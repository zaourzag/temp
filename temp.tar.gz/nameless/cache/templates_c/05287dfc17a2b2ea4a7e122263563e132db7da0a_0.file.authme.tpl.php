<?php
/* Smarty version 3.1.33, created on 2021-01-23 02:21:11
  from '/var/www/nameless/custom/templates/DefaultRevamp/authme.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600b8817be6bc8_45865245',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '05287dfc17a2b2ea4a7e122263563e132db7da0a' => 
    array (
      0 => '/var/www/nameless/custom/templates/DefaultRevamp/authme.tpl',
      1 => 1611079053,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_600b8817be6bc8_45865245 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<h2 class="ui header">
  <?php echo $_smarty_tpl->tpl_vars['CONNECT_WITH_AUTHME']->value;?>

  <div class="sub header"><?php echo $_smarty_tpl->tpl_vars['AUTHME_INFO']->value;?>
</div>
</h2>

<?php if (count($_smarty_tpl->tpl_vars['ERRORS']->value)) {?>
  <div class="ui error icon message">
    <i class="x icon"></i>
    <div class="content">
      <div class="header">Error</div>
      <ul class="list">
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ERRORS']->value, 'error');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['error']->value) {
?>
          <li><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</li>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
      </ul>
    </div>
  </div>
<?php }?>

<div class="ui padded segment" id="authme-email">
  <div class="ui stackable grid">
    <div class="ui centered row">
      <div class="ui sixteen wide tablet ten wide computer column">
        <form class="ui form" action="" method="post" id="form-authme-email">
          <div class="field">
            <label for="inputUsername"><?php echo $_smarty_tpl->tpl_vars['USERNAME']->value;?>
</label>
            <input type="text" id="inputUsername" name="username" placeholder="<?php echo $_smarty_tpl->tpl_vars['USERNAME']->value;?>
" tabindex="1">
          </div>
          <div class="field">
            <label for="inputPassword"><?php echo $_smarty_tpl->tpl_vars['PASSWORD']->value;?>
</label>
            <input type="password" id="inputPassword" name="password" placeholder="<?php echo $_smarty_tpl->tpl_vars['PASSWORD']->value;?>
" tabindex="2">
          </div>
          <?php if (isset($_smarty_tpl->tpl_vars['RECAPTCHA']->value)) {?>
            <div class="field">
              <div class="g-recaptcha" data-sitekey="<?php echo $_smarty_tpl->tpl_vars['RECAPTCHA']->value;?>
" tabindex="3"></div>
            </div>
          <?php }?>
          <div class="inline field">
            <div class="ui checkbox">
              <input type="checkbox" name="t_and_c" id="t_and_c" value="1" tabindex="7">
              <label for="t_and_c"><?php echo $_smarty_tpl->tpl_vars['AGREE_TO_TERMS']->value;?>
</label>
            </div>
          </div>
          <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
          <input type="submit" class="ui primary button" value="<?php echo $_smarty_tpl->tpl_vars['SUBMIT']->value;?>
" tabindex="5">
        </form>
      </div>
    </div>
  </div>
</div>

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
