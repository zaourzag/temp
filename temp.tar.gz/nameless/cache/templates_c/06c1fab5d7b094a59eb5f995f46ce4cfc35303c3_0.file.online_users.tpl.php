<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:17
  from '/var/www/nameless/custom/templates/Aether/widgets/online_users.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c2d6656d1_40739184',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '06c1fab5d7b094a59eb5f995f46ce4cfc35303c3' => 
    array (
      0 => '/var/www/nameless/custom/templates/Aether/widgets/online_users.tpl',
      1 => 1599551086,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c2d6656d1_40739184 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="card">
    <div class="card-header header-theme">
        <span><i class="fas fa-users"></i> <?php echo $_smarty_tpl->tpl_vars['ONLINE_USERS']->value;?>
</span>
    </div>
    <div class="card-block">
        <?php if (isset($_smarty_tpl->tpl_vars['ONLINE_USERS_LIST']->value)) {?>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ONLINE_USERS_LIST']->value, 'user', false, NULL, 'online_users_arr', array (
  'last' => true,
  'iteration' => true,
  'total' => true,
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
$_smarty_tpl->tpl_vars['__smarty_foreach_online_users_arr']->value['iteration']++;
$_smarty_tpl->tpl_vars['__smarty_foreach_online_users_arr']->value['last'] = $_smarty_tpl->tpl_vars['__smarty_foreach_online_users_arr']->value['iteration'] === $_smarty_tpl->tpl_vars['__smarty_foreach_online_users_arr']->value['total'];
?>
            <a style="<?php echo $_smarty_tpl->tpl_vars['user']->value['style'];?>
" href="<?php echo $_smarty_tpl->tpl_vars['user']->value['profile'];?>
" data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
" data-html="true" data-placement="top"><img src="<?php echo $_smarty_tpl->tpl_vars['user']->value['avatar'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['user']->value['nickname'];?>
" class="img-rounded" style="max-height:20px;max-width:20px;"> <?php if ($_smarty_tpl->tpl_vars['SHOW_NICKNAME_INSTEAD']->value) {
echo $_smarty_tpl->tpl_vars['user']->value['nickname'];
} else {
echo $_smarty_tpl->tpl_vars['user']->value['username'];
}?></a>
                <?php if (!(isset($_smarty_tpl->tpl_vars['__smarty_foreach_online_users_arr']->value['last']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_online_users_arr']->value['last'] : null)) {?><br /><?php }?>
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        <?php } else { ?>
            <?php echo $_smarty_tpl->tpl_vars['NO_USERS_ONLINE']->value;?>

        <?php }?>
    </div>
</div><?php }
}
