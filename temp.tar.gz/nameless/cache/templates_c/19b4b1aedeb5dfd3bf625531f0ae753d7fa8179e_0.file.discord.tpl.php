<?php
/* Smarty version 3.1.33, created on 2021-01-27 08:09:41
  from '/var/www/nameless/custom/panel_templates/Default/core/widgets/discord.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60111fc55e4ee5_33103155',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '19b4b1aedeb5dfd3bf625531f0ae753d7fa8179e' => 
    array (
      0 => '/var/www/nameless/custom/panel_templates/Default/core/widgets/discord.tpl',
      1 => 1611082601,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60111fc55e4ee5_33103155 (Smarty_Internal_Template $_smarty_tpl) {
?><form action="" method="post">
    <div class="form-group">
        <label for="inputDiscordId"><?php echo $_smarty_tpl->tpl_vars['DISCORD_ID']->value;?>
 <span class="badge badge-info" data-toggle="popover" data-title="<?php echo $_smarty_tpl->tpl_vars['INFO']->value;?>
" data-content="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['ID_INFO']->value, ENT_QUOTES, 'UTF-8', true);?>
"><i class="fa fa-question"></i></label>
        <input class="form-control" type="number" name="discord_guild_id" id="inputDiscordId" value="<?php echo $_smarty_tpl->tpl_vars['DISCORD_ID_VALUE']->value;?>
">
    </div>
    <div class="form-group">
        <label for="inputDiscordTheme"><?php echo $_smarty_tpl->tpl_vars['DISCORD_THEME']->value;?>
</label>
        <select class="form-control" id="inputDiscordTheme" name="theme">
            <option value="dark" <?php if ($_smarty_tpl->tpl_vars['DISCORD_THEME_VALUE']->value == 'dark') {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['DARK']->value;?>
</option>
            <option value="light" <?php if ($_smarty_tpl->tpl_vars['DISCORD_THEME_VALUE']->value == 'light') {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['LIGHT']->value;?>
</option>
        </select>
    </div>
    <div type="form-group">
        <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
        <input type="submit" class="btn btn-primary" value="<?php echo $_smarty_tpl->tpl_vars['SUBMIT']->value;?>
">
    </div>
</form><?php }
}
