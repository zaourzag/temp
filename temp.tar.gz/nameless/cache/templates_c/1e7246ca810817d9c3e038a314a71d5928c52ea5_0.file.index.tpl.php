<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:42:50
  from '/var/www/nameless/custom/templates/MineBox/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c8a758053_77436236',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1e7246ca810817d9c3e038a314a71d5928c52ea5' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/index.tpl',
      1 => 1611094419,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_60077c8a758053_77436236 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/nameless/core/includes/smarty/plugins/modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<div class="container" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER']->value;?>
;">
  <div class="card">
    <div class="card-body">
	  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
	    <ol class="carousel-indicators">
		  <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
		  <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
		  <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
	    </ol>
	  <div class="carousel-inner">
        <div class="carousel-item active">
		  <img class="d-block w-100" src="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER1_IMG']->value;?>
" height="300px" title="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER1_TITLE']->value;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER1_TITLE']->value;?>
">
		  <div class="carousel-caption d-none d-md-block">
			<h5><?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER1_TITLE']->value;?>
</h5>
			<p><?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER1_DESC']->value;?>
</p>
		  </div>
        </div>
        <div class="carousel-item">
		  <img class="d-block w-100" src="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER2_IMG']->value;?>
" height="300px" title="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER2_TITLE']->value;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER2_TITLE']->value;?>
">
		  <div class="carousel-caption d-none d-md-block">
			<h5><?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER2_TITLE']->value;?>
</h5>
			<p><?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER2_DESC']->value;?>
</p>
          </div>
        </div>
        <div class="carousel-item">
		  <img class="d-block w-100" src="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER3_IMG']->value;?>
" height="300px" title="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER3_TITLE']->value;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER3_TITLE']->value;?>
">
		  <div class="carousel-caption d-none d-md-block">
			<h5><?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER3_TITLE']->value;?>
</h5>
			<p><?php echo $_smarty_tpl->tpl_vars['MINEBOX_SLIDER3_DESC']->value;?>
</p>
          </div>
        </div>
	  </div>
	  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
	  </a>
	  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
	  </a>
	  </div>
    </div>
  </div>
<br />  
</div>


<div class="container">
 <div class="card">
  <div class="card-body">
  <div class="home-news">
    <?php if (isset($_smarty_tpl->tpl_vars['HOME_SESSION_FLASH']->value)) {?>
      <div class="alert alert-info">
        <i class="fa fa-exclamation-triangle" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['HOME_SESSION_FLASH']->value;?>

      </div>
    <?php }?>
    <?php if (isset($_smarty_tpl->tpl_vars['HOME_SESSION_ERROR_FLASH']->value)) {?>
      <div class="alert alert-danger">
        <i class="fa fa-exclamation-triangle" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['HOME_SESSION_ERROR_FLASH']->value;?>

      </div>
    <?php }?>
	
	<div class="row">
	  <?php if (isset($_smarty_tpl->tpl_vars['NEWS']->value)) {?>
	  <div class="col-md-9">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['NEWS']->value, 'item');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['item']->value) {
?>
		<div class="card panel-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
">
		  <div class="card-header text-white text-uppercase header-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
">
			<div class="announcement-header">
				<div class="announcement-calendar">
					<div class="day"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['item']->value['date'],"%d");?>
</div>
					<div class="month"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['item']->value['date'],"%b");?>
</div>
				</div>
				<div class="announcement-header-details">
					<div class="announcement-title">
						<?php if ($_smarty_tpl->tpl_vars['item']->value['label']) {
echo $_smarty_tpl->tpl_vars['item']->value['label'];?>
 <?php }?><a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
					</div>
					<ul class="announcement-meta listInline listInline--bullet">
						<li><i class="fa fa-user"></i> <a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_url'];?>
" style="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_style'];?>
" data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['item']->value['author_id'];?>
" data-html="true" data-placement="top"> <?php echo $_smarty_tpl->tpl_vars['item']->value['author_name'];?>
</a></li>
						<li><i class="fa fa-clock-o"></i> <span data-toggle="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['item']->value['date'];?>
"> <?php echo $_smarty_tpl->tpl_vars['item']->value['time_ago'];?>
</span></li>
						<li><i class="fa fa-eye"></i><a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['url'];?>
"> <?php echo $_smarty_tpl->tpl_vars['item']->value['views'];?>
</a></li>
						<li><i class="fa fa-comments"></i><a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['url'];?>
"> <?php echo $_smarty_tpl->tpl_vars['item']->value['replies'];?>
</a></li>
					</ul>
				</div>
				<a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_url'];?>
" class="avatar avatar--s announcement-avatar" data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['item']->value['author_id'];?>
" data-html="true" data-placement="top">
					<img src="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_avatar'];?>
"  class="avatar-u2-s img-rounded" width="100%" alt="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_name'];?>
">
				</a>
			</div>
		  </div>
		  <div class="card-body">
			<div class="news-content">
			 <?php echo $_smarty_tpl->tpl_vars['item']->value['content'];?>

			</div>
		  </div>
		  <div class="panel-footer">  
			<span class="pull-left">
				<span class="ui right floated blue image label bg-secondary "><i class="fa fa-comments"></i> <?php echo $_smarty_tpl->tpl_vars['item']->value['replies'];?>
</span>
				<span class="ui right floated blue image label bg-secondary "><i class="fa fa-eye"></i> <?php echo $_smarty_tpl->tpl_vars['item']->value['views'];?>
</span>
				<a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_url'];?>
" style="background-<?php echo $_smarty_tpl->tpl_vars['item']->value['author_style'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['author_style'];?>
" class="ui right floated blue image label" data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['item']->value['author_id'];?>
" data-html="true" data-placement="top"><img src="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_avatar'];?>
" alt=""> <?php echo $_smarty_tpl->tpl_vars['item']->value['author_name'];?>
</a>
			</span>
			<span class="pull-right">
				<a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['url'];?>
" class="ui label bg-secondary text-white" ><i class="fa fa-book" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['READ_FULL_POST']->value;?>
</a>
			</span>
		  </div>
		</div>
		<hr>
		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	  </div>
	  <div class="col-md-3">
	  
	  <?php } else { ?>
	  <div class="col-md-4 offset-md-4">
	  <?php }?>

<div class="googleads" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS']->value;?>
;">
<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value, $tmp) > 0) {?>
<br />
  <center>
	<ins class="adsbygoogle" data-ad-client="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value;?>
" data-ad-slot="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_SLOT']->value;?>
" data-ad-format="auto" data-full-width-responsive="true"></ins>
	<?php echo '<script'; ?>
>
		(adsbygoogle = window.adsbygoogle || []).push({});
	<?php echo '</script'; ?>
>
  </center>
<?php }?>
</div>

<div class="sidebar_banner" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER']->value;?>
;">
<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value, $tmp) > 0) {?>
<br />
  <center>
	<a href="<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value, $tmp) > 0) {
echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value;
} else { ?>#!<?php }?>" target="_blank" rel="nofollow">
		<img src="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value;?>
" style="max-width: 100%;">
	</a>
  </center>
<br />
<?php }?>
</div>



	<?php if (isset($_smarty_tpl->tpl_vars['MINECRAFT']->value)) {?>
	 
	  <div class="card panel-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
">
	    <div class="collaps card-header header-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
"><i class="fa fa-server" style="width: auto;margin: 0 .75em 0 0;"></i> SERVER STATUS</div>
	      <div class="content" style="margin-bottom: -16px;">
	      <div class="well">
	        <table class="table">
		    <?php if (isset($_smarty_tpl->tpl_vars['CLICK_TO_COPY_TOOLTIP']->value)) {?>
		      <tbody>
			    <tr class="bg-primary text-white">
			      <style>
				    .server{
					    font-size: 0px;
				    }
				    .server .fa{
					    font-size: 12px;
				    }
				    .server #ip{
					    font-size: 12px;
				    }
			      </style>
				  <span class="btn btn-primary btn-sm server" style="width: 100%; padding: 10px; text-align: left; border-radius: 0px;" onclick="copyToClipboard('#ip')" data-toggle="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['CLICK_TO_COPY_TOOLTIP']->value;?>
"><i class="fa fa-clone" style="width: auto;margin: 0 .75em 0 0;"></i><?php echo $_smarty_tpl->tpl_vars['CONNECT_WITH']->value;?>
</span>
			    </tr>
		    <?php }?>
		    <?php if (isset($_smarty_tpl->tpl_vars['SERVER_QUERY']->value)) {?>
		      <?php if (isset($_smarty_tpl->tpl_vars['SERVER_QUERY']->value['status_value']) && $_smarty_tpl->tpl_vars['SERVER_QUERY']->value['status_value'] == 1) {?>
			    <?php if (isset($_smarty_tpl->tpl_vars['SERVER_QUERY']->value['status_full'])) {?>
				    <tr class="bg-warning text-white">
				      <span class="btn btn-warning btn-sm" style="width: 100%; padding: 10px; text-align: left; border-radius: 0px;"><i class="fa fa-circle-o-notch fa-spin fa-1x" style="width: auto;margin: 0 .75em 0 0;"></i><?php echo $_smarty_tpl->tpl_vars['SERVER_QUERY']->value['status_full'];?>
</span>
				    </tr>
			    <?php } else { ?>
				    <tr class="bg-success text-white">
				      <span class="btn btn-success btn-sm" style="width: 100%; padding: 10px; text-align: left; border-radius: 0px;"><i class="fa fa-circle-o-notch fa-spin fa-1x" style="width: auto;margin: 0 .75em 0 0;"></i><?php echo $_smarty_tpl->tpl_vars['SERVER_ONLINE']->value;?>
</span>
				    </tr>
			    <?php }?>
		      <?php } else { ?>
			    <tr class="bg-danger text-white">
			     <span class="btn btn-danger btn-sm" style="width: 100%; padding: 10px; text-align: left; border-radius: 0px;"><i class="fa fa-circle-o-notch fa-spin fa-1x" style="width: auto;margin: 0 .75em 0 0;"></i><?php echo $_smarty_tpl->tpl_vars['SERVER_OFFLINE']->value;?>
</span>
			    </tr>
		      <?php }?>
		    <?php }?>
		      </tbody>
		    </table>
	      </div>
	    </div>
	  </div>
	  <br />
	<?php }?>




		<?php if (count($_smarty_tpl->tpl_vars['WIDGETS']->value)) {?>
		  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['WIDGETS']->value, 'widget');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['widget']->value) {
?>
			<?php echo $_smarty_tpl->tpl_vars['widget']->value;?>

			<br />
		  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		<?php }?>
	    
	   </div>
	 </div>
   </div>
  </div>
 </div>
</div>
<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
