<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:17
  from '/var/www/nameless/custom/templates/Aether/navbar.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c2d6cc7e6_56361839',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '21339be35892d759ad3df32876c2ca66da8c330a' => 
    array (
      0 => '/var/www/nameless/custom/templates/Aether/navbar.tpl',
      1 => 1599551082,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c2d6cc7e6_56361839 (Smarty_Internal_Template $_smarty_tpl) {
?><nav class="navbar navbar-theme navbar-fixed-top">
    <div class="container">
        <button class="navbar-toggler hidden-md-up white-text nav-link" type="button" data-toggle="collapse" data-target="#navbar">
    	<i class="fas fa-bars"></i> <?php echo $_smarty_tpl->tpl_vars['NAVBAR_MENU']->value;?>

</button>
        <div class="collapse navbar-toggleable-sm" id="navbar">
            <ul class="nav navbar-nav">
                <a class="navbar-brand col-inv" href="/"><?php echo $_smarty_tpl->tpl_vars['SITE_NAME']->value;?>
</a> <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['NAV_LINKS']->value, 'item', false, 'name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['name']->value => $_smarty_tpl->tpl_vars['item']->value) {
?> <?php if (isset($_smarty_tpl->tpl_vars['item']->value['items'])) {?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle white-text" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
                    <div class="dropdown-menu">
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['item']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?>
                        <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" <?php if (isset($_smarty_tpl->tpl_vars['dropdown']->value['target']) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['dropdown']->value['target'], $tmp) > 2) {?> target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
"<?php }?>><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a> <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </div>
                </li>
                <?php } else { ?>
                <li class="nav-item">
                    <a class="nav-link white-text <?php if (isset($_smarty_tpl->tpl_vars['item']->value['active'])) {?>nav-link-active<?php }?>" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" <?php if (isset($_smarty_tpl->tpl_vars['item']->value['target']) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['item']->value['target'], $tmp) > 2) {?> target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"<?php }?>><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a></li>
                <?php }?> <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </ul>
            <ul class="nav navbar-nav pull-xs-right">
                <?php if (isset($_smarty_tpl->tpl_vars['MESSAGING_LINK']->value)) {?>
                <li class="nav-item dropdown pm-dropdown">
                    <a href="#" class="nav-link dropdown-toggle no-caret white-text" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span style="margin: -10px 0px; font-size: 16px;"><i class="fa fa-envelope"></i> <div style="display: inline;" id="pms"></div></span></a>
                    <div class="dropdown-menu pm-dropdown-menu dropdown-menu-right">
                        <div id="pm_dropdown"><?php echo $_smarty_tpl->tpl_vars['LOADING']->value;?>
</div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['MESSAGING_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['VIEW_MESSAGES']->value;?>
</a>
                    </div>
                </li>
                <li class="nav-item dropdown alert-dropdown">
                    <a href="#" class="nav-link dropdown-toggle no-caret white-text" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span style="margin: -10px 0px; font-size: 16px;"><i class="fa fa-flag"></i> <div style="display: inline;" id="alerts"></div></span></a>
                    <div class="dropdown-menu alert-dropdown-menu dropdown-menu-right">
                        <div id="alert_dropdown"><?php echo $_smarty_tpl->tpl_vars['LOADING']->value;?>
</div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['ALERTS_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['VIEW_ALERTS']->value;?>
</a>
                    </div>
                </li>
                <?php }?> <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['USER_AREA']->value, 'item', false, 'name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['name']->value => $_smarty_tpl->tpl_vars['item']->value) {
?> <?php if (isset($_smarty_tpl->tpl_vars['item']->value['items'])) {?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['item']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?> <?php if (isset($_smarty_tpl->tpl_vars['dropdown']->value['separator'])) {?>
                        <div class="dropdown-divider"></div>
                        <?php } else { ?>
                        <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" <?php if (isset($_smarty_tpl->tpl_vars['dropdown']->value['target']) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['dropdown']->value['target'], $tmp) > 2) {?> target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
"<?php }?>><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a> <?php }?> <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </div>
                </li>
                <?php } else { ?>
                <li class="nav-item<?php if (isset($_smarty_tpl->tpl_vars['item']->value['active'])) {?> active<?php }?>" style="padding-right:10px;">
                    <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" <?php if (isset($_smarty_tpl->tpl_vars['item']->value['target']) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['item']->value['target'], $tmp) > 2) {?> target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"<?php }?>><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
                </li>
                <?php }?> <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?> <?php if (isset($_smarty_tpl->tpl_vars['USER_DROPDOWN']->value)) {?> <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['USER_DROPDOWN']->value, 'item', false, 'name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['name']->value => $_smarty_tpl->tpl_vars['item']->value) {
?> <?php if (isset($_smarty_tpl->tpl_vars['item']->value['items'])) {?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle white-text" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                            <?php if (isset($_smarty_tpl->tpl_vars['LOGGED_IN_USER']->value)) {?>
				<img src="<?php echo $_smarty_tpl->tpl_vars['LOGGED_IN_USER']->value['avatar'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['LOGGED_IN_USER']->value['username'];?>
" class="img-rounded" style="max-height:20px;max-width:20px;"/><?php }?> <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>

						</a>
                    <div class="dropdown-menu dropdown-menu-right white-text">
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['item']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?> <?php if (isset($_smarty_tpl->tpl_vars['dropdown']->value['separator'])) {?>
                        <div class="dropdown-divider"></div>
                        <?php } else { ?>
                        <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" <?php if (isset($_smarty_tpl->tpl_vars['dropdown']->value['target']) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['dropdown']->value['target'], $tmp) > 2) {?> target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
"<?php }?>><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a> <?php }?> <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </div>
                </li>
                <?php } else { ?>
                <li class="nav-item<?php if (isset($_smarty_tpl->tpl_vars['item']->value['active'])) {?> active<?php }?>" style="padding-right:10px;">
                    <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" <?php if (isset($_smarty_tpl->tpl_vars['item']->value['target']) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['item']->value['target'], $tmp) > 2) {?> target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"<?php }?>><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
                </li>
                <?php }?> <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?> <?php }?>
            </ul>
        </div>
    </div>
</nav>
<?php if (isset($_smarty_tpl->tpl_vars['THEME_C_OVERLAY']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_C_OVERLAY']->value, $tmp) > 2) {?>
<div class="color-overlay">
    <div class="aether-headtop" style="opacity: 0.3; z-index: 1">
    </div>
</div>
<?php } else { ?>
<div class="color-overlay">
    <div class="aether-headtop" style="opacity: 1; z-index: 4">
    </div>
</div>
<?php }?>
<img class="logo" alt="logo" src='<?php echo $_smarty_tpl->tpl_vars['THEME_LOGO']->value;?>
'> <?php if (isset($_smarty_tpl->tpl_vars['THEME_SERVER_BOX']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SERVER_BOX']->value, $tmp) > 2) {?> <?php if (isset($_smarty_tpl->tpl_vars['MINECRAFT']->value)) {?>
<div class="box box1 col-inv">
    <h1><b><?php echo $_smarty_tpl->tpl_vars['SERVER_BOX_TITLE']->value;?>
 <i class="fas fa-cube"></i></b></h1> <?php if (isset($_smarty_tpl->tpl_vars['CLICK_TO_COPY_TOOLTIP']->value)) {?>
    <span class="btn" onclick="copyToClipboard('#ip')" data-toggle="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['CLICK_TO_COPY_TOOLTIP']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['CONNECT_WITH']->value;?>
</span>
    <br /> <?php }?> <?php if (isset($_smarty_tpl->tpl_vars['SERVER_QUERY']->value)) {?><span class="btn"><?php if (isset($_smarty_tpl->tpl_vars['SERVER_QUERY']->value['status_value']) && $_smarty_tpl->tpl_vars['SERVER_QUERY']->value['status_value'] == 1) {?>
    <?php echo $_smarty_tpl->tpl_vars['SERVER_QUERY']->value['x_players_online'];
} else {
echo $_smarty_tpl->tpl_vars['SERVER_OFFLINE']->value;
}?></span><?php }?>
    <br />
    <br />
</div>
<?php }?> <?php }?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_DISCORD_BOX']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_DISCORD_BOX']->value, $tmp) > 2) {?>
<div class="box box2 col-inv">
    <h1><b><?php echo $_smarty_tpl->tpl_vars['DISCORD_BOX_TITLE']->value;?>
 <i class="fab fa-discord"></i></b></h1>
    <span class="btn" onclick="copyToClipboard('#discord')" data-toggle="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['CLICK_TO_COPY_TOOLTIP']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['DISCORD_BOX_COPY']->value;?>
 <span id="discord"><?php echo $_smarty_tpl->tpl_vars['THEME_DISCORD_SERVER']->value;?>
</span></span>
    <br />
    <span class="btn"><?php echo $_smarty_tpl->tpl_vars['DISCORD_BOX_STATUS_1']->value;?>
 <b><?php echo $_smarty_tpl->tpl_vars['DISCORD_API_COUNT']->value;?>
</b> <?php echo $_smarty_tpl->tpl_vars['DISCORD_BOX_STATUS_2']->value;?>
</span>
    <br />
    <br />
</div>
<?php }?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_BOX_MOBILE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_BOX_MOBILE']->value, $tmp) > 2) {?>
<div class="box box1 box-inv">
    <?php if (isset($_smarty_tpl->tpl_vars['THEME_SERVER_BOX']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SERVER_BOX']->value, $tmp) > 2) {?> <?php if (isset($_smarty_tpl->tpl_vars['MINECRAFT']->value)) {?>
    <h1><b><?php echo $_smarty_tpl->tpl_vars['SERVER_BOX_TITLE']->value;?>
 <i class="fas fa-cube"></i></b></h1> <?php if (isset($_smarty_tpl->tpl_vars['CLICK_TO_COPY_TOOLTIP']->value)) {?>
    <span class="btn" onclick="copyToClipboard('#ip')" data-toggle="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['CLICK_TO_COPY_TOOLTIP']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['CONNECT_WITH']->value;?>
</span>
    <br /> <?php }?> <?php if (isset($_smarty_tpl->tpl_vars['SERVER_QUERY']->value)) {?> <?php if (isset($_smarty_tpl->tpl_vars['SERVER_QUERY']->value['status_value']) && $_smarty_tpl->tpl_vars['SERVER_QUERY']->value['status_value'] == 1) {?>
    <span class="btn"><?php echo $_smarty_tpl->tpl_vars['SERVER_QUERY']->value['x_players_online'];?>
</span> <?php } else { ?>
    <span class="btn"><?php echo $_smarty_tpl->tpl_vars['SERVER_OFFLINE']->value;?>
</span> <?php }?> <?php }?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_DISCORD_BOX']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_DISCORD_BOX']->value, $tmp) > 2) {?>
    <h1><b><?php echo $_smarty_tpl->tpl_vars['DISCORD_BOX_TITLE']->value;?>
 <i class="fab fa-discord"></i></b></h1>
    <span class="btn" onclick="copyToClipboard('#discord')" data-toggle="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['CLICK_TO_COPY_TOOLTIP']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['DISCORD_BOX_COPY']->value;?>
 <span id="discord"><?php echo $_smarty_tpl->tpl_vars['THEME_DISCORD_SERVER']->value;?>
</span></span>
    <br />
    <span class="btn"><?php echo $_smarty_tpl->tpl_vars['DISCORD_BOX_STATUS_1']->value;?>
 <b><?php echo $_smarty_tpl->tpl_vars['DISCORD_API_COUNT']->value;?>
</b> <?php echo $_smarty_tpl->tpl_vars['DISCORD_BOX_STATUS_2']->value;?>
</span>
    <br /> <?php }?> <?php }?> <?php }?>
</div>
<?php }?>
<div class="header-bottom-theme"></div>
<div class="container" style="padding-top: 2rem;">
    <?php if (isset($_smarty_tpl->tpl_vars['MAINTENANCE_ENABLED']->value)) {?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button> <?php echo $_smarty_tpl->tpl_vars['MAINTENANCE_ENABLED']->value;?>

    </div>
    <?php }?> <?php if (isset($_smarty_tpl->tpl_vars['MUST_VALIDATE_ACCOUNT']->value)) {?>
    <div class="alert alert-danger">
        <?php echo $_smarty_tpl->tpl_vars['MUST_VALIDATE_ACCOUNT']->value;?>

    </div>
    <?php }?>
</div>
<div class="container">
    <?php if (isset($_smarty_tpl->tpl_vars['THEME_ALERT_TITLE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_ALERT_TITLE']->value, $tmp) > 0) {?>
    <div class="alert bg-danger">
        <h4 class="alert-heading"><i class="fas fa-exclamation-circle alert-blink"></i> <?php echo $_smarty_tpl->tpl_vars['THEME_ALERT_TITLE']->value;?>
</h4>
        <hr>
        <p><?php echo $_smarty_tpl->tpl_vars['THEME_ALERT_TEXT']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['THEME_ALERT_PAGE']->value;?>
</p>
    </div>
    <?php }?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_ANNOUNCE_TITLE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_ANNOUNCE_TITLE']->value, $tmp) > 0) {?>
    <div class="card">
        <div class="card-header header-theme"><i class="fas fa-bullhorn"></i> <?php echo $_smarty_tpl->tpl_vars['THEME_ANNOUNCE_TITLE']->value;?>
</div>
        <div class="card-block">
            <?php echo $_smarty_tpl->tpl_vars['THEME_ANNOUNCE_TEXT']->value;?>

        </div>
    </div>
    <?php }?>
    <div class="chatbox" id="chatbox-top"></div>
</div><?php }
}
