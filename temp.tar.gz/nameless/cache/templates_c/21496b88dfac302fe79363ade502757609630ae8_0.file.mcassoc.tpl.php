<?php
/* Smarty version 3.1.33, created on 2021-01-27 15:17:38
  from '/var/www/nameless/custom/templates/DefaultRevamp/mcassoc.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60118412c87bc5_69437631',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '21496b88dfac302fe79363ade502757609630ae8' => 
    array (
      0 => '/var/www/nameless/custom/templates/DefaultRevamp/mcassoc.tpl',
      1 => 1611079053,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_60118412c87bc5_69437631 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<h2 class="ui header">
  <?php echo $_smarty_tpl->tpl_vars['VERIFY_ACCOUNT']->value;?>

  <div class="sub header"><?php echo $_smarty_tpl->tpl_vars['VERIFY_ACCOUNT_HELP']->value;?>
</div>
</h2>

<?php if (!isset($_smarty_tpl->tpl_vars['STEP']->value)) {?>
  <div class="ui padded segment" id="mcassoc-body">
    <?php echo $_smarty_tpl->tpl_vars['MCASSOC']->value;?>

  </div>
<?php } else { ?>
  <?php if (isset($_smarty_tpl->tpl_vars['ERROR']->value)) {?>
    <div class="ui error icon message">
      <i class="x icon"></i>
      <div class="content">
        <div class="header">Error</div>
        <?php echo $_smarty_tpl->tpl_vars['ERROR']->value;?>

        <br />
        <b><a href="<?php echo $_smarty_tpl->tpl_vars['RETRY_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['RETRY_TEXT']->value;?>
</a></b>
      </div>
    </div>
  <?php } elseif (isset($_smarty_tpl->tpl_vars['SUCCESS']->value)) {?>
    <div class="ui success icon message">
      <i class="check icon"></i>
      <div class="content">
        <div class="header">Success</div>
        <?php echo $_smarty_tpl->tpl_vars['SUCCESS']->value;?>

        <br />
        <b><a href="<?php echo $_smarty_tpl->tpl_vars['LOGIN_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['LOGIN_TEXT']->value;?>
</a></b>
      </div>
    </div>
  <?php }
}?>

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
