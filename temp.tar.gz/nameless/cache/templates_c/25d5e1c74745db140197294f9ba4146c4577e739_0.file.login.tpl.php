<?php
/* Smarty version 3.1.33, created on 2021-01-20 01:19:21
  from '/var/www/nameless/custom/templates/MineBox/login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60078519942511_59545257',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '25d5e1c74745db140197294f9ba4146c4577e739' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/login.tpl',
      1 => 1611094419,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_60078519942511_59545257 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="container">
  <div class="row">
	<div class="col-md-12">
	  <div class="card">
	  <div class="card-body">
		<h1><i class="fa fa-sign-in" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['SIGN_IN']->value;?>
</h1>
	    <div class="row justify-content-center">
		<div class="col-md-6">
		  <form role="form" action="" method="post">

			<?php if (count($_smarty_tpl->tpl_vars['ERROR']->value)) {?>
			<div class="alert alert-danger" role="alert">
			  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ERROR']->value, 'item', false, NULL, 'err', array (
  'last' => true,
  'iteration' => true,
  'total' => true,
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['__smarty_foreach_err']->value['iteration']++;
$_smarty_tpl->tpl_vars['__smarty_foreach_err']->value['last'] = $_smarty_tpl->tpl_vars['__smarty_foreach_err']->value['iteration'] === $_smarty_tpl->tpl_vars['__smarty_foreach_err']->value['total'];
?>
				<?php echo $_smarty_tpl->tpl_vars['item']->value;?>

				<?php if (!(isset($_smarty_tpl->tpl_vars['__smarty_foreach_err']->value['last']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_err']->value['last'] : null)) {?><br /><?php }?>
			  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			</div>
			<?php }?>


              <?php if (isset($_smarty_tpl->tpl_vars['EMAIL']->value)) {?>
				  <div class="form-group">
					  <label for="email"><i class="fa fa-at" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['EMAIL']->value;?>
</label>
					  <input type="email" class="form-control form-control-lg" name="email" id="email"
							 autocomplete="off" value="<?php echo $_smarty_tpl->tpl_vars['USERNAME_INPUT']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['EMAIL']->value;?>
" tabindex="1">
				  </div>
              <?php } else { ?>
				  <div class="form-group">
					  <label for="username"><i class="fa fa-user" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['USERNAME']->value;?>
</label>
					  <input type="text" class="form-control form-control-lg" name="username" id="username"
							 autocomplete="off" value="<?php echo $_smarty_tpl->tpl_vars['USERNAME_INPUT']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['USERNAME']->value;?>
" tabindex="1">
				  </div>
              <?php }?>
			
			<div class="form-group">
			  <label for="password"><i class="fa fa-lock" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['PASSWORD']->value;?>
</label>
			  <input type="password" class="form-control form-control-lg" name="password" id="password" autocomplete="off" placeholder="<?php echo $_smarty_tpl->tpl_vars['PASSWORD']->value;?>
" tabindex="2">
			</div>

			<div class="form-group">
			  <div class="row">
				<div class="col-xs-12 col-md-6">
				  <div class="form-group">
					<span class="button-checkbox">
						<button type="button" class="btn" data-color="info" tabindex="7"> <?php echo $_smarty_tpl->tpl_vars['REMEMBER_ME']->value;?>
</button>
						<input type="checkbox" name="remember" id="remember" style="display:none;" value="1">
					</span>				
				  </div>
				</div>
				<div class="col-xs-12 col-md-6">
				  <span class="pull-right">
					<a class="btn btn-warning" href="<?php echo $_smarty_tpl->tpl_vars['FORGOT_PASSWORD_URL']->value;?>
"><i class="fa fa-unlock-alt" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['FORGOT_PASSWORD']->value;?>
</a>
				  </span>
				</div>
			  </div>
			</div>
			<input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['FORM_TOKEN']->value;?>
">
			<input type="submit" class="btn btn-success" value="<?php echo $_smarty_tpl->tpl_vars['SIGN_IN']->value;?>
">
			<a href="<?php echo $_smarty_tpl->tpl_vars['REGISTER_URL']->value;?>
" class="btn btn-primary"><i class="fa fa-user-plus" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['REGISTER']->value;?>
</a>
		  </form>
		  </div>
	    </div>
	  </div>
	</div>
	</div>
  </div>
</div>

<br />

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
