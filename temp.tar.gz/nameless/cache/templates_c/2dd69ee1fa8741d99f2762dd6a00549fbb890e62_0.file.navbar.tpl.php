<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:42:50
  from '/var/www/nameless/custom/templates/MineBox/navbar.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c8a782ab0_60062634',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2dd69ee1fa8741d99f2762dd6a00549fbb890e62' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/navbar.tpl',
      1 => 1611094419,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c8a782ab0_60062634 (Smarty_Internal_Template $_smarty_tpl) {
?><div class='minebox-headtop'>
	<center>
		<a href="<?php echo $_smarty_tpl->tpl_vars['SITE_HOME']->value;?>
"><img class="logo animated pulse infinite img-fluid" src="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_LOGO']->value;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['SITE_NAME']->value;?>
"></a> 
	</center>
</div>
<nav class="navbar navbar-expand-lg sticky-top text-uppercase navbar-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
 navbar-default">
  <button class="navbar-toggler" style="padding:10px;" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="text-white">&#9776;</span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	<div class="container">
	  <ul class="navbar-nav mr-auto pull-left">
	    <a class="navbar-brand" href="<?php echo $_smarty_tpl->tpl_vars['SITE_HOME']->value;?>
"> <?php echo $_smarty_tpl->tpl_vars['SITE_NAME']->value;?>
</a>
 	    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['NAV_LINKS']->value, 'item', false, 'name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['name']->value => $_smarty_tpl->tpl_vars['item']->value) {
?>
		  <?php if (isset($_smarty_tpl->tpl_vars['item']->value['items'])) {?>
		    			<li class="nav-item dropdown">
			  <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
			    <div class="dropdown-menu">
				  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['item']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?>
				    <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a>
				  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				</div>
			  </a>
			</li>
		  <?php } else { ?>
		    			<li class="nav-item<?php if (isset($_smarty_tpl->tpl_vars['item']->value['active'])) {?> active<?php }?> <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
">
			  <a class="nav-link<?php if (isset($_smarty_tpl->tpl_vars['item']->value['active'])) {?> white-text<?php }?>" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
			</li>
		  <?php }?>
		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	  </ul>
	
	  <ul class="nav navbar-nav pull-right">
	    <?php if (isset($_smarty_tpl->tpl_vars['MESSAGING_LINK']->value)) {?>
	    		<li class="nav-item dropdown pm-dropdown">
		  <a href="#" class="nav-link dropdown-toggle no-caret" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span style="margin: -10px 0px; font-size: 16px;"><i class="fa fa-envelope"></i> <div style="display: inline;" id="pms"></div></span></a>
		  <div class="dropdown-menu pm-dropdown-menu">
		    <div id="pm_dropdown"><?php echo $_smarty_tpl->tpl_vars['LOADING']->value;?>
</div>
			<div class="dropdown-divider"></div>
			<a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['MESSAGING_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['VIEW_MESSAGES']->value;?>
</a>
		  </div>
		</li>
		
		<li class="nav-item dropdown alert-dropdown">
		  <a href="#" class="nav-link dropdown-toggle no-caret" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span style="margin: -10px 0px; font-size: 16px;"><i class="fa fa-flag"></i> <div style="display: inline;" id="alerts"></div></span></a>
		  <div class="dropdown-menu alert-dropdown-menu">
		    <div id="alert_dropdown"><?php echo $_smarty_tpl->tpl_vars['LOADING']->value;?>
</div>
		    <div class="dropdown-divider"></div>
			<a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['ALERTS_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['VIEW_ALERTS']->value;?>
</a>
		  </div>
		</li>
		<?php }?>
	  
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['USER_AREA']->value, 'item', false, 'name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['name']->value => $_smarty_tpl->tpl_vars['item']->value) {
?>
		  <?php if (isset($_smarty_tpl->tpl_vars['item']->value['items'])) {?>
						<li class="nav-item dropdown">
			  <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
			  <div class="dropdown-menu">
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['item']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?>
				  <?php if (isset($_smarty_tpl->tpl_vars['dropdown']->value['separator'])) {?>
				    <div class="dropdown-divider"></div>
				  <?php } else { ?>
				    <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a>
				  <?php }?>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			  </div>
			</li>
		  <?php } else { ?>
						<li class="nav-item<?php if (isset($_smarty_tpl->tpl_vars['item']->value['active'])) {?> active<?php }?>" style="padding-right:10px;">
			  <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
			</li>
		  <?php }?>
		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

		<?php if (isset($_smarty_tpl->tpl_vars['USER_DROPDOWN']->value)) {?>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['USER_DROPDOWN']->value, 'item', false, 'name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['name']->value => $_smarty_tpl->tpl_vars['item']->value) {
?>
                <?php if (isset($_smarty_tpl->tpl_vars['item']->value['items'])) {?>
                    					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                            <?php if (isset($_smarty_tpl->tpl_vars['LOGGED_IN_USER']->value)) {?><img src="<?php echo $_smarty_tpl->tpl_vars['LOGGED_IN_USER']->value['avatar'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['LOGGED_IN_USER']->value['username'];?>
" class="img-rounded" style="max-height:25px;max-width:25px;"/><?php }?> <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>

						</a>
						<div class="dropdown-menu dropdown-menu-right">
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['item']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?>
                                <?php if (isset($_smarty_tpl->tpl_vars['dropdown']->value['separator'])) {?>
									<div class="dropdown-divider"></div>
                                <?php } else { ?>
									<a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a>
                                <?php }?>
                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
						</div>
					</li>
                <?php } else { ?>
                    					<li class="nav-item<?php if (isset($_smarty_tpl->tpl_vars['item']->value['active'])) {?> active<?php }?>" style="padding-right:10px;">
						<a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
					</li>
                <?php }?>
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		<?php }?>
	  </ul>
	</div>
  </div>
</nav>
<div class="container" style="padding-top: 2rem;">
		<?php if (isset($_smarty_tpl->tpl_vars['MAINTENANCE_ENABLED']->value)) {?>
		<div class="alert alert-danger alert-dismissible" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<i class="fa fa-exclamation-triangle"></i> <?php echo $_smarty_tpl->tpl_vars['MAINTENANCE_ENABLED']->value;?>

		</div>
	<?php }?>
	<?php if (isset($_smarty_tpl->tpl_vars['MUST_VALIDATE_ACCOUNT']->value)) {?>
		<div class="alert alert-info">
			<i class="fa fa-exclamation-triangle"></i> <?php echo $_smarty_tpl->tpl_vars['MUST_VALIDATE_ACCOUNT']->value;?>

		</div>
	<?php }?>
	
	<div class="alerts" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_ALERT']->value;?>
;">
	  <?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_ALERT_TEXT']->value)) {?>
		<br />
		<div class="alert alert-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_ALERT_TYPE']->value;?>
">
			<i class="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_ALERT_ICON']->value;?>
"></i> <?php echo $_smarty_tpl->tpl_vars['MINEBOX_ALERT_TEXT']->value;?>

		</div>
	  <?php }?>
	</div>

</div>

<div class="container">
  <div class="minebox-welcome" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_WELCOME']->value;?>
; border-radius: 10px; background-size: cover; height: 200px; width: 100%; padding: 50px; color: #fff;">
    <center>
	  <h2><?php echo $_smarty_tpl->tpl_vars['MINEBOX_WELCOME_TITLE']->value;?>
<h2>
	  <h3><?php echo $_smarty_tpl->tpl_vars['MINEBOX_WELCOME_DESC']->value;?>
<h3>
	  <a class="btn btn-primary" href="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_WELCOME_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['MINEBOX_WELCOME_BUTTON']->value;?>
</a>
    </center>
  </div>
</div>

<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value, $tmp) > 0) {?>
<br />
<div class="container">
  <center>
	<ins class="adsbygoogle" style="height:90px" data-ad-client="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value;?>
" data-ad-slot="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_SLOT']->value;?>
" data-ad-format="auto" data-full-width-responsive="true"></ins>
	<?php echo '<script'; ?>
>
		(adsbygoogle = window.adsbygoogle || []).push({});
	<?php echo '</script'; ?>
>
  </center>
</div>
<?php }?>

<div class="header_banner" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_HEADER_BANNER']->value;?>
;">
<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_HEADER_BANNER_IMG']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_HEADER_BANNER_IMG']->value, $tmp) > 0) {?>
<br />
<div class="container">
  <center>
	<a href="<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_HEADER_BANNER_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_HEADER_BANNER_LINK']->value, $tmp) > 0) {
echo $_smarty_tpl->tpl_vars['MINEBOX_HEADER_BANNER_LINK']->value;
} else { ?>#!<?php }?>" target="_blank" rel="nofollow">
		<img src="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_HEADER_BANNER_IMG']->value;?>
" style="max-width: 100%">
	</a>
  </center>
</div>
<br>
<?php }?>
</div><?php }
}
