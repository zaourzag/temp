<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:54:35
  from '/var/www/nameless/custom/templates/MineBox/404.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077f4b14efb8_20919855',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2e7b2af8f47a4a303dd7aa88a5930cc89fee8bd0' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/404.tpl',
      1 => 1611094418,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_60077f4b14efb8_20919855 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html<?php if (defined("HTML_CLASS")) {?> <?php echo @constant('HTML_CLASS');
}?> lang="<?php if (defined("HTML_LANG")) {
echo @constant('HTML_LANG');
} else { ?>en<?php }?>" <?php if (defined("HTML_RTL") && @constant('HTML_RTL') == true) {?> dir="rtl"<?php }?>>
<head>
	<!-- Standard Meta -->
	<meta charset="<?php if (defined("LANG_CHARSET")) {
echo @constant('LANG_CHARSET');
} else { ?>utf-8<?php }?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

	<!-- Site Properties -->
	<title><?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
</title>
	<meta name="author" content="<?php echo @constant('SITE_NAME');?>
">
	<meta name="theme-color" content="#06a9da">
	
	<?php if (isset($_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value, $tmp) > 0) {?>
		<meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value;?>
" />
	<?php }?>

	<?php if (isset($_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value, $tmp) > 0) {?>
		<meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value;?>
" />
	<?php }?>

	<meta property="og:title" content="<?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="<?php echo $_smarty_tpl->tpl_vars['OG_URL']->value;?>
" />
	<meta property="og:image" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_LOGO']->value;?>
'; <?php echo '?>';?>" />
	<link rel="shortcut icon" href="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_FAVICON']->value;?>
" />

	<?php if (isset($_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value, $tmp) > 0) {?>
		<meta property="og:description" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value;?>
" />
	<?php }?>

	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['TEMPLATE_CSS']->value, 'css');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['css']->value) {
?>
		<?php echo $_smarty_tpl->tpl_vars['css']->value;?>

	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

	<meta name="robots" content="noindex">

</head>

<body>
<?php $_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="container">
	<center><h1>404</h1></center>
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<div class="jumbotron">
				<center>
					<h2><?php echo $_smarty_tpl->tpl_vars['404_TITLE']->value;?>
</h2>
					<h4><?php echo $_smarty_tpl->tpl_vars['CONTENT']->value;?>
</h4>
					<div class="btn-group" role="group" aria-label="...">
						<button class="btn btn-primary btn-lg" onclick="javascript:history.go(-1)"><?php echo $_smarty_tpl->tpl_vars['BACK']->value;?>
</button>
						<a href="<?php echo $_smarty_tpl->tpl_vars['SITE_HOME']->value;?>
" class="btn btn-success btn-lg"><?php echo $_smarty_tpl->tpl_vars['HOME']->value;?>
</a>
					</div>
					<hr />
					<?php echo $_smarty_tpl->tpl_vars['ERROR']->value;?>

				</center>
			</div>
		</div>
	</div>
</div>
</body>
<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
</html><?php }
}
