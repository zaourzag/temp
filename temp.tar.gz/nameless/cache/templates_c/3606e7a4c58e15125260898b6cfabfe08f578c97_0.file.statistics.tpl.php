<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:43
  from '/var/www/nameless/custom/templates/Cesium/widgets/statistics.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c4760b4e1_93905385',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3606e7a4c58e15125260898b6cfabfe08f578c97' => 
    array (
      0 => '/var/www/nameless/custom/templates/Cesium/widgets/statistics.tpl',
      1 => 1611091459,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c4760b4e1_93905385 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="card card-default" id="widget-statistics">
	<div class="card-header">
		<i class="fas fa-chart-bar fa-fw"></i> <?php echo $_smarty_tpl->tpl_vars['STATISTICS']->value;?>

	</div>
	<div class="card-body">
		<div class="pairs">
			<?php if (isset($_smarty_tpl->tpl_vars['FORUM_STATISTICS']->value)) {?>
				<dl>
					<dt><?php echo $_smarty_tpl->tpl_vars['TOTAL_THREADS']->value;?>
</dt>
					<dd><?php echo $_smarty_tpl->tpl_vars['TOTAL_THREADS_VALUE']->value;?>
</dd>
				</dl>
				<dl>
					<dt><?php echo $_smarty_tpl->tpl_vars['TOTAL_POSTS']->value;?>
</dt>
					<dd><?php echo $_smarty_tpl->tpl_vars['TOTAL_POSTS_VALUE']->value;?>
</dd>
				</dl>
			<?php }?>
			<dl>
				<dt><?php echo $_smarty_tpl->tpl_vars['USERS_REGISTERED']->value;?>
</dt>
				<dd><?php echo $_smarty_tpl->tpl_vars['USERS_REGISTERED_VALUE']->value;?>
</dd>
			</dl>
			<dl>
				<dt><?php echo $_smarty_tpl->tpl_vars['GUESTS_ONLINE']->value;?>
</dt>
				<dd><?php echo $_smarty_tpl->tpl_vars['GUESTS_ONLINE_VALUE']->value;?>
</dd>
			</dl>
			<dl>
				<dt><?php echo $_smarty_tpl->tpl_vars['LATEST_MEMBER']->value;?>
</dt>
				<dd><a href="<?php echo $_smarty_tpl->tpl_vars['LATEST_MEMBER_VALUE']->value['profile'];?>
" style="<?php echo $_smarty_tpl->tpl_vars['LAST_MEMBER_VALUE']->value['style'];?>
" data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['LATEST_MEMBER_VALUE']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['LATEST_MEMBER_VALUE']->value['nickname'];?>
</a></dd>
			</dl>
		</div>
	</div>
</div><?php }
}
