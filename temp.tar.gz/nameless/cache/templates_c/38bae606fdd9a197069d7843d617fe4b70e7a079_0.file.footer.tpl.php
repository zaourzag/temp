<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:42:50
  from '/var/www/nameless/custom/templates/MineBox/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c8a7928d4_81137148',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '38bae606fdd9a197069d7843d617fe4b70e7a079' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/footer.tpl',
      1 => 1611094419,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c8a7928d4_81137148 (Smarty_Internal_Template $_smarty_tpl) {
?><br />
<?php if (isset($_smarty_tpl->tpl_vars['GLOBAL_WARNING_TITLE']->value)) {?>
	<div class="modal fade show-punishment" data-keyboard="false" data-backdrop="static" id="acknowledgeModal" tabindex="-1" role="dialog" aria-labelledby="acknowledgeModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title" id="acknowledgeModalLabel"><?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_TITLE']->value;?>
</h4>
				</div>
				<div class="modal-body">
					<?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_REASON']->value;?>

				</div>
				<div class="modal-footer">
					<a href="<?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_ACKNOWLEDGE_LINK']->value;?>
" class="btn btn-warning"><?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_ACKNOWLEDGE']->value;?>
</a>
				</div>
			</div>
		</div>
	</div>
<?php }?>

<div class="header_banner" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_FOOTER_BANNER']->value;?>
;">
<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_FOOTER_BANNER_IMG']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_FOOTER_BANNER_IMG']->value, $tmp) > 0) {?>
<br />
<div class="container">
  <center>
	<a href="<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_FOOTER_BANNER_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_FOOTER_BANNER_LINK']->value, $tmp) > 0) {
echo $_smarty_tpl->tpl_vars['MINEBOX_FOOTER_BANNER_LINK']->value;
} else { ?>#!<?php }?>" target="_blank" rel="nofollow">
		<img src="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_FOOTER_BANNER_IMG']->value;?>
" style="max-width: 100%;">
	</a>
  </center>
</div>
<?php }?>
</div>

<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value, $tmp) > 0) {?>
<div class="container">
  <center>
	<ins class="adsbygoogle" style="height:90px" data-ad-client="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value;?>
" data-ad-slot="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_SLOT']->value;?>
" data-ad-format="auto" data-full-width-responsive="true"></ins>
	<?php echo '<script'; ?>
>
		(adsbygoogle = window.adsbygoogle || []).push({});
	<?php echo '</script'; ?>
>
  </center>
</div>
<br />
<?php }?>

<footer class="page-footer font-small blue pt-4 footer-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
">

    <!-- Footer Links -->
    <div class="container container-fluid text-center text-md-left">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-4 mt-md-0 mt-3">

          <!-- Content -->
          <h5 class="text-uppercase white-text"><i class="fa fa-info-circle" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['SITE_NAME']->value;?>
</h5>
          <p class="white-text"><?php echo $_smarty_tpl->tpl_vars['MINEBOX_DESCRIPTION']->value;?>
</p>
						<?php if (!empty($_smarty_tpl->tpl_vars['SOCIAL_MEDIA_ICONS']->value)) {?>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['SOCIAL_MEDIA_ICONS']->value, 'icon');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['icon']->value) {
?>
				<a class="white-text" href="<?php echo $_smarty_tpl->tpl_vars['icon']->value['link'];?>
" target="_blank"><i id="social-<?php echo $_smarty_tpl->tpl_vars['icon']->value['short'];?>
" class="fa fa-<?php echo $_smarty_tpl->tpl_vars['icon']->value['long'];?>
-square fa-3x social"></i></a>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			<?php }?>
			<br>
			<?php if ($_smarty_tpl->tpl_vars['PAGE_LOAD_TIME']->value) {?>
			  <a class="white-text" href="#" onClick="return false;" data-toggle="tooltip" id="page_load_tooltip" title="Page loading.."><i class="fa fa-tachometer fa-fw fa-2x"></i></a>
		    <?php }?>
        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none pb-3">

        <!-- Grid column -->
		
        <div class="col-md-2 mb-md-0 mb-3">
		
            <!-- Links -->
            <h5 class="text-uppercase white-text"><i class="fa fa-link" style="width: auto;margin: 0 .75em 0 0;"></i> LINKS</h5>
            <ul class="list-unstyled">
			<?php if (!empty($_smarty_tpl->tpl_vars['FOOTER_NAVIGATION']->value)) {?>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['FOOTER_NAVIGATION']->value, 'item', false, 'name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['name']->value => $_smarty_tpl->tpl_vars['item']->value) {
?>
			  <?php if (isset($_smarty_tpl->tpl_vars['item']->value['items'])) {?>
								<li>
				  <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
					<div class="dropdown-menu">
					  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['item']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?>
						<a class="white-text dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a>
					  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
					</div>
				  </a>
				</li>
			  <?php } else { ?>
								<li>
				  <a class="white-text" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
				</li>
			  <?php }?>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			<?php }?>
            </ul>

          </div>
		  
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-2 mb-md-0 mb-3">

            <!-- Links -->
            <h5 class="text-uppercase white-text"><i class="fa fa-gavel" style="width: auto;margin: 0 .75em 0 0;"></i> LEGAL</h5>

            <ul class="list-unstyled">
              <li>
                <a class="white-text" href="<?php echo $_smarty_tpl->tpl_vars['PRIVACY_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['PRIVACY_TEXT']->value;?>
</a>
              </li>
              <li>
                <a class="white-text" href="<?php echo $_smarty_tpl->tpl_vars['TERMS_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['TERMS_TEXT']->value;?>
</a>
              </li>
            </ul>

          </div>
          <!-- Grid column -->
		  
        <!-- Grid column -->
        <div class="col-md-4 mt-md-0 mt-3">
			<img class="logo animated pulse infinite img-fluid" src="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_FLOGO']->value;?>
" alt="Logo" />
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
    <!-- Footer Links -->
	<br />
    <!-- Copyright -->
    <div class="footer-copyright text-center white-text" style="background: #00000061; line-height: 0px; padding-top: 20px; padding-bottom: 1px;">
        <p>Copyright &copy; <?php echo date('Y');?>
 <a href="/"><?php echo $_smarty_tpl->tpl_vars['SITE_NAME']->value;?>
</a>.</p>
		<p>Forum Software <a href="https://github.com/NamelessMC/Nameless" target="_blank">NamelessMC</a> By <a href="https://samerton.me/" target="_blank">Samerton</a> & Theme By <a href="https://speedmc.me" target="_blank">SpeedMC</a></p></div>
    </div>
    <!-- Copyright -->
	<a id="back-to-top" href="#"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>
</footer>


<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['TEMPLATE_JS']->value, 'script');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['script']->value) {
?>
	<?php echo $_smarty_tpl->tpl_vars['script']->value;?>

<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

<?php if (isset($_smarty_tpl->tpl_vars['NEW_UPDATE']->value)) {?>
	<?php if ($_smarty_tpl->tpl_vars['NEW_UPDATE_URGENT']->value != true) {?>
		<?php echo '<script'; ?>
 type="text/javascript">
            $(document).ready(function(){
                $('#closeUpdate').click(function(event){
                    event.preventDefault();

                    let expiry = new Date();
                    let length = 3600000;
                    expiry.setTime(expiry.getTime() + length);

                    $.cookie('update-alert-closed', 'true', { path: '/', expires: expiry });
                });

                if($.cookie('update-alert-closed') === 'true'){
                    $('#updateAlert').hide();
                }
            });
		<?php echo '</script'; ?>
>
	<?php }
}?>
</body>
</html><?php }
}
