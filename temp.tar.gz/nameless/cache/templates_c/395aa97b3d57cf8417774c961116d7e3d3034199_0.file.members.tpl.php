<?php
/* Smarty version 3.1.33, created on 2021-01-20 01:30:36
  from '/var/www/nameless/custom/templates/MineBox/members.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600787bcabf819_75996709',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '395aa97b3d57cf8417774c961116d7e3d3034199' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/members.tpl',
      1 => 1611094419,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 2,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_600787bcabf819_75996709 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="container">
  <div class="card">
	<div class="card-body">
	<div class="row">
	
	<?php if (!empty($_smarty_tpl->tpl_vars['WIDGETS']->value)) {?>
		<div class="col-md-9">
	<?php }?>
  
	<div class="col-12">
	  <div class="table-responsive">
	  <ul class="nav nav-tabs">
		<li class="nav-item">
		  <a href="<?php echo $_smarty_tpl->tpl_vars['ALL_LINK']->value;?>
" class="nav-link"><?php echo $_smarty_tpl->tpl_vars['DISPLAY_ALL']->value;?>
</a>
		</li>
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['GROUPS']->value, 'groups');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['groups']->value) {
?>
		<li class="nav-item">
		  <a href="<?php echo $_smarty_tpl->tpl_vars['groups']->value['grouplink'];?>
" class="nav-link"><?php echo $_smarty_tpl->tpl_vars['groups']->value['groupname'];?>
</a>
		</li>
		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	  </ul>
	  <br />
		<table class="table table-striped table-bordered table-hover dataTables-users" style="width:100%">
		  <thead>
			<tr>
			  <th><?php echo $_smarty_tpl->tpl_vars['USERNAME']->value;?>
</th>
			  <th><?php echo $_smarty_tpl->tpl_vars['GROUP']->value;?>
</th>
			  <th><?php echo $_smarty_tpl->tpl_vars['CREATED']->value;?>
</th>
			</tr>
		  </thead>
		  <tbody>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['MEMBERS']->value, 'member');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['member']->value) {
?>
			  <tr>
			    <td><a href="<?php echo $_smarty_tpl->tpl_vars['member']->value['profile'];?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['member']->value['avatar'];?>
" class="img-rounded" style="height:35px; width:35px;" alt="<?php echo $_smarty_tpl->tpl_vars['member']->value['nickname'];?>
" /></a> <a style="color:<?php echo $_smarty_tpl->tpl_vars['member']->value['group_colour'];?>
;" href="<?php echo $_smarty_tpl->tpl_vars['member']->value['profile'];?>
"><?php echo $_smarty_tpl->tpl_vars['member']->value['nickname'];?>
</a></td>
				<td><?php echo $_smarty_tpl->tpl_vars['member']->value['group'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['member']->value['joined'];?>
</td>
			  </tr>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		  </tbody>
		</table>
	  </div>
	</div>



	<?php if (!empty($_smarty_tpl->tpl_vars['WIDGETS']->value)) {?>
		</div>
		<div class="col-md-3">
		
<div class="googleads" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS']->value;?>
;">
<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value, $tmp) > 0) {?>
<br />
  <center>
	<ins class="adsbygoogle" data-ad-client="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value;?>
" data-ad-slot="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_SLOT']->value;?>
" data-ad-format="auto" data-full-width-responsive="true"></ins>
	<?php echo '<script'; ?>
>
		(adsbygoogle = window.adsbygoogle || []).push({});
	<?php echo '</script'; ?>
>
  </center>
<?php }?>
</div>

<div class="sidebar_banner" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER']->value;?>
;">
<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value, $tmp) > 0) {?>
<br />
  <center>
	<a href="<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value, $tmp) > 0) {
echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value;
} else { ?>#!<?php }?>" target="_blank" rel="nofollow">
		<img src="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value;?>
" style="max-width: 100%;">
	</a>
  </center>
<br />
<?php }?>
</div>

		
		  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['WIDGETS']->value, 'widget');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['widget']->value) {
?>
			<?php echo $_smarty_tpl->tpl_vars['widget']->value;?>
<br />
		  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</div>
	<?php }?>
	
	</div>
    </div>
  </div>
</div>

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
