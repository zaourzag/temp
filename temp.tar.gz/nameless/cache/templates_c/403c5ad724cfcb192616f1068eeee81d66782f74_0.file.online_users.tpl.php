<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:43
  from '/var/www/nameless/custom/templates/Cesium/widgets/online_users.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c476006e0_66466606',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '403c5ad724cfcb192616f1068eeee81d66782f74' => 
    array (
      0 => '/var/www/nameless/custom/templates/Cesium/widgets/online_users.tpl',
      1 => 1611091459,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c476006e0_66466606 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="card card-default" id="widget-onlineUsers">
	<div class="card-header">
		<i class="fas fa-users-cog fa-fw"></i> <?php echo $_smarty_tpl->tpl_vars['ONLINE_USERS']->value;?>

	</div>
	<div class="card-body">
		<div class="list list-inline">
			<?php if (isset($_smarty_tpl->tpl_vars['ONLINE_USERS_LIST']->value)) {?>
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ONLINE_USERS_LIST']->value, 'user');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
?>
					<div class="list-item">
						<div class="list-icon">
							<a href="<?php echo $_smarty_tpl->tpl_vars['user']->value['profile'];?>
">
								<img src="<?php echo $_smarty_tpl->tpl_vars['user']->value['avatar'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['user']->value['nickname'];?>
">
							</a>
						</div>
						<div class="list-content">
							<a href="<?php echo $_smarty_tpl->tpl_vars['user']->value['profile'];?>
" style="<?php echo $_smarty_tpl->tpl_vars['user']->value['style'];?>
" data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['user']->value['username'];?>
</a>
						</div>
					</div>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			<?php } else { ?>
				<?php echo $_smarty_tpl->tpl_vars['NO_USERS_ONLINE']->value;?>

			<?php }?>
		</div>
	</div>
	<div class="card-footer">
		<span><?php echo $_smarty_tpl->tpl_vars['TOTAL_ONLINE_USERS']->value;?>
</span>
	</div>
</div><?php }
}
