<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:42:50
  from '/var/www/nameless/custom/templates/MineBox/widgets/online_users.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c8a733853_47341668',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '424bc0b993be9e41ccae870c882409b8fe85cc2f' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/widgets/online_users.tpl',
      1 => 1611094424,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c8a733853_47341668 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="card panel-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
">
	<div class="collaps card-header text-white text-uppercase header-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
"><i class="fa fa-users" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['ONLINE_USERS']->value;?>
</div>
	<div class="content">
	<div class="card-body">
        <?php if (isset($_smarty_tpl->tpl_vars['ONLINE_USERS_LIST']->value)) {?>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ONLINE_USERS_LIST']->value, 'user', false, NULL, 'online_users_arr', array (
  'last' => true,
  'iteration' => true,
  'total' => true,
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
$_smarty_tpl->tpl_vars['__smarty_foreach_online_users_arr']->value['iteration']++;
$_smarty_tpl->tpl_vars['__smarty_foreach_online_users_arr']->value['last'] = $_smarty_tpl->tpl_vars['__smarty_foreach_online_users_arr']->value['iteration'] === $_smarty_tpl->tpl_vars['__smarty_foreach_online_users_arr']->value['total'];
?>
                <a style="<?php echo $_smarty_tpl->tpl_vars['user']->value['style'];?>
" href="<?php echo $_smarty_tpl->tpl_vars['user']->value['profile'];?>
" data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
" data-html="true" data-placement="top"><img src="<?php echo $_smarty_tpl->tpl_vars['user']->value['avatar'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['user']->value['nickname'];?>
" class="img-circle" style="max-height:20px;max-width:20px;"> <?php echo $_smarty_tpl->tpl_vars['user']->value['username'];?>
</a>
                <?php if (!(isset($_smarty_tpl->tpl_vars['__smarty_foreach_online_users_arr']->value['last']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_online_users_arr']->value['last'] : null)) {?>, <?php }?>
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        <?php } else { ?>
            <?php echo $_smarty_tpl->tpl_vars['NO_USERS_ONLINE']->value;?>

        <?php }?>
    </div>
	</div>
	<div class="panel-footer">
    <?php echo $_smarty_tpl->tpl_vars['TOTAL_ONLINE_USERS']->value;?>

	</div>
</div><?php }
}
