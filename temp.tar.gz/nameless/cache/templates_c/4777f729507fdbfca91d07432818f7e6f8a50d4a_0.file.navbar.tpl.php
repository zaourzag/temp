<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:34:31
  from '/var/www/nameless/custom/templates/Monarch/navbar.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077a9751d115_57890508',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4777f729507fdbfca91d07432818f7e6f8a50d4a' => 
    array (
      0 => '/var/www/nameless/custom/templates/Monarch/navbar.tpl',
      1 => 1611098705,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077a9751d115_57890508 (Smarty_Internal_Template $_smarty_tpl) {
?>
  <div class="ui masthead pusher" <?php if (isset($_smarty_tpl->tpl_vars['MONARCH_BG']->value)) {?> style="background-image:url('<?php echo $_smarty_tpl->tpl_vars['MONARCH_BG']->value;?>
');background-position:<?php echo $_smarty_tpl->tpl_vars['MONARCH_BG_POSITION']->value;?>
;background-size:cover;background-color:#000;"<?php }?>>
    <div class="ui container">
    <div class="ui stackable grid">
      <div class="ui middle aligned row">
        <div class="eight wide column">
          <a href="<?php echo $_smarty_tpl->tpl_vars['SITE_HOME']->value;?>
"><img class="logo animated pulse infinite img-fluid" src="<?php echo $_smarty_tpl->tpl_vars['MONARCH_LOGO']->value;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['SITE_NAME']->value;?>
"></a>
        </div>
        <div class="eight wide column">
          <?php if (isset($_smarty_tpl->tpl_vars['MINECRAFT']->value)) {?>
            <div class="connect-server">
		      <?php if (isset($_smarty_tpl->tpl_vars['SERVER_QUERY']->value)) {?>
		        <?php if (isset($_smarty_tpl->tpl_vars['SERVER_QUERY']->value['status_value']) && $_smarty_tpl->tpl_vars['SERVER_QUERY']->value['status_value'] == 1) {?>
			      <?php if (isset($_smarty_tpl->tpl_vars['SERVER_QUERY']->value['status_full'])) {?>
			   	    <h4 class="ui header"><?php echo $_smarty_tpl->tpl_vars['SERVER_QUERY']->value['status_full'];?>
</h4>
			      <?php } else { ?>
			        <h4 class="ui header"><?php echo $_smarty_tpl->tpl_vars['SERVER_QUERY']->value['x_players_online'];?>
</h4>
			      <?php }?>
		        <?php } else { ?>
		          <h4 class="ui header"><?php echo $_smarty_tpl->tpl_vars['SERVER_OFFLINE']->value;?>
</h4>
		        <?php }?>
            <?php } else { ?>
		          <h4 class="ui header" style="color:darkred;text-transform:uppercase;"><?php echo $_smarty_tpl->tpl_vars['SERVER_OFFLINE']->value;?>
</h4>
		      <?php }?>
		      <?php if (isset($_smarty_tpl->tpl_vars['CLICK_TO_COPY_TOOLTIP']->value)) {?>
		        <h4 class="ui header">
		          <span onclick="copy('#ip')" data-tooltip="<?php echo $_smarty_tpl->tpl_vars['CLICK_TO_COPY_TOOLTIP']->value;?>
" data-variation="mini" data-inverted="" data-position="bottom center"><?php echo $_smarty_tpl->tpl_vars['CONNECT_WITH']->value;?>
</span>
		        </h4>
		      <?php }?>
        </div>
	      <?php }?>
        </div>
      </div>
    </div>
    </div>
  </div>


<div class="ui vertical inverted sidebar menu left" id="toc" style="background:<?php echo $_smarty_tpl->tpl_vars['MONARCH_COLOR']->value;?>
">
  <div class="item"><h3><?php echo $_smarty_tpl->tpl_vars['SITE_NAME']->value;?>
</h3></div>
  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['NAV_LINKS']->value, 'item', false, 'name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['name']->value => $_smarty_tpl->tpl_vars['item']->value) {
?>
    <?php if (isset($_smarty_tpl->tpl_vars['item']->value['items'])) {?>
      <div class="ui pointing dropdown link item">
        <span class="text"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</span> <i class="dropdown icon"></i>
        <div class="menu">
          <div class="header"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</div>
          <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['item']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?>
            <a class="item" href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a>
          <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>
      </div>
    <?php } else { ?>
      <a class="item<?php if (isset($_smarty_tpl->tpl_vars['item']->value['active'])) {?> active<?php }?>" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
    <?php }?>
  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</div>

<div class="pusher">
    <div id="wrapper">
  <div class="ui top fixed">
    <div class="ui secondary small menu" id="navbar" style="background:<?php echo $_smarty_tpl->tpl_vars['MONARCH_COLOR']->value;?>
">
      <div class="ui container">
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['NAV_LINKS']->value, 'item', false, 'name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['name']->value => $_smarty_tpl->tpl_vars['item']->value) {
?>
          <?php if (isset($_smarty_tpl->tpl_vars['item']->value['items'])) {?>
            <div class="ui pointing dropdown link item">
              <span class="text"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</span> <i class="dropdown icon"></i>
              <div class="menu">
                <div class="header"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</div>
                  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['item']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?>
				    <?php if (isset($_smarty_tpl->tpl_vars['dropdown']->value['seperator'])) {?>
				      <div class="divider"></div>
				    <?php } else { ?>
				      <a class="item" href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a>
				    <?php }?>
				  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
              </div>
            </div>
          <?php } else { ?>
            <a class="item<?php if (isset($_smarty_tpl->tpl_vars['item']->value['active'])) {?> active<?php }?>" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
          <?php }?>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        <a class="toc item">
          <i class="sidebar icon"></i>
        </a>
        <div class="right menu">
          <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['USER_SECTION']->value, 'item', false, 'name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['name']->value => $_smarty_tpl->tpl_vars['item']->value) {
?>
		    <?php if (isset($_smarty_tpl->tpl_vars['item']->value['items'])) {?>
              <?php if (($_smarty_tpl->tpl_vars['name']->value == "alerts") || ($_smarty_tpl->tpl_vars['name']->value == "pms")) {?>
		        <a class="ui small default icon button" data-toggle="popup" data-position="bottom right" id="button-<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
</a>
		        <div class="ui wide basic popup">
                  <h4 class="ui header"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</h4>
                  <div class="ui relaxed link list" id="list-<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
">
				    <a class="item"><?php echo $_smarty_tpl->tpl_vars['LOADING']->value;?>
</a>
                  </div>
                  <div class="ui link list">
				    <div class="ui divider"></div>
				    <a class="item" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['meta'];?>
</a>
                  </div>
                </div>
              <?php } elseif (($_smarty_tpl->tpl_vars['name']->value == "account")) {?>
		        <a class="ui medium image label" data-toggle="popup" data-position="bottom right" id="button-<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
">
		          <img src="<?php echo $_smarty_tpl->tpl_vars['LOGGED_IN_USER']->value['avatar'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['LOGGED_IN_USER']->value['username'];?>
"> <?php echo $_smarty_tpl->tpl_vars['LOGGED_IN_USER']->value['username'];?>

		        </a>
		        <div class="ui wide basic popup">
                  <h4 class="ui header"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</h4>
                  <div class="ui relaxed link list" id="list-<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
">
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['item']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?>
				      <?php if (isset($_smarty_tpl->tpl_vars['dropdown']->value['seperator'])) {?>
				        <div class="ui divider"></div>
				      <?php } else { ?>
				        <a class="item" href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a>
				      <?php }?>
				    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                  </div>
                </div>
              <?php }?>
		    <?php } else { ?>
		      <?php if (($_smarty_tpl->tpl_vars['name']->value == "panel")) {?>
		        <a class="ui small primary icon button" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
</a>
		      <?php } elseif (($_smarty_tpl->tpl_vars['name']->value == "register")) {?>
		        <a class="ui small primary button" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
		      <?php } else { ?>
		        <a class="ui small default button" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
		      <?php }?>
		    <?php }?>
		  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>
      </div>
    </div>
  </div>

    <div class="ui container intro">
	    <?php if (isset($_smarty_tpl->tpl_vars['NEW_UPDATE']->value)) {?>
      <?php if ($_smarty_tpl->tpl_vars['NEW_UPDATE_URGENT']->value == true) {?>
        <div class="ui negative message">
      <?php } else { ?>
      <div class="ui blue message">
        <i class="close icon"></i>
      <?php }?>
        <div class="header"><?php echo $_smarty_tpl->tpl_vars['NEW_UPDATE']->value;?>
</div>
	    <p><?php echo $_smarty_tpl->tpl_vars['CURRENT_VERSION']->value;?>
 &middot; <?php echo $_smarty_tpl->tpl_vars['NEW_VERSION']->value;?>
 &middot; <a href="<?php echo $_smarty_tpl->tpl_vars['UPDATE_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['UPDATE']->value;?>
</a></p>
      </div>
    <?php }
}
}
