<?php
/* Smarty version 3.1.33, created on 2021-01-20 01:19:31
  from '/var/www/nameless/custom/templates/MineBox/user/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60078523f2af75_91334677',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '48d4796db428fa84e13450f72e4b061abdcca567' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/user/index.tpl',
      1 => 1611094424,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:user/navigation.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_60078523f2af75_91334677 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="container" style="padding-top: 2rem;">
  <div class="row">
	<div class="col-md-3">
	  <?php $_smarty_tpl->_subTemplateRender('file:user/navigation.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
	</div>
	<div class="col-md-9">
	  <div class="card">
		<div class="card-body">
		  <h2 class="card-title"><i class="fa fa-user" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['OVERVIEW']->value;?>
</h2>
		  <ul>
			
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['USER_DETAILS_VALUES']->value, 'value', false, 'name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['name']->value => $_smarty_tpl->tpl_vars['value']->value) {
?>
			<li>
			  <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
: <strong><?php echo $_smarty_tpl->tpl_vars['value']->value;?>
</strong>
			</li>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			
		  </ul>
		  <hr>
		  <?php if (isset($_smarty_tpl->tpl_vars['FORUM_GRAPH']->value)) {?>
			<div id="chartWrapper">
			  <h3 class="ui header"><i class="fa fa-line-chart"></i> <?php echo $_smarty_tpl->tpl_vars['FORUM_GRAPH']->value;?>
</h3>
			  <canvas id="dataChart" width="100%" height="40"></canvas>
			</div>
		  <?php }?>
		</div>
	  </div>
	</div>
  </div>
</div>

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
