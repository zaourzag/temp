<?php
/* Smarty version 3.1.33, created on 2021-01-20 02:19:33
  from '/var/www/nameless/custom/panel_templates/Default/members/members.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600793359626e0_16627394',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '534baeff2996d794817aedf0e840a51e674583bf' => 
    array (
      0 => '/var/www/nameless/custom/panel_templates/Default/members/members.tpl',
      1 => 1611098705,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:sidebar.tpl' => 1,
    'file:footer.tpl' => 1,
    'file:scripts.tpl' => 1,
  ),
),false)) {
function content_600793359626e0_16627394 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <?php $_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <?php $_smarty_tpl->_subTemplateRender('file:sidebar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
	
	<div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark"><?php echo $_smarty_tpl->tpl_vars['MEMBERS']->value;?>
</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo $_smarty_tpl->tpl_vars['PANEL_INDEX']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['DASHBOARD']->value;?>
</a></li>
                            <li class="breadcrumb-item active"><?php echo $_smarty_tpl->tpl_vars['MEMBERS']->value;?>
</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
		
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php if (isset($_smarty_tpl->tpl_vars['NEW_UPDATE']->value)) {?>
                <?php if ($_smarty_tpl->tpl_vars['NEW_UPDATE_URGENT']->value == true) {?>
                <div class="alert alert-danger">
                    <?php } else { ?>
                    <div class="alert alert-primary alert-dismissible" id="updateAlert">
                        <button type="button" class="close" id="closeUpdate" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    <?php }?>
                    <?php echo $_smarty_tpl->tpl_vars['NEW_UPDATE']->value;?>

                    <br />
                    <a href="<?php echo $_smarty_tpl->tpl_vars['UPDATE_LINK']->value;?>
" class="btn btn-primary" style="text-decoration:none"><?php echo $_smarty_tpl->tpl_vars['UPDATE']->value;?>
</a>
                    <hr />
                    <?php echo $_smarty_tpl->tpl_vars['CURRENT_VERSION']->value;?>
<br />
                    <?php echo $_smarty_tpl->tpl_vars['NEW_VERSION']->value;?>

                </div>
                <?php }?>
				
                <div class="card">
                    <div class="card-body">
						<form action="" method="post">
                            <div class="form-group">
                                <label for="link_location"><?php echo $_smarty_tpl->tpl_vars['LINK_LOCATION']->value;?>
</label>
                                <select class="form-control" id="link_location" name="link_location">
                                    <option value="1"<?php if ($_smarty_tpl->tpl_vars['LINK_LOCATION_VALUE']->value == 1) {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['LINK_NAVBAR']->value;?>
</option>
                                    <option value="2"<?php if ($_smarty_tpl->tpl_vars['LINK_LOCATION_VALUE']->value == 2) {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['LINK_MORE']->value;?>
</option>
                                    <option value="3"<?php if ($_smarty_tpl->tpl_vars['LINK_LOCATION_VALUE']->value == 3) {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['LINK_FOOTER']->value;?>
</option>
                                    <option value="4"<?php if ($_smarty_tpl->tpl_vars['LINK_LOCATION_VALUE']->value == 4) {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['LINK_NONE']->value;?>
</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="inputIcon"><?php echo $_smarty_tpl->tpl_vars['ICON']->value;?>
</label>
                                <input type="text" class="form-control" name="icon" id="inputIcon" placeholder="<?php echo $_smarty_tpl->tpl_vars['ICON_EXAMPLE']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['ICON_VALUE']->value;?>
">
                            </div>
                            <div class="form-group">
                                <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
                                <input type="submit" class="btn btn-primary" value="<?php echo $_smarty_tpl->tpl_vars['SUBMIT']->value;?>
">
                            </div>
						</form>
					</div>
				</div>
					
            </div>
        </section>
	</div>
	
    <?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</div>
<!-- ./wrapper -->

<?php $_smarty_tpl->_subTemplateRender('file:scripts.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>
</html><?php }
}
