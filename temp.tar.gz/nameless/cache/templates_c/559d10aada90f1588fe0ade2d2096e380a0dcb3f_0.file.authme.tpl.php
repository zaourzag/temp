<?php
/* Smarty version 3.1.33, created on 2021-01-20 01:30:59
  from '/var/www/nameless/custom/templates/MineBox/authme.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600787d327b864_78591550',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '559d10aada90f1588fe0ade2d2096e380a0dcb3f' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/authme.tpl',
      1 => 1611094418,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_600787d327b864_78591550 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="container">
  <div class="card">
    <div class="card-body">
	  <form action="" method="post">
	    <h2><?php echo $_smarty_tpl->tpl_vars['CONNECT_WITH_AUTHME']->value;?>
</h2>
        <hr />
		
		<?php if (isset($_smarty_tpl->tpl_vars['ERRORS']->value)) {?>
		  <div class="alert alert-danger">
		    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ERRORS']->value, 'error');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['error']->value) {
?>
                <?php echo $_smarty_tpl->tpl_vars['error']->value;?>
<br />
		    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		  </div>
		<?php }?>

		<div class="alert alert-info">
			<?php echo $_smarty_tpl->tpl_vars['AUTHME_INFO']->value;?>

		</div>

		<div class="form-group">
			<label for="inputUsername"><?php echo $_smarty_tpl->tpl_vars['USERNAME']->value;?>
</label>
			<input type="text" id="inputUsername" name="username" class="form-control" placeholder="<?php echo $_smarty_tpl->tpl_vars['USERNAME']->value;?>
">
		</div>

		<div class="form-group">
			<label for="inputPassword"><?php echo $_smarty_tpl->tpl_vars['PASSWORD']->value;?>
</label>
			<input type="password" id="inputPassword" name="password" class="form-control" placeholder="<?php echo $_smarty_tpl->tpl_vars['PASSWORD']->value;?>
">
		</div>

        <?php if (isset($_smarty_tpl->tpl_vars['RECAPTCHA']->value)) {?>
        <div class="form-group">
            <center>
              <div class="g-recaptcha" data-sitekey="<?php echo $_smarty_tpl->tpl_vars['RECAPTCHA']->value;?>
"></div>
            </center>
        </div>
        <?php }?>

        <hr />
        <?php echo $_smarty_tpl->tpl_vars['AGREE_TO_TERMS']->value;?>

        <br />
		<span class="button-checkbox">
		  <button type="button" class="btn" data-color="info" tabindex="7"> <?php echo $_smarty_tpl->tpl_vars['I_AGREE']->value;?>
</button>
		  <input type="checkbox" name="t_and_c" id="t_and_c" style="display:none;" value="1">
		</span>


        <br />

	    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
	    <br />
	    <input type="submit" value="<?php echo $_smarty_tpl->tpl_vars['SUBMIT']->value;?>
" class="btn btn-success">
	  </form>
	</div>
  </div>
</div>

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
