<?php
/* Smarty version 3.1.33, created on 2021-01-20 01:30:14
  from '/var/www/nameless/custom/templates/MineBox/forum/forum_index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600787a6f00bb3_49052525',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '579b4742266045102c7ff33a45b857f5b6c5a472' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/forum/forum_index.tpl',
      1 => 1611094420,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_600787a6f00bb3_49052525 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="container">
<div class="card">
  <div class="card-body">
	  <div class="row">
		<div class="col-md-9">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item active"><a href="<?php echo $_smarty_tpl->tpl_vars['BREADCRUMB_URL']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['BREADCRUMB_TEXT']->value;?>
</a></li>
		  </ol>
		  
		  <?php if (isset($_smarty_tpl->tpl_vars['SPAM_INFO']->value)) {?>
		  <div class="alert alert-info"><?php echo $_smarty_tpl->tpl_vars['SPAM_INFO']->value;?>
</div>
		  <?php }?>
		  
		  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['FORUMS']->value, 'forum', false, 'category');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['category']->value => $_smarty_tpl->tpl_vars['forum']->value) {
?>
		    <?php $_smarty_tpl->_assignInScope('counter', 1);?>
		    <div class="card panel-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
">
		    <?php if (!empty($_smarty_tpl->tpl_vars['forum']->value['subforums'])) {?>
			  <div class="collaps card-header text-white text-uppercase header-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
"><?php ob_start();
echo $_smarty_tpl->tpl_vars['forum']->value['icon'];
$_prefixVariable1 = ob_get_clean();
if (empty($_prefixVariable1)) {?><i class="fa fa-folder-open" style="width: auto;margin: 0 .75em 0 0;"></i><?php } else {
echo $_smarty_tpl->tpl_vars['forum']->value['icon'];
}?> <a href="#<?php echo $_smarty_tpl->tpl_vars['forum']->value['title'];?>
" data-toggle="tooltip" data-placement="right" title="<?php echo $_smarty_tpl->tpl_vars['forum']->value['description'];?>
"><strong><?php echo $_smarty_tpl->tpl_vars['forum']->value['title'];?>
</strong></a></div>
			  <div class="content">
			  <div class="card-body">
			  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['forum']->value['subforums'], 'subforum');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['subforum']->value) {
?>
			    <div class="row align-items-center">
					<div class="col-md-1">
						<?php if (empty($_smarty_tpl->tpl_vars['subforum']->value->icon)) {?><i class="fa fa-comments-o fa-fw fa-2x" style="width: auto;margin: 0 .75em 0 0;"></i><?php } else {
echo $_smarty_tpl->tpl_vars['subforum']->value->icon;
}?>
					</div>
				  <div class="col-md-5">
				    <a data-toggle="tooltip" data-placement="right" title="<?php echo $_smarty_tpl->tpl_vars['subforum']->value->forum_description;?>
" href="<?php if (!isset($_smarty_tpl->tpl_vars['subforum']->value->redirect_confirm)) {
echo $_smarty_tpl->tpl_vars['subforum']->value->link;
} else { ?>#" data-toggle="modal" data-target="#confirmRedirectModal<?php echo $_smarty_tpl->tpl_vars['subforum']->value->id;
}?>"><?php echo $_smarty_tpl->tpl_vars['subforum']->value->forum_title;?>
</a>
				 
				  </div>
				  <?php if (!isset($_smarty_tpl->tpl_vars['subforum']->value->redirect_confirm)) {?>
				   <div class="col-md-2">
				    <i class="fa fa-edit" style="width: auto;margin: 0 .75em 0 0;"></i> <span><?php echo $_smarty_tpl->tpl_vars['subforum']->value->topics;?>
 <?php echo $_smarty_tpl->tpl_vars['TOPICS']->value;?>
</span><br> 
					<i class="fa fa-comments" style="width: auto;margin: 0 .75em 0 0;"></i> <span><?php echo $_smarty_tpl->tpl_vars['subforum']->value->posts;?>
 <?php echo $_smarty_tpl->tpl_vars['POSTS']->value;?>
</span> 
				  </div>
				  <div class="col-md-4">
				    <?php if (isset($_smarty_tpl->tpl_vars['subforum']->value->last_post)) {?>
					<div class="row align-items-center">
				      <div class="col-md-3">
						<div class="frame">
						  <a href="<?php echo $_smarty_tpl->tpl_vars['subforum']->value->last_post->profile;?>
"><img alt="<?php echo $_smarty_tpl->tpl_vars['subforum']->value->last_post->profile;?>
" style="height:40px; width:40px;" class="img-centre rounded" src="<?php echo $_smarty_tpl->tpl_vars['subforum']->value->last_post->avatar;?>
" /></a>
						</div>
					  </div>
					  <div class="col-md-9">
					    <a href="<?php echo $_smarty_tpl->tpl_vars['subforum']->value->last_post->link;?>
"><?php echo $_smarty_tpl->tpl_vars['subforum']->value->last_post->title;?>
</a>
					    <br />
					    <span data-toggle="tooltip" data-trigger="hover" data-original-title="<?php echo $_smarty_tpl->tpl_vars['subforum']->value->last_post->post_date;?>
"><?php echo $_smarty_tpl->tpl_vars['subforum']->value->last_post->date_friendly;?>
</span><br /><?php echo $_smarty_tpl->tpl_vars['BY']->value;?>
 <a data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['subforum']->value->last_post->post_creator;?>
" data-html="true" data-placement="top" style="<?php echo $_smarty_tpl->tpl_vars['subforum']->value->last_post->user_style;?>
" href="<?php echo $_smarty_tpl->tpl_vars['subforum']->value->last_post->profile;?>
"><?php echo $_smarty_tpl->tpl_vars['subforum']->value->last_post->username;?>
</a>
					  </div>
					</div>
					<?php } else { ?>
					<?php echo $_smarty_tpl->tpl_vars['NO_TOPICS']->value;?>

					<?php }?>
				  </div>
				  <?php } else { ?>
				    <div class="modal fade" id="confirmRedirectModal<?php echo $_smarty_tpl->tpl_vars['subforum']->value->id;?>
" tabindex="-1" role="dialog" aria-hidden="true">
				      <div class="modal-dialog" role="document">
				        <div class="modal-content">
				          <div class="modal-body">
				            <?php echo $_smarty_tpl->tpl_vars['subforum']->value->redirect_confirm;?>

				          </div>
				          <div class="modal-footer">
				            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo $_smarty_tpl->tpl_vars['NO']->value;?>
</button>
				            <a class="btn btn-primary" href="<?php echo $_smarty_tpl->tpl_vars['subforum']->value->redirect_url;?>
" target="_blank" rel="noopener nofollow"><?php echo $_smarty_tpl->tpl_vars['YES']->value;?>
</a>
				          </div>
				        </div>
				      </div>
				    </div>
				  <?php }?>
				</div>
				<?php if (isset($_smarty_tpl->tpl_vars['subforum']->value->subforums)) {?>
				  <br />
				  <?php $_smarty_tpl->_assignInScope('sf_counter', 1);?>
				  <div class="row">
				  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['subforum']->value->subforums, 'sub_subforum');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['sub_subforum']->value) {
?>
				    <div class="col-md-4">
				      <?php if (empty($_smarty_tpl->tpl_vars['sub_subforum']->value->icon)) {?><i class="fa fa-folder-open" style="width: auto;margin: 0 .75em 0 0;"></i><?php } else {
echo $_smarty_tpl->tpl_vars['sub_subforum']->value->icon;
}?>&nbsp;&nbsp;<a href="<?php echo $_smarty_tpl->tpl_vars['sub_subforum']->value->link;?>
"><?php echo $_smarty_tpl->tpl_vars['sub_subforum']->value->title;?>
</a>
				      <?php $_smarty_tpl->_assignInScope('sf_counter', $_smarty_tpl->tpl_vars['sf_counter']->value+1);?>
				    </div>
				    <?php if ($_smarty_tpl->tpl_vars['sf_counter']->value == 4) {?>
				      </div>
				      <div class="row">
				    <?php }?>
				  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				  </div>
				<?php }?>
				<?php if ((count($_smarty_tpl->tpl_vars['forum']->value['subforums'])) != $_smarty_tpl->tpl_vars['counter']->value) {?>
				<hr />
				<?php }?>
				<?php $_smarty_tpl->_assignInScope('counter', $_smarty_tpl->tpl_vars['counter']->value+1);?>
			  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			  </div>
			  </div>
		    <?php }?>
			</div>
			<br />
		  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</div>
		<div class="col-md-3">
		
		  <form class="form-horizontal" role="form" method="post" action="<?php echo $_smarty_tpl->tpl_vars['SEARCH_URL']->value;?>
">
		    <div class="input-group">
			  <input type="text" class="form-control input-sm" name="forum_search" placeholder="<?php echo $_smarty_tpl->tpl_vars['SEARCH']->value;?>
">
			  <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
			  <div class="input-group-append">
			    <button class="btn btn-success" type="submit"><i class="fa fa-search"></i></button>
			  </div>
		    </div>
		  </form>

<div class="googleads" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS']->value;?>
;">
<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value, $tmp) > 0) {?>
<br />
  <center>
	<ins class="adsbygoogle" data-ad-client="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value;?>
" data-ad-slot="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_SLOT']->value;?>
" data-ad-format="auto" data-full-width-responsive="true"></ins>
	<?php echo '<script'; ?>
>
		(adsbygoogle = window.adsbygoogle || []).push({});
	<?php echo '</script'; ?>
>
  </center>
<?php }?>
</div>

<div class="sidebar_banner" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER']->value;?>
;">
<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value, $tmp) > 0) {?>
<br />
  <center>
	<a href="<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value, $tmp) > 0) {
echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value;
} else { ?>#!<?php }?>" target="_blank" rel="nofollow">
		<img src="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value;?>
" style="max-width: 100%;">
	</a>
  </center>
<br />
<?php }?>
</div>

		  <?php if (count($_smarty_tpl->tpl_vars['WIDGETS']->value)) {?>
		    <br />
		    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['WIDGETS']->value, 'widget');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['widget']->value) {
?>
		    <?php echo $_smarty_tpl->tpl_vars['widget']->value;?>

		    <br />
		    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		  <?php }?>
		</div>
	  </div>
  </div>
</div>
</div>
<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
