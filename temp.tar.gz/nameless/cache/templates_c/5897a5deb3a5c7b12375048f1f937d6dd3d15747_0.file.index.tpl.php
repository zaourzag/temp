<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:17
  from '/var/www/nameless/custom/templates/Aether/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c2d699092_46176068',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5897a5deb3a5c7b12375048f1f937d6dd3d15747' => 
    array (
      0 => '/var/www/nameless/custom/templates/Aether/index.tpl',
      1 => 1599551084,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_60077c2d699092_46176068 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?> <?php $_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="container">
    <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER1_TITLE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER1_TITLE']->value, $tmp) > 0) {?>
    <div class="carousel slide" style="padding-bottom: 1rem; border-radius: 5px 5px 5px 5px; overflow: hidden;" id="carousel" data-ride="carousel">
        <ol class="carousel-indicators">
            <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER1_TITLE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER1_TITLE']->value, $tmp) > 0) {?>
            <li data-target="#carousel" data-slide-to="0" class="active"></li><?php }?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER2_TITLE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER2_TITLE']->value, $tmp) > 0) {?>
            <li data-target="#carousel" data-slide-to="1"></li><?php }?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER3_TITLE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER3_TITLE']->value, $tmp) > 0) {?>
            <li data-target="#carousel" data-slide-to="2"></li><?php }?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER4_TITLE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER4_TITLE']->value, $tmp) > 0) {?>
            <li data-target="#carousel" data-slide-to="3"></li><?php }?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER5_TITLE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER5_TITLE']->value, $tmp) > 0) {?>
            <li data-target="#carousel" data-slide-to="4"></li><?php }?>
        </ol>
        <div class="carousel-inner">
            <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER1_TITLE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER1_TITLE']->value, $tmp) > 0) {?>
            <div class="carousel-item active">
                <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER1_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER1_LINK']->value, $tmp) > 0) {?><a href="<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER1_LINK']->value;?>
"><?php }?>
                    <img src="<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER1_IMAGE']->value;?>
" class="d-block w-100" alt="Slide #1">
                    <div class="carousel-caption d-none d-md-block">
                        <h1 style="color:<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER1_TCOLOR']->value;?>
"><b><?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER1_TITLE']->value;?>
</b></h1>
                        <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER1_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER1_DESCRIPTION']->value, $tmp) > 0) {?>
				<p class="col-inv" style="color:<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER1_DCOLOR']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER1_DESCRIPTION']->value;?>
</p>
			<?php }?>
                    </div>
                <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER1_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER1_LINK']->value, $tmp) > 0) {?></a><?php }?>
            </div>
            <?php }?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER2_TITLE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER2_TITLE']->value, $tmp) > 0) {?>
            <div class="carousel-item">
                <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER2_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER2_LINK']->value, $tmp) > 0) {?><a href="<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER2_LINK']->value;?>
"><?php }?>
                    <img src="<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER2_IMAGE']->value;?>
" class="d-block w-100" alt="Slide #2">
                    <div class="carousel-caption d-none d-md-block">
                        <h1 style="color:<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER2_TCOLOR']->value;?>
"><b><?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER2_TITLE']->value;?>
</b></h1>
                        <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER2_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER2_DESCRIPTION']->value, $tmp) > 0) {?>
				<p class="col-inv" style="color:<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER2_DCOLOR']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER2_DESCRIPTION']->value;?>
</p>
			<?php }?>
                    </div>
                <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER2_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER2_LINK']->value, $tmp) > 0) {?></a><?php }?>
            </div>
            <?php }?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER3_TITLE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER3_TITLE']->value, $tmp) > 0) {?>
            <div class="carousel-item">
                <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER3_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER3_LINK']->value, $tmp) > 0) {?><a href="<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER3_LINK']->value;?>
"><?php }?>
                    <img src="<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER3_IMAGE']->value;?>
" class="d-block w-100" alt="Slide #3">
                    <div class="carousel-caption d-none d-md-block">
                        <h1 style="color:<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER3_TCOLOR']->value;?>
"><b><?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER3_TITLE']->value;?>
</b></h1>
                        <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER3_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER3_DESCRIPTION']->value, $tmp) > 0) {?>
				<p class="col-inv" style="color:<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER3_DCOLOR']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER3_DESCRIPTION']->value;?>
</p>
			<?php }?>
                    </div>
                <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER3_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER3_LINK']->value, $tmp) > 0) {?></a><?php }?>
            </div>
            <?php }?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER4_TITLE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER4_TITLE']->value, $tmp) > 0) {?>
            <div class="carousel-item">
                <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER4_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER4_LINK']->value, $tmp) > 0) {?><a href="<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER4_LINK']->value;?>
"><?php }?>
                    <img src="<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER4_IMAGE']->value;?>
" class="d-block w-100" alt="Slide #4">
                    <div class="carousel-caption d-none d-md-block">
                        <h1 style="color:<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER4_TCOLOR']->value;?>
"><b><?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER4_TITLE']->value;?>
</b></h1>
                        <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER4_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER4_DESCRIPTION']->value, $tmp) > 0) {?>
				<p class="col-inv" style="color:<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER4_DCOLOR']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER4_DESCRIPTION']->value;?>
</p>
			<?php }?>
                    </div>
                <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER4_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER4_LINK']->value, $tmp) > 0) {?></a><?php }?>
            </div>
            <?php }?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER5_TITLE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER5_TITLE']->value, $tmp) > 0) {?>
            <div class="carousel-item">
                <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER5_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER5_LINK']->value, $tmp) > 0) {?><a href="<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER5_LINK']->value;?>
"><?php }?>
                    <img src="<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER5_IMAGE']->value;?>
" class="d-block w-100" alt="Slide #5">
                    <div class="carousel-caption d-none d-md-block">
                        <h1 style="color:<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER5_TCOLOR']->value;?>
"><b><?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER5_TITLE']->value;?>
</b></h1>
                        <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER5_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER5_DESCRIPTION']->value, $tmp) > 0) {?>
				<p class="col-inv" style="color:<?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER5_DCOLOR']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['THEME_SLIDER5_DESCRIPTION']->value;?>
</p>
			<?php }?>
                    </div>
                <?php if (isset($_smarty_tpl->tpl_vars['THEME_SLIDER5_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_SLIDER5_LINK']->value, $tmp) > 0) {?></a><?php }?>
            </div>
            <?php }?>
        </div>
    </div>
    <?php }?>
</div>
<div class="home-news">
    <div class="container">
        <?php if (isset($_smarty_tpl->tpl_vars['HOME_SESSION_FLASH']->value)) {?>
        <div class="alert alert-info">
            <?php echo $_smarty_tpl->tpl_vars['HOME_SESSION_FLASH']->value;?>

        </div>
        <?php }?> <?php if (isset($_smarty_tpl->tpl_vars['HOME_SESSION_ERROR_FLASH']->value)) {?>
        <div class="alert alert-danger">
            <?php echo $_smarty_tpl->tpl_vars['HOME_SESSION_ERROR_FLASH']->value;?>

        </div>
        <?php }?>
        <div class="row">
            <?php if (isset($_smarty_tpl->tpl_vars['NEWS']->value)) {?>
            <div class="col-md-9">
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['NEWS']->value, 'item');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['item']->value) {
?>
                <div class="card">
                    <div class="card-header header-theme">
                        <i class="fas fa-newspaper"></i>&nbsp;<?php if ($_smarty_tpl->tpl_vars['item']->value['label']) {
echo $_smarty_tpl->tpl_vars['item']->value['label'];?>
 <?php }?><a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['url'];?>
"><b><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</b></a> &bull;&nbsp;
                        <i class="fas fa-pen-alt"></i>&nbsp;<a data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['item']->value['author_id'];?>
" data-html="true" data-placement="top" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_url'];?>
" style="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_style'];?>
"><b><?php echo $_smarty_tpl->tpl_vars['item']->value['author_name'];?>
</b></a><br class="news-right-br" />
                        <span class="news-right">
                        <i class="fas fa-eye"></i>&nbsp;<b><?php echo $_smarty_tpl->tpl_vars['item']->value['views'];?>
&nbsp;&bull;&nbsp;</b><span data-toggle="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['item']->value['date'];?>
"><i class="fas fa-user-clock"></i>&nbsp;<b><?php echo $_smarty_tpl->tpl_vars['item']->value['time_ago'];?>
</b></span></span>
                    </div>
                    <div class="card-block forum_post">
                        <?php echo $_smarty_tpl->tpl_vars['item']->value['content'];?>

                    </div>
                    <div class="card-footer footer-card-theme">
                        <a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['url'];?>
" class="btn btn-news-theme btn-sm"><?php echo $_smarty_tpl->tpl_vars['READ_FULL_POST']->value;?>
 &raquo;</a>
                    </div>
                </div>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </div>
            <div class="col-md-3">
                <?php } else { ?>
                <div class="col-md-4 offset-md-4">
                    <?php }?> <?php if (count($_smarty_tpl->tpl_vars['WIDGETS']->value)) {?> <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['WIDGETS']->value, 'widget');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['widget']->value) {
?> <?php echo $_smarty_tpl->tpl_vars['widget']->value;?>
 <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?> <?php }?>
                </div>
            </div>
        </div>
    </div>
    <?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
