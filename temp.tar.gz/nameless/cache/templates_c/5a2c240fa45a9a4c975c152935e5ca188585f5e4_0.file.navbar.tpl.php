<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:43
  from '/var/www/nameless/custom/templates/Cesium/navbar.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c4765f4c9_55842860',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5a2c240fa45a9a4c975c152935e5ca188585f5e4' => 
    array (
      0 => '/var/www/nameless/custom/templates/Cesium/navbar.tpl',
      1 => 1611091445,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c4765f4c9_55842860 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="wrapper">

	<header class="header-container"<?php if (($_smarty_tpl->tpl_vars['CSM']->value['headerBackground'])) {?> style="background: url('<?php echo $_smarty_tpl->tpl_vars['CSM']->value['headerBackground'];?>
') no-repeat center center / cover;"<?php }?>>

		<?php if (($_smarty_tpl->tpl_vars['CSM']->value['header'] && (($_smarty_tpl->tpl_vars['CSM']->value['headerHomepage'] && PAGE == 'index') || (!$_smarty_tpl->tpl_vars['CSM']->value['headerHomepage'])))) {?>
			<div class="header" style="<?php ob_start();
echo $_smarty_tpl->tpl_vars['CSM']->value['headerHeight'];
$_prefixVariable1 = ob_get_clean();
if (!empty($_prefixVariable1)) {?>height: <?php echo $_smarty_tpl->tpl_vars['CSM']->value['headerHeight'];?>
;<?php }?>">
				<div class="container">
					<?php if (($_smarty_tpl->tpl_vars['CSM']->value['discord'])) {?>
						<a href="<?php echo $_smarty_tpl->tpl_vars['CSM']->value['discord']['link'];?>
" class="header-discord" id="header-discord" data-toggle="tooltip" data-placement="bottom" title="<?php echo $_smarty_tpl->tpl_vars['CSM']->value['clickToJoinDiscordServer'];?>
">
							<div class="discord-icon">
								<i class="fab fa-discord fa-fw"></i>
							</div>
							<div class="discord-content">
								<div class="discord-title"><?php echo $_smarty_tpl->tpl_vars['CSM']->value['discord']['joinNow'];?>
</div>
								<span><?php echo $_smarty_tpl->tpl_vars['CSM']->value['discord']['members'];?>
</span>
							</div>
						</a>
					<?php }?>
					<div class="header-logo"<?php if (($_smarty_tpl->tpl_vars['CSM']->value['discord'] && !$_smarty_tpl->tpl_vars['CSM']->value['server']) || (!$_smarty_tpl->tpl_vars['CSM']->value['discord'] && !$_smarty_tpl->tpl_vars['CSM']->value['server'])) {?> style="order: -1;"<?php }?>>
						<?php if (($_smarty_tpl->tpl_vars['CSM']->value['logoURL'])) {?>
							<div class="site-logo <?php if (($_smarty_tpl->tpl_vars['CSM']->value['logoAnimation'])) {?> animated<?php }
if ((!$_smarty_tpl->tpl_vars['CSM']->value['server'])) {?> mx-auto<?php }?>">
								<a href="<?php echo $_smarty_tpl->tpl_vars['SITE_HOME']->value;?>
">
									<img src="<?php echo $_smarty_tpl->tpl_vars['CSM']->value['logoURL'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['CSM']->value['logoAlt'];?>
">
								</a>
							</div>
						<?php } elseif (($_smarty_tpl->tpl_vars['CSM']->value['logoAlt'])) {?>
							<div class="site-name">
								<h1>
									<a href="<?php echo $_smarty_tpl->tpl_vars['SITE_HOME']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['CSM']->value['logoAlt'];?>
</a>
								</h1>
							</div>
						<?php }?>
					</div>
					<?php if (($_smarty_tpl->tpl_vars['CSM']->value['server'])) {?>
						<a href="#" class="header-server" id="header-server" onclick="copy('#ip')" data-toggle="tooltip" data-placement="bottom" title="<?php echo $_smarty_tpl->tpl_vars['CSM']->value['clickToCopyServerIP'];?>
">
							<div class="server-icon">
								<i class="fas fa-globe fa-fw"></i>
							</div>
							<div class="server-content" id="server-content">
								<div class="server-title">
									<span id="ip"><?php echo $_smarty_tpl->tpl_vars['CSM']->value['server']['ip'];?>
</span>
								</div>
								<span><?php echo $_smarty_tpl->tpl_vars['CSM']->value['server']['players'];?>
</span>
							</div>
						</a>
					<?php }?>
				</div>
			</div>
		<?php }?>

		<div class="nav-sidebar" id="nav-sidebar">
			<div class="nav-container">
				<div class="nav-header">
					<a href="<?php echo $_smarty_tpl->tpl_vars['SITE_HOME']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['SITE_NAME']->value;?>
</a>
					<a href="#" class="nav-close" id="nav-close">
						<i class="fas fa-times"></i>
					</a>
				</div>
				<div class="nav-body">
					<ul class="nav-items">
						<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['NAV_LINKS']->value, 'link');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['link']->value) {
?>
							<?php if (empty($_smarty_tpl->tpl_vars['link']->value['items'])) {?>
								<li class="nav-item">
									<a href="<?php echo $_smarty_tpl->tpl_vars['link']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['link']->value['target'];?>
" class="nav-link"><?php echo $_smarty_tpl->tpl_vars['link']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['link']->value['title'];?>
</a>
								</li>
							<?php } else { ?>
								<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['link']->value['items'], 'item');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['item']->value) {
?>
									<li class="nav-item">
										<a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
" class="nav-link"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
									</li>
								<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
							<?php }?>
						<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
					</ul>
				</div>
			</div>
		</div>

		<?php if (($_smarty_tpl->tpl_vars['CSM']->value['navbarStyle'] == 'auto')) {?>
			<nav class="navbar<?php if ((count($_smarty_tpl->tpl_vars['NAV_LINKS']->value) < 4)) {?> navbar-expand-lg<?php } elseif ((count($_smarty_tpl->tpl_vars['NAV_LINKS']->value) < 7)) {?> navbar-expand-xl<?php }
if (($_smarty_tpl->tpl_vars['CSM']->value['navbarPosition'] == 'top')) {?> navbar-top<?php }?>" id="navbar">
		<?php } elseif (($_smarty_tpl->tpl_vars['CSM']->value['navbarStyle'] == 'full')) {?>
			<nav class="navbar navbar-expand-lg<?php if (($_smarty_tpl->tpl_vars['CSM']->value['navbarPosition'] == 'top')) {?> navbar-top<?php }?>" id="navbar">
		<?php } elseif (($_smarty_tpl->tpl_vars['CSM']->value['navbarStyle'] == 'sidebar')) {?>
			<nav class="navbar<?php if (($_smarty_tpl->tpl_vars['CSM']->value['navbarPosition'] == 'top')) {?> navbar-top<?php }?>" id="navbar">
		<?php }?>

			<div class="container">
				<a class="navbar-toggler" id="navbar-toggler">
					<i class="fas fa-bars"></i> Menu
				</a>
				<div class="collapse navbar-collapse">
					<ul class="navbar-nav mr-auto">
						<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['NAV_LINKS']->value, 'link');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['link']->value) {
?>
							<?php if (empty($_smarty_tpl->tpl_vars['link']->value['items'])) {?>
								<li class="nav-item<?php if (isset($_smarty_tpl->tpl_vars['link']->value['active'])) {?> active<?php }?>">
									<a href="<?php echo $_smarty_tpl->tpl_vars['link']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['link']->value['target'];?>
" class="nav-link"><?php echo $_smarty_tpl->tpl_vars['link']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['link']->value['title'];?>
</a>
								</li>
							<?php } else { ?>
								<div class="nav-item dropdown">
									<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><?php echo $_smarty_tpl->tpl_vars['link']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['link']->value['title'];?>
</a>
									<div class="dropdown-menu">
										<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['link']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?>
											<a href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
" class="dropdown-item"><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a>
										<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
									</div>
								</div>
							<?php }?>
						<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
					</ul>
				</div>
				<ul class="navbar-nav ml-auto">

					<?php if (isset($_smarty_tpl->tpl_vars['LOGGED_IN_USER']->value)) {?>
						<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['USER_SECTION']->value, 'link', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['link']->value) {
?>
							<?php if (($_smarty_tpl->tpl_vars['key']->value == 'alerts')) {
$_tmp_array = isset($_smarty_tpl->tpl_vars['link']) ? $_smarty_tpl->tpl_vars['link']->value : array();
if (!is_array($_tmp_array) || $_tmp_array instanceof ArrayAccess) {
settype($_tmp_array, 'array');
}
$_tmp_array['icon'] = '<i class="fas fa-flag"></i>';
$_smarty_tpl->_assignInScope('link', $_tmp_array);?>
							<?php } elseif (($_smarty_tpl->tpl_vars['key']->value == 'pms')) {
$_tmp_array = isset($_smarty_tpl->tpl_vars['link']) ? $_smarty_tpl->tpl_vars['link']->value : array();
if (!is_array($_tmp_array) || $_tmp_array instanceof ArrayAccess) {
settype($_tmp_array, 'array');
}
$_tmp_array['icon'] = '<i class="fas fa-envelope"></i>';
$_smarty_tpl->_assignInScope('link', $_tmp_array);?>
							<?php } elseif (($_smarty_tpl->tpl_vars['key']->value == 'panel')) {
$_tmp_array = isset($_smarty_tpl->tpl_vars['link']) ? $_smarty_tpl->tpl_vars['link']->value : array();
if (!is_array($_tmp_array) || $_tmp_array instanceof ArrayAccess) {
settype($_tmp_array, 'array');
}
$_tmp_array['icon'] = '<i class="fas fa-cogs"></i>';
$_smarty_tpl->_assignInScope('link', $_tmp_array);?>
							<?php } elseif (($_smarty_tpl->tpl_vars['key']->value == 'account')) {
$_tmp_array = isset($_smarty_tpl->tpl_vars['link']) ? $_smarty_tpl->tpl_vars['link']->value : array();
if (!is_array($_tmp_array) || $_tmp_array instanceof ArrayAccess) {
settype($_tmp_array, 'array');
}
$_tmp_array['icon'] = '<i class="fas fa-user"></i>';
$_smarty_tpl->_assignInScope('link', $_tmp_array);?>
							<?php } else {
$_tmp_array = isset($_smarty_tpl->tpl_vars['item']) ? $_smarty_tpl->tpl_vars['item']->value : array();
if (!is_array($_tmp_array) || $_tmp_array instanceof ArrayAccess) {
settype($_tmp_array, 'array');
}
$_tmp_array['icon'] = '';
$_smarty_tpl->_assignInScope('item', $_tmp_array);
}?>
							<?php if (empty($_smarty_tpl->tpl_vars['link']->value['items'])) {?>
								<?php if ((($_smarty_tpl->tpl_vars['key']->value == 'panel' && !$_smarty_tpl->tpl_vars['CSM']->value['panelInDropdown']) || $_smarty_tpl->tpl_vars['key']->value !== 'panel')) {?>
									<li class="nav-item<?php if (isset($_smarty_tpl->tpl_vars['link']->value['active'])) {?> active<?php }?>">
										<a href="<?php echo $_smarty_tpl->tpl_vars['link']->value['link'];?>
" target="<?php echo (empty($_smarty_tpl->tpl_vars['link']->value['target']) && $_smarty_tpl->tpl_vars['key']->value == 'panel' ? '_blank' : $_smarty_tpl->tpl_vars['link']->value['target']);?>
" class="nav-link">
											<?php echo $_smarty_tpl->tpl_vars['link']->value['icon'];?>
 <span><?php echo $_smarty_tpl->tpl_vars['link']->value['title'];?>
</span>
										</a>
									</li>
								<?php }?>
							<?php } else { ?>
								<div class="nav-item dropdown" id="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
">
									<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><?php echo $_smarty_tpl->tpl_vars['link']->value['icon'];?>
 <span><?php echo $_smarty_tpl->tpl_vars['link']->value['title'];?>
</span></a>
									<div class="dropdown-menu">
										<a class="dropdown-header"><?php echo $_smarty_tpl->tpl_vars['link']->value['title'];?>
</a>
										<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['link']->value['items'], 'dropdown', false, 'dropdownKey');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdownKey']->value => $_smarty_tpl->tpl_vars['dropdown']->value) {
?>
											<?php if (isset($_smarty_tpl->tpl_vars['dropdown']->value['seperator'])) {?>
												<hr>
											<?php } else { ?>
												<a href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
" class="dropdown-item"><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a>
												<?php if (($_smarty_tpl->tpl_vars['dropdownKey']->value == 'user')) {?>
													<?php if (($_smarty_tpl->tpl_vars['USER_SECTION']->value['panel'] && $_smarty_tpl->tpl_vars['CSM']->value['panelInDropdown'])) {?>
														<a href="<?php echo $_smarty_tpl->tpl_vars['USER_SECTION']->value['panel']['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['USER_SECTION']->value['panel']['target'];?>
" class="dropdown-item"><?php echo $_smarty_tpl->tpl_vars['USER_SECTION']->value['panel']['title'];?>
</a>
													<?php }?>
												<?php }?>
											<?php }?>
										<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
									</div>
								</div>
							<?php }?>
						<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
					<?php } else { ?>
						<?php if (($_smarty_tpl->tpl_vars['CSM']->value['guestDropdown'])) {?>
							<div class="nav-item dropdown" id="guestDropdown">
								<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fas fa-user"></i> Guest</a>
								<div class="dropdown-menu">
									<a class="dropdown-header">Guest</a>
									<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['USER_SECTION']->value, 'link', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['link']->value) {
?>
										<?php if (empty($_smarty_tpl->tpl_vars['link']->value['items'])) {?>
											<a href="<?php echo $_smarty_tpl->tpl_vars['link']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['link']->value['target'];?>
" class="dropdown-item"><?php echo $_smarty_tpl->tpl_vars['link']->value['title'];?>
</a>
										<?php }?>
									<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
								</div>
							</div>
						<?php } else { ?>
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['USER_SECTION']->value, 'link', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['link']->value) {
?>
								<?php if (($_smarty_tpl->tpl_vars['key']->value == 'login')) {
$_tmp_array = isset($_smarty_tpl->tpl_vars['link']) ? $_smarty_tpl->tpl_vars['link']->value : array();
if (!is_array($_tmp_array) || $_tmp_array instanceof ArrayAccess) {
settype($_tmp_array, 'array');
}
$_tmp_array['icon'] = '<i class="fas fa-key"></i>';
$_smarty_tpl->_assignInScope('link', $_tmp_array);?>
								<?php } elseif (($_smarty_tpl->tpl_vars['key']->value == 'register')) {
$_tmp_array = isset($_smarty_tpl->tpl_vars['link']) ? $_smarty_tpl->tpl_vars['link']->value : array();
if (!is_array($_tmp_array) || $_tmp_array instanceof ArrayAccess) {
settype($_tmp_array, 'array');
}
$_tmp_array['icon'] = '<i class="fas fa-clipboard"></i>';
$_smarty_tpl->_assignInScope('link', $_tmp_array);?>
								<?php } else {
$_tmp_array = isset($_smarty_tpl->tpl_vars['link']) ? $_smarty_tpl->tpl_vars['link']->value : array();
if (!is_array($_tmp_array) || $_tmp_array instanceof ArrayAccess) {
settype($_tmp_array, 'array');
}
$_tmp_array['icon'] = '';
$_smarty_tpl->_assignInScope('link', $_tmp_array);
}?>
								<?php if (empty($_smarty_tpl->tpl_vars['link']->value['items'])) {?>
									<li class="nav-item<?php if (isset($_smarty_tpl->tpl_vars['link']->value['active'])) {?> active<?php }?>">
										<a href="<?php echo $_smarty_tpl->tpl_vars['link']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['link']->value['target'];?>
" class="nav-link">
											<?php echo $_smarty_tpl->tpl_vars['link']->value['icon'];?>
 <span><?php echo $_smarty_tpl->tpl_vars['link']->value['title'];?>
</span>
										</a>
									</li>
								<?php } else { ?>
									<div class="nav-item dropdown" id="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
">
										<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><?php echo $_smarty_tpl->tpl_vars['link']->value['icon'];?>
 <span><?php echo $_smarty_tpl->tpl_vars['link']->value['title'];?>
</span></a>
										<div class="dropdown-menu">
											<a class="dropdown-header"><?php echo $_smarty_tpl->tpl_vars['link']->value['title'];?>
</a>
											<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['link']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?>
												<?php if (isset($_smarty_tpl->tpl_vars['dropdown']->value['seperator'])) {?>
													<hr>
												<?php } else { ?>
													<a href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
" class="dropdown-item"><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a>
												<?php }?>
											<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
										</div>
									</div>
								<?php }?>
							<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
						<?php }?>
					<?php }?>

				</ul>
			</div>
		</nav>

	</header>

	

	<div class="container" id="index">

		<?php if (isset($_smarty_tpl->tpl_vars['NEW_UPDATE']->value)) {?>
			<div class="alert alert-<?php echo $_smarty_tpl->tpl_vars['NEW_UPDATE_URGENT']->value == true ? 'danger' : 'info alert-dismissible';?>
" id="alert-update">
				<?php if (($_smarty_tpl->tpl_vars['NEW_UPDATE_URGENT']->value !== true)) {?>
					<a href="#" class="close" data-dismiss="alert">
						<i class="fas fa-times"></i>
					</a>
				<?php }?>
				<strong><?php echo $_smarty_tpl->tpl_vars['NEW_UPDATE']->value;?>
</strong>
				<li><?php echo $_smarty_tpl->tpl_vars['CURRENT_VERSION']->value;?>
</li>
				<li><?php echo $_smarty_tpl->tpl_vars['NEW_VERSION']->value;?>
</li>
				<a href="<?php echo $_smarty_tpl->tpl_vars['UPDATE_LINK']->value;?>
" class="btn btn-info btn-sm mt-2 ml-2"><?php echo $_smarty_tpl->tpl_vars['UPDATE']->value;?>
</a>
			</div>
    	<?php }?>

		<?php if (isset($_smarty_tpl->tpl_vars['CSM']->value['update'])) {?>
			<div class="alert alert-info">
				<strong><?php echo $_smarty_tpl->tpl_vars['CSM']->value['update']['updateAvailableTitle'];?>
</strong>
				<div class="my-1">
					<?php echo $_smarty_tpl->tpl_vars['CSM']->value['update']['updateAvailable'];?>

				</div>
				<a href="<?php echo $_smarty_tpl->tpl_vars['CSM']->value['update']['updateLink'];?>
" class="btn btn-info btn-sm mt-2"><?php echo $_smarty_tpl->tpl_vars['CSM']->value['update']['updateNow'];?>
</a>
			</div>
    	<?php }?>

		<?php if (isset($_smarty_tpl->tpl_vars['MAINTENANCE_ENABLED']->value)) {?>
			<div class="alert alert-danger alert-dismissible">
				<a href="#" class="close" data-dismiss="alert">
					<i class="fas fa-times"></i>
				</a>
				<?php echo $_smarty_tpl->tpl_vars['MAINTENANCE_ENABLED']->value;?>

			</div>
		<?php }?>

		<?php if (isset($_smarty_tpl->tpl_vars['MUST_VALIDATE_ACCOUNT']->value)) {?>
			<div class="alert alert-info">
				<?php echo $_smarty_tpl->tpl_vars['MUST_VALIDATE_ACCOUNT']->value;?>

			</div>
		<?php }?>

		<?php if (count($_smarty_tpl->tpl_vars['CSM']->value['announcements'])) {?>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['CSM']->value['announcements'], 'announcement');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['announcement']->value) {
?>
				<div class="announcement announcement-<?php echo $_smarty_tpl->tpl_vars['announcement']->value['type'];?>
">
					<div class="announcement-header"><?php echo $_smarty_tpl->tpl_vars['announcement']->value['name'];?>
</div>
					<?php echo $_smarty_tpl->tpl_vars['announcement']->value['content'];?>

				</div>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		<?php }?>

		<?php if (count($_smarty_tpl->tpl_vars['CSM']->value['carousel'])) {?>
			<div class="carousel slide" id="carousel" data-ride="carousel">
				<ol class="carousel-indicators">
					<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['CSM']->value['carousel'], 'carouselItem', false, NULL, 'name', array (
  'iteration' => true,
  'first' => true,
  'last' => true,
  'index' => true,
  'total' => true,
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['carouselItem']->value) {
$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['iteration']++;
$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['index']++;
$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['first'] = !$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['index'];
$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['last'] = $_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['iteration'] === $_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['total'];
?>
						<li data-target="#carousel" data-slide-to="<?php echo (isset($_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['iteration']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['iteration'] : null)-1;?>
" <?php if (((isset($_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['first']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['first'] : null))) {?>class="active"<?php }?>></li>
					<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				</ol>
				<div class="carousel-inner">
					<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['CSM']->value['carousel'], 'carouselItem', false, NULL, 'name', array (
  'iteration' => true,
  'first' => true,
  'last' => true,
  'index' => true,
  'total' => true,
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['carouselItem']->value) {
$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['iteration']++;
$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['index']++;
$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['first'] = !$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['index'];
$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['last'] = $_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['iteration'] === $_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['total'];
?>
						<a class="carousel-item<?php if (((isset($_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['first']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['first'] : null))) {?> active<?php }?>"<?php if (!empty($_smarty_tpl->tpl_vars['carouselItem']->value['link'])) {?> href="<?php echo $_smarty_tpl->tpl_vars['carouselItem']->value['link'];?>
" target="_blank"<?php }?>>
							<img src="<?php echo $_smarty_tpl->tpl_vars['carouselItem']->value['image'];?>
" class="d-block w-100" alt="<?php echo $_smarty_tpl->tpl_vars['carouselItem']->value['title'];?>
">
							<div class="carousel-caption d-none d-md-block">
								<?php if (($_smarty_tpl->tpl_vars['carouselItem']->value['title'])) {?>
									<h5><?php echo $_smarty_tpl->tpl_vars['carouselItem']->value['title'];?>
</h5>
								<?php }?>
								<?php if (($_smarty_tpl->tpl_vars['carouselItem']->value['description'])) {?>
									<p><?php echo $_smarty_tpl->tpl_vars['carouselItem']->value['description'];?>
</p>
								<?php }?>
							</div>
						</a>
					<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				</div>
			</div>
		<?php }?>

		<div class="chatbox" id="chatbox-top"></div>

		<div class="row justify-content-center">
	
			<?php if (count($_smarty_tpl->tpl_vars['WIDGETS']->value) || (@constant('PAGE') == 'forum' && $_smarty_tpl->tpl_vars['SEARCH']->value && $_smarty_tpl->tpl_vars['SEARCH_URL']->value)) {?>
				<div class="col-lg-3 order-last" id="widgets">
					<div class="row">
						<?php if ((@constant('PAGE') == 'forum' && $_smarty_tpl->tpl_vars['SEARCH']->value && $_smarty_tpl->tpl_vars['SEARCH_URL']->value)) {?>
							<div class="<?php echo empty($_smarty_tpl->tpl_vars['WIDGETS']->value) ? 'col' : 'col-lg-12 col-md-4 col-sm-6';?>
" id="widget">
								<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['SEARCH_URL']->value;?>
" id="form-forumSearch">
									<div class="form-group">
										<div class="input-group">
											<input type="text" name="forum_search" class="form-control" placeholder="<?php echo $_smarty_tpl->tpl_vars['SEARCH']->value;?>
">
											<input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
											<div class="input-group-append">
												<button class="btn btn-primary" type="submit">
													<i class="fas fa-search"></i>
												</button>
											</div>
										</div>
									</div>
								</form>
							</div>
						<?php }?>
						<?php if (count($_smarty_tpl->tpl_vars['WIDGETS']->value)) {?>
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['WIDGETS']->value, 'widget', false, NULL, 'name', array (
  'iteration' => true,
  'first' => true,
  'last' => true,
  'index' => true,
  'total' => true,
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['widget']->value) {
$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['iteration']++;
$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['index']++;
$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['first'] = !$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['index'];
$_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['last'] = $_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['iteration'] === $_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['total'];
?>
								<?php if (!empty($_smarty_tpl->tpl_vars['widget']->value)) {?>
									<div class="<?php echo (isset($_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['last']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_name']->value['last'] : null) ? 'col' : 'col-lg-12 col-md-4 col-sm-6';?>
" id="widget">
										<?php echo $_smarty_tpl->tpl_vars['widget']->value;?>

									</div>
								<?php }?>
							<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
						<?php }?>
					</div>
				</div>
			<?php }?>

			<?php if (count($_smarty_tpl->tpl_vars['WIDGETS']->value) || isset($_smarty_tpl->tpl_vars['FRIENDS']->value)) {?>
				<div class="col-lg-9">
			<?php } else { ?>
				<div class="col">
			<?php }
}
}
