<?php
/* Smarty version 3.1.33, created on 2021-01-20 11:54:07
  from '/var/www/nameless/custom/templates/DefaultRevamp/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600819dfc6e484_99221436',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '60830e57b62d4a0cd553aed1c0ca9240385f51b7' => 
    array (
      0 => '/var/www/nameless/custom/templates/DefaultRevamp/header.tpl',
      1 => 1611082599,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_600819dfc6e484_99221436 (Smarty_Internal_Template $_smarty_tpl) {
if (defined("HTML_CLASS")) {
$_smarty_tpl->_assignInScope('HTMLCLASS', " ".((string)@constant('HTML_CLASS')));
}
if (defined("HTML_LANG")) {
$_smarty_tpl->_assignInScope('HTMLLANG', " lang='".((string)@constant('HTML_LANG'))."'");
} else {
$_smarty_tpl->_assignInScope('HTMLLANG', " lang='en'");
}
if (defined("HTML_RTL") && @constant('HTML_RTL') == true) {
$_smarty_tpl->_assignInScope('HTMLRTL', " dir='rtl'");
}
if (defined("LANG_CHARSET")) {
$_smarty_tpl->_assignInScope('METACHARSET', ((string)@constant('LANG_CHARSET')));
} else {
$_smarty_tpl->_assignInScope('METACHARSET', "utf-8");
}
if (isset($_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value, $tmp) > 0) {
$_smarty_tpl->_assignInScope('PAGEDESCRIPTION', ((string)$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value));
} else {
$_smarty_tpl->_assignInScope('PAGEDESCRIPTION', " ");
}
if (isset($_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value, $tmp) > 0) {
$_smarty_tpl->_assignInScope('PAGEKEYWORDS', ((string)$_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value));
} else {
$_smarty_tpl->_assignInScope('PAGEKEYWORDS', " ");
}?>

<!DOCTYPE html>
<html<?php echo $_smarty_tpl->tpl_vars['HTMLCLASS']->value;
echo $_smarty_tpl->tpl_vars['HTMLLANG']->value;
echo $_smarty_tpl->tpl_vars['HTMLRTL']->value;?>
>
  <head>
    
    <meta charset="<?php echo $_smarty_tpl->tpl_vars['METACHARSET']->value;?>
">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <title><?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
</title>
  
    <meta name="author" content="<?php echo @constant('SITE_NAME');?>
">
    <meta name='description' content='<?php echo $_smarty_tpl->tpl_vars['PAGEDESCRIPTION']->value;?>
' />
    <meta name='keywords' content='<?php echo $_smarty_tpl->tpl_vars['PAGEKEYWORDS']->value;?>
' />
  
    <meta property="og:title" content="<?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="<?php echo $_smarty_tpl->tpl_vars['OG_URL']->value;?>
" />
    <meta property="og:image" content="<?php echo $_smarty_tpl->tpl_vars['OG_IMAGE']->value;?>
" />
    <meta property='og:description' content='<?php echo $_smarty_tpl->tpl_vars['PAGEDESCRIPTION']->value;?>
' />
  
	  <!-- Twitter Card Properties -->
    <meta name="twitter:title" content="<?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:image" content="<?php echo $_smarty_tpl->tpl_vars['OG_IMAGE']->value;?>
" />

     <?php if (isset($_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value, $tmp) > 0) {?>
         <meta name="twitter:description" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value;?>
" />
    <?php }?>
  
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['TEMPLATE_CSS']->value, 'css');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['css']->value) {
?>
      <?php echo $_smarty_tpl->tpl_vars['css']->value;?>

    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

	<?php if (isset($_smarty_tpl->tpl_vars['ANALYTICS_ID']->value)) {?>
	  
		<?php echo '<script'; ?>
 async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $_smarty_tpl->tpl_vars['ANALYTICS_ID']->value;?>
"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
>
		  window.dataLayer = window.dataLayer || [];
		  function gtag(){dataLayer.push(arguments);}
		  gtag('js', new Date());

		  gtag('config', '<?php echo $_smarty_tpl->tpl_vars['ANALYTICS_ID']->value;?>
');
		<?php echo '</script'; ?>
>
	  
    <?php }?>
  </head>

  <body<?php if ($_smarty_tpl->tpl_vars['DEFAULT_REVAMP_DARK_MODE']->value) {?> class="dark"<?php }?> id="page-<?php if (is_numeric(@constant('PAGE'))) {
echo $_smarty_tpl->tpl_vars['TITLE']->value;
} else {
echo @constant('PAGE');
}?>">
<?php }
}
