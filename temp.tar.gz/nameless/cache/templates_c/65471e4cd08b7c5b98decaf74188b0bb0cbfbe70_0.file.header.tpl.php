<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:43
  from '/var/www/nameless/custom/templates/Cesium/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c47626183_71837486',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '65471e4cd08b7c5b98decaf74188b0bb0cbfbe70' => 
    array (
      0 => '/var/www/nameless/custom/templates/Cesium/header.tpl',
      1 => 1611091445,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c47626183_71837486 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>

<html language="<?php echo @constant('HTML_LANG') ? @constant('HTML_LANG') : 'en';?>
"<?php echo @constant('HTML_CLASS') ? ' '+@constant('HTML_CLASS') : '';
echo @constant('HTML_RTL') ? ' dir="rtl"' : '';?>
>

	<head>
	
		<meta charset="<?php echo @constant('LANG_CHARSET') ? @constant('LANG_CHARSET') : 'utf-8';?>
">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

		<title><?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo $_smarty_tpl->tpl_vars['CSM']->value['siteTitle'] ? $_smarty_tpl->tpl_vars['CSM']->value['siteTitle'] : @constant('SITE_NAME');?>
</title>
	
		<meta name="author" content="<?php echo $_smarty_tpl->tpl_vars['CSM']->value['siteTitle'] ? $_smarty_tpl->tpl_vars['CSM']->value['siteTitle'] : @constant('SITE_NAME');?>
">
		<meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value ? $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value : $_smarty_tpl->tpl_vars['CSM']->value['siteDescription'];?>
">
		<meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value ? $_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value : '';?>
">
	
		<meta property="og:title" content="<?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo $_smarty_tpl->tpl_vars['CSM']->value['siteTitle'] ? $_smarty_tpl->tpl_vars['CSM']->value['siteTitle'] : @constant('SITE_NAME');?>
">
		<meta property="og:type" content="website">
		<meta property="og:url" content="<?php echo $_smarty_tpl->tpl_vars['OG_URL']->value;?>
">
		<meta property="og:image" content="<?php echo $_smarty_tpl->tpl_vars['CSM']->value['siteImage'];?>
">
		<meta property="og:description" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value ? $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value : $_smarty_tpl->tpl_vars['CSM']->value['siteDescription'];?>
">

		<link rel="icon" type="image/png" href="<?php echo $_smarty_tpl->tpl_vars['CSM']->value['siteFavicon'];?>
">
	
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['TEMPLATE_CSS']->value, 'css');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['css']->value) {
?>
			<?php echo $_smarty_tpl->tpl_vars['css']->value;?>

		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	
	</head>

	<body class="<?php echo $_smarty_tpl->tpl_vars['CSM']->value['classes'];?>
" id="page-<?php echo is_numeric(@constant('PAGE')) ? $_smarty_tpl->tpl_vars['TITLE']->value : @constant('PAGE');?>
">
	
		<?php if (((@constant('PAGE') == 'portal' && $_smarty_tpl->tpl_vars['CSM']->value['portal']['particles']) || (@constant('PAGE') !== 'portal' && $_smarty_tpl->tpl_vars['CSM']->value['particles']))) {?>
			<div class="particles" id="particles"></div>
		<?php }
}
}
