<?php
/* Smarty version 3.1.33, created on 2021-01-20 01:34:41
  from '/var/www/nameless/custom/templates/MineBox/profile.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600788b1cfdc15_58404264',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6549347f1c2885627a8783b7897035907a1cb091' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/profile.tpl',
      1 => 1611094419,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_600788b1cfdc15_58404264 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="container">
  <div class="jumbotron" style="background-image:url('<?php echo $_smarty_tpl->tpl_vars['BANNER']->value;?>
');">
	<div class="row">
	  <div class="col-md-8">
		<h2>
		  <img class="img-rounded" style="height:60px;width=60px;" src="<?php echo $_smarty_tpl->tpl_vars['AVATAR']->value;?>
" />
		  <strong<?php if ($_smarty_tpl->tpl_vars['USERNAME_COLOUR']->value != false) {?> style="<?php echo $_smarty_tpl->tpl_vars['USERNAME_COLOUR']->value;?>
"<?php }?>><?php echo $_smarty_tpl->tpl_vars['NICKNAME']->value;?>
</strong> 
		  <?php echo $_smarty_tpl->tpl_vars['GROUP']->value;?>

		</h2>
	  </div>
	  <div class="col-md-4">
		<span class="pull-right">
		  
		  <?php if (isset($_smarty_tpl->tpl_vars['LOGGED_IN']->value)) {?>
		    <?php if (!isset($_smarty_tpl->tpl_vars['SELF']->value)) {?>
		  <div class="btn-group">
			<!--<a href="<?php echo $_smarty_tpl->tpl_vars['FOLLOW_LINK']->value;?>
" class="btn btn-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
 btn-lg"><i class="fa fa-users fa-fw"></i> <?php echo $_smarty_tpl->tpl_vars['FOLLOW']->value;?>
</a>-->
			<?php if ($_smarty_tpl->tpl_vars['MOD_OR_ADMIN']->value != true) {?><a href="#" data-toggle="modal" data-target="#blockModal" class="btn btn-red btn-lg"><i class="fa fa-ban fa-fw"></i></a><?php }?>
			<a href="<?php echo $_smarty_tpl->tpl_vars['MESSAGE_LINK']->value;?>
" class="btn btn-secondary btn-lg"><i class="fa fa-envelope fa-fw"></i></a>
		  </div>
		    <?php } else { ?>
		  <div class="btn-group">
		    <a href="<?php echo $_smarty_tpl->tpl_vars['SETTINGS_LINK']->value;?>
" class="btn btn-secondary btn-lg"><i class="fa fa-cogs fa-fw"></i></a>
		    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#imageModal"><i class="fa fa-picture-o fa-fw" aria-hidden="true"></i></button>
		  </div>
		    <?php }?>
		  <?php }?>
		  
		</span>
	  </div>
	</div>
  </div>
<?php if (!isset($_smarty_tpl->tpl_vars['CAN_VIEW']->value) || (isset($_smarty_tpl->tpl_vars['CAN_VIEW']->value) && $_smarty_tpl->tpl_vars['CAN_VIEW']->value == true)) {?>
  <?php if (!empty($_smarty_tpl->tpl_vars['WIDGETS']->value)) {?>
    <div class="row">
      <div class="col-md-9">
  <?php }?>
  
  <div class="card">
    <div class="card-body">
	  <ul class="nav nav-tabs">
		<li class="nav-item">
		  <a class="nav-link active" data-toggle="tab" href="#feed" role="tab"><?php echo $_smarty_tpl->tpl_vars['FEED']->value;?>
</a>
		</li>
		<li class="nav-item">
		  <a class="nav-link" data-toggle="tab" href="#about" role="tab"><?php echo $_smarty_tpl->tpl_vars['ABOUT']->value;?>
</a>
		</li>
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['TABS']->value, 'tab', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['tab']->value) {
?>
		<li class="nav-item">
		  <a class="nav-link" data-toggle="tab" href="#<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" role="tab"><?php echo $_smarty_tpl->tpl_vars['tab']->value['title'];?>
</a>
		</li>
		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	  </ul>

	  <br />

	  <div class="tab-content">
		<div class="tab-pane active" id="feed" role="tabpanel">
		  <?php if (isset($_smarty_tpl->tpl_vars['LOGGED_IN']->value)) {?>
			<?php if (isset($_smarty_tpl->tpl_vars['ERROR']->value)) {?>
			<div class="alert alert-danger">
			  <?php echo $_smarty_tpl->tpl_vars['ERROR']->value;?>

			</div>
			<?php }?>
			<?php if (isset($_smarty_tpl->tpl_vars['SUCCESS']->value)) {?>
			<div class="alert alert-success">
			  <?php echo $_smarty_tpl->tpl_vars['SUCCESS']->value;?>

 			</div>
			<?php }?>
		  <form action="" method="post">
			<div class="form-group">
			  <textarea name="post" class="form-control" placeholder="<?php echo $_smarty_tpl->tpl_vars['POST_ON_WALL']->value;?>
"></textarea>
			</div>

			<input type="hidden" name="action" value="new_post">
			<input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
			<input type="submit" class="btn btn-success" value="<?php echo $_smarty_tpl->tpl_vars['SUBMIT']->value;?>
">
		  </form>

		  <hr />
		  <?php }?>

		  <?php if (count($_smarty_tpl->tpl_vars['WALL_POSTS']->value)) {?>
		  <div class="timeline">
			<div class="line text-muted"></div>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['WALL_POSTS']->value, 'post');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['post']->value) {
?>

			<article class="panel panel-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
">
			  <div class="panel-heading icon">
				<a data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['post']->value['user_id'];?>
" data-html="true" data-placement="top" href="<?php echo $_smarty_tpl->tpl_vars['post']->value['profile'];?>
"><img class="img-rounded" style="height:40px; width=40px;" src="<?php echo $_smarty_tpl->tpl_vars['post']->value['avatar'];?>
" /></a>
			  </div>

			  <div class="panel-heading">
				<span class="panel-title" style="display:inline;"><?php echo $_smarty_tpl->tpl_vars['BY']->value;?>
: <a data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['post']->value['user_id'];?>
" data-html="true" data-placement="top" href="<?php echo $_smarty_tpl->tpl_vars['post']->value['profile'];?>
"><?php echo $_smarty_tpl->tpl_vars['post']->value['nickname'];?>
</a></span>
				<span class="pull-right"><span rel="tooltip" data-original-title="<?php echo $_smarty_tpl->tpl_vars['post']->value['date'];?>
"><i class="fa fa-clock-o"></i> <?php echo $_smarty_tpl->tpl_vars['post']->value['date_rough'];?>
</span></span>
			  </div>

			  <div class="panel-body">
				<div class="forum_post">
				  <?php echo $_smarty_tpl->tpl_vars['post']->value['content'];?>

				</div>
			  </div>

			  <div class="panel-footer">
				<a href="<?php if ($_smarty_tpl->tpl_vars['post']->value['reactions_link'] != "#") {
echo $_smarty_tpl->tpl_vars['post']->value['reactions_link'];
} else { ?>#<?php }?>" class="pop" data-content='<?php if (isset($_smarty_tpl->tpl_vars['post']->value['reactions']['reactions'])) {?> <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['post']->value['reactions']['reactions'], 'reaction', false, NULL, 'reactions', array (
  'last' => true,
  'iteration' => true,
  'total' => true,
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['reaction']->value) {
$_smarty_tpl->tpl_vars['__smarty_foreach_reactions']->value['iteration']++;
$_smarty_tpl->tpl_vars['__smarty_foreach_reactions']->value['last'] = $_smarty_tpl->tpl_vars['__smarty_foreach_reactions']->value['iteration'] === $_smarty_tpl->tpl_vars['__smarty_foreach_reactions']->value['total'];
?><a href="<?php echo $_smarty_tpl->tpl_vars['reaction']->value['profile'];?>
" style="<?php echo $_smarty_tpl->tpl_vars['reaction']->value['style'];?>
"><img class="img-rounded" src="<?php echo $_smarty_tpl->tpl_vars['reaction']->value['avatar'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['reaction']->value['username'];?>
" style="max-height:30px; max-width:30px;" /> <?php echo $_smarty_tpl->tpl_vars['reaction']->value['nickname'];?>
</a><?php if (!(isset($_smarty_tpl->tpl_vars['__smarty_foreach_reactions']->value['last']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_reactions']->value['last'] : null)) {?><br /><?php }
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?> <?php } else {
echo $_smarty_tpl->tpl_vars['post']->value['reactions']['count'];
}?>'><i class="fa fa-thumbs-up"></i> <?php echo $_smarty_tpl->tpl_vars['post']->value['reactions']['count'];?>
 </a> | <a href="#" data-toggle="modal" data-target="#replyModal<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
"><i class="fa fa-comments"></i> <?php echo $_smarty_tpl->tpl_vars['post']->value['replies']['count'];?>
</a>
				<span class="pull-right">
				  <?php if ((isset($_smarty_tpl->tpl_vars['CAN_MODERATE']->value) && $_smarty_tpl->tpl_vars['CAN_MODERATE']->value == 1) || $_smarty_tpl->tpl_vars['post']->value['self'] == 1) {?>
				    <form action="" method="post" id="delete<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
" style="display:none">
					  <input type="hidden" name="post_id" value="<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
">
					  <input type="hidden" name="action" value="delete">
				      <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
					</form>
					<a href="#" data-toggle="modal" data-target="#editModal<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
"><i class="fa fa-pencil-square-o"></i> <?php echo $_smarty_tpl->tpl_vars['EDIT']->value;?>
</a> | <a href="#" onclick="deletePost(<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
)"><i class="fa fa-trash"></i> <?php echo $_smarty_tpl->tpl_vars['DELETE']->value;?>
</a>
				  <?php }?>
				</span>
			  </div>

			</article>
			
			<?php if ((isset($_smarty_tpl->tpl_vars['CAN_MODERATE']->value) && $_smarty_tpl->tpl_vars['CAN_MODERATE']->value == 1) || $_smarty_tpl->tpl_vars['post']->value['self'] == 1) {?>
				<!-- Post editing modal -->
				<div class="modal fade" id="editModal<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
" tabindex="-1" role="dialog" aria-labelledby="editModal<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
Label" aria-hidden="true">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h4 class="modal-title" id="reactModal<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
Label"><?php echo $_smarty_tpl->tpl_vars['EDIT']->value;?>
</h4>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form action="" method="post">
								  <div class="form-group">
									<textarea class="form-control" name="content"><?php echo $_smarty_tpl->tpl_vars['post']->value['content'];?>
</textarea>
								  </div>
								  <div class="form-group">
									<input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
									<input type="hidden" name="post_id" value="<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
">
									<input type="hidden" name="action" value="edit">
									<input type="submit" class="btn btn-success" value="<?php echo $_smarty_tpl->tpl_vars['SUBMIT']->value;?>
">
								  </div>
								</form>
							</div>
						</div>
					</div>
				</div>
			<?php }?>

			<?php if ($_smarty_tpl->tpl_vars['post']->value['reactions_link'] != "#") {?>
			<!-- Reaction modal -->
			<div class="modal fade" id="reactModal<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
" tabindex="-1" role="dialog" aria-labelledby="reactModal<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
Label" aria-hidden="true">
			  <div class="modal-dialog" role="document">
				<div class="modal-content">
				  <div class="modal-header">
					<h4 class="modal-title" id="reactModal<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
Label"><?php echo $_smarty_tpl->tpl_vars['REACTIONS_TITLE']->value;?>
</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					  <span aria-hidden="true">&times;</span>
					</button>
				  </div>
				  <div class="modal-body">
					
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo $_smarty_tpl->tpl_vars['CLOSE']->value;?>
</button>
				  </div>
				</div>
			  </div>
			</div>
			<?php }?>
			
			<!-- Replies modal -->
			<div class="modal fade" id="replyModal<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
" tabindex="-1" role="dialog" aria-labelledby="replyModal<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
Label" aria-hidden="true">
			  <div class="modal-dialog" role="document">
				<div class="modal-content">
				  <div class="modal-header">
					<h4 class="modal-title" id="replyModal<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
Label"><?php echo $_smarty_tpl->tpl_vars['REPLIES_TITLE']->value;?>
</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					  <span aria-hidden="true">&times;</span>
					</button>	
				  </div>
				  <div class="modal-body">
				    <?php if (isset($_smarty_tpl->tpl_vars['post']->value['replies']['replies'])) {?>
					  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['post']->value['replies']['replies'], 'reply', false, NULL, 'replies', array (
  'last' => true,
  'iteration' => true,
  'total' => true,
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['reply']->value) {
$_smarty_tpl->tpl_vars['__smarty_foreach_replies']->value['iteration']++;
$_smarty_tpl->tpl_vars['__smarty_foreach_replies']->value['last'] = $_smarty_tpl->tpl_vars['__smarty_foreach_replies']->value['iteration'] === $_smarty_tpl->tpl_vars['__smarty_foreach_replies']->value['total'];
?>
					  <img src="<?php echo $_smarty_tpl->tpl_vars['reply']->value['avatar'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['reply']->value['username'];?>
" style="max-height:20px; max-width:20px;" class="img-rounded" /> <a href="<?php echo $_smarty_tpl->tpl_vars['reply']->value['profile'];?>
" style="<?php echo $_smarty_tpl->tpl_vars['reply']->value['style'];?>
"><?php echo $_smarty_tpl->tpl_vars['reply']->value['nickname'];?>
</a> &raquo;
					  <span class="pull-right">
					    <span rel="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['reply']->value['time_full'];?>
"><?php echo $_smarty_tpl->tpl_vars['reply']->value['time_friendly'];?>
</span>
					  </span>
					  <div style="height:15px;"></div>
					  <div class="forum_post">
					    <?php echo $_smarty_tpl->tpl_vars['reply']->value['content'];?>

					  </div>
					  <?php if ((isset($_smarty_tpl->tpl_vars['CAN_MODERATE']->value) && $_smarty_tpl->tpl_vars['CAN_MODERATE']->value == 1) || $_smarty_tpl->tpl_vars['reply']->value['self'] == 1) {?>
					    <form action="" method="post" id="deleteReply<?php echo $_smarty_tpl->tpl_vars['reply']->value['id'];?>
">
					      <input type="hidden" name="action" value="deleteReply">
					      <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
					      <input type="hidden" name="post_id" value="<?php echo $_smarty_tpl->tpl_vars['reply']->value['id'];?>
">
					    </form>
					    <br /><a href="#" onclick="deleteReply(<?php echo $_smarty_tpl->tpl_vars['reply']->value['id'];?>
)"><?php echo $_smarty_tpl->tpl_vars['DELETE']->value;?>
</a>
					  <?php }?>
					  <?php if (!(isset($_smarty_tpl->tpl_vars['__smarty_foreach_replies']->value['last']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_replies']->value['last'] : null)) {?><hr /><?php }?>
					  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
					<?php } else { ?>
					  <p><?php echo $_smarty_tpl->tpl_vars['NO_REPLIES']->value;?>
</p>
					<?php }?>
					
					<?php if (isset($_smarty_tpl->tpl_vars['LOGGED_IN']->value)) {?>
					<hr />
					<form action="" method="post">
					  <textarea class="form-control" name="reply" placeholder="<?php echo $_smarty_tpl->tpl_vars['NEW_REPLY']->value;?>
"></textarea>
					  <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
					  <input type="hidden" name="post" value="<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
">
					  <input type="hidden" name="action" value="reply">
					<?php }?>
				  </div>
				  <div class="modal-footer">
				    <?php if (isset($_smarty_tpl->tpl_vars['LOGGED_IN']->value)) {?>
					<input type="submit" value="<?php echo $_smarty_tpl->tpl_vars['SUBMIT']->value;?>
" class="btn btn-success">
					</form>
				    <?php }?>
					<button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo $_smarty_tpl->tpl_vars['CLOSE']->value;?>
</button>
				  </div>
				</div>
			  </div>
			</div>

			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		  </div>

			<?php echo $_smarty_tpl->tpl_vars['PAGINATION']->value;?>

		  <?php } else { ?>
			<div class="alert alert-info"><?php echo $_smarty_tpl->tpl_vars['NO_WALL_POSTS']->value;?>
</div>
			<br /><br />
		  <?php }?>
		</div>

		<div class="tab-pane" id="about" role="tabpanel">
		  <div class="row">
		    <div class="col-md-4">
			  <div class="card">
			    <div class="card-body">
				  <?php if (isset($_smarty_tpl->tpl_vars['ABOUT_FIELDS']->value['minecraft'])) {?>
				    <center>
					  <img src="<?php echo $_smarty_tpl->tpl_vars['ABOUT_FIELDS']->value['minecraft']['image'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['USERNAME']->value;?>
" class="img-rounded" />
					  <h2<?php if ($_smarty_tpl->tpl_vars['USERNAME_COLOUR']->value != false) {?> style="<?php echo $_smarty_tpl->tpl_vars['USERNAME_COLOUR']->value;?>
"<?php }?>><?php echo $_smarty_tpl->tpl_vars['NICKNAME']->value;?>
</h2>
					  <?php echo $_smarty_tpl->tpl_vars['USER_TITLE']->value;?>

					</center>
					<hr />
					<ul>
					  <li><?php echo $_smarty_tpl->tpl_vars['ABOUT_FIELDS']->value['registered']['title'];?>
</strong> <span rel="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['ABOUT_FIELDS']->value['registered']['tooltip'];?>
"><?php echo $_smarty_tpl->tpl_vars['ABOUT_FIELDS']->value['registered']['value'];?>
</li>
					  <li><?php echo $_smarty_tpl->tpl_vars['ABOUT_FIELDS']->value['last_seen']['title'];?>
</strong> <span rel="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['ABOUT_FIELDS']->value['last_seen']['tooltip'];?>
"><?php echo $_smarty_tpl->tpl_vars['ABOUT_FIELDS']->value['last_seen']['value'];?>
</li>
					  <li><?php echo $_smarty_tpl->tpl_vars['ABOUT_FIELDS']->value['profile_views']['title'];?>
</strong> <?php echo $_smarty_tpl->tpl_vars['ABOUT_FIELDS']->value['profile_views']['value'];?>
</li>
					</ul>
				  <?php } else { ?>
				    <h2<?php if ($_smarty_tpl->tpl_vars['USERNAME_COLOUR']->value != false) {?> style="<?php echo $_smarty_tpl->tpl_vars['USERNAME_COLOUR']->value;?>
"<?php }?>><?php echo $_smarty_tpl->tpl_vars['NICKNAME']->value;?>
</h2>
					<hr />
				  <?php }?>
				</div>
			  </div>
			</div>
			
			<div class="col-md-8">
			  <div class="card">
			    <div class="card-body">
				  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ABOUT_FIELDS']->value, 'field', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['field']->value) {
?>
					<?php if (is_numeric($_smarty_tpl->tpl_vars['key']->value)) {?>
					  <h3><?php echo $_smarty_tpl->tpl_vars['field']->value['title'];?>
</h3>
					  <p><?php echo $_smarty_tpl->tpl_vars['field']->value['value'];?>
</p>
					  <hr />
					<?php }?>
				  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			    </div>
			  </div>
			</div>
		  </div>
		</div>
		
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['TABS']->value, 'tab', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['tab']->value) {
?>
		<div class="tab-pane" id="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" role="tabpanel">
		  <?php $_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['tab']->value['include'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>
		</div>
		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		
	  </div>
    </div>
  </div>
 


  <?php if (!empty($_smarty_tpl->tpl_vars['WIDGETS']->value)) {?>
  </div>
  <div class="col-md-3">
  
<div class="googleads" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS']->value;?>
;">
<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value, $tmp) > 0) {?>
<br />
  <center>
	<ins class="adsbygoogle" data-ad-client="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value;?>
" data-ad-slot="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_SLOT']->value;?>
" data-ad-format="auto" data-full-width-responsive="true"></ins>
	<?php echo '<script'; ?>
>
		(adsbygoogle = window.adsbygoogle || []).push({});
	<?php echo '</script'; ?>
>
  </center>
<?php }?>
</div>

<div class="sidebar_banner" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER']->value;?>
;">
<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value, $tmp) > 0) {?>
<br />
  <center>
	<a href="<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value, $tmp) > 0) {
echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value;
} else { ?>#!<?php }?>" target="_blank" rel="nofollow">
		<img src="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value;?>
" style="max-width: 100%;">
	</a>
  </center>
<br />
<?php }?>
</div>
  
  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['WIDGETS']->value, 'widget');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['widget']->value) {
?>
    <?php echo $_smarty_tpl->tpl_vars['widget']->value;?>
<br/ >
  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
  </div>
  </div>
  <?php }?>
  
</div>
<?php } else { ?>
  <div class="alert alert-danger" role="alert">
     <?php echo $_smarty_tpl->tpl_vars['PRIVATE_PROFILE']->value;?>

  </div>
<?php }
if (isset($_smarty_tpl->tpl_vars['LOGGED_IN']->value)) {?>
  <?php if (isset($_smarty_tpl->tpl_vars['SELF']->value)) {?>
	<!-- Change background image modal -->
	<div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<h4 class="modal-title" id="imageModalLabel"><?php echo $_smarty_tpl->tpl_vars['CHANGE_BANNER']->value;?>
</h4>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  <span aria-hidden="true">&times;</span>
			</button>
		  </div>
		  <form action="" method="post" style="display:inline;" >
		    <div class="modal-body">
			  <select name="banner" class="image-picker show-html">
			    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['BANNERS']->value, 'banner');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['banner']->value) {
?>
				  <option data-img-src="<?php echo $_smarty_tpl->tpl_vars['banner']->value['src'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['banner']->value['name'];?>
"<?php if ($_smarty_tpl->tpl_vars['banner']->value['active'] == true) {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['banner']->value['name'];?>
</option>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			  </select>
			  <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
			  <input type="hidden" name="action" value="banner">
		    </div>
		    <div class="modal-footer">
			  <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo $_smarty_tpl->tpl_vars['CANCEL']->value;?>
</button>
			  <input type="submit" class="btn btn-success" value="<?php echo $_smarty_tpl->tpl_vars['SUBMIT']->value;?>
">
		    </div>
		  </form>
		</div>
	  </div>
	</div>
  <?php } else { ?>
	<?php if ($_smarty_tpl->tpl_vars['MOD_OR_ADMIN']->value != true) {?>
	<!-- Block user modal -->
	<div class="modal fade" id="blockModal" tabindex="-1" role="dialog" aria-labelledby="blockModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<h4 class="modal-title" id="blockModalLabel"><?php if (isset($_smarty_tpl->tpl_vars['BLOCK_USER']->value)) {
echo $_smarty_tpl->tpl_vars['BLOCK_USER']->value;
} else {
echo $_smarty_tpl->tpl_vars['UNBLOCK_USER']->value;
}?></h4>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  <span aria-hidden="true">&times;</span>
			</button>
		  </div>
		  <form action="" method="post" style="display:inline;" >
		    <div class="modal-body">
			  <p><?php if (isset($_smarty_tpl->tpl_vars['CONFIRM_BLOCK_USER']->value)) {
echo $_smarty_tpl->tpl_vars['CONFIRM_BLOCK_USER']->value;
} else {
echo $_smarty_tpl->tpl_vars['CONFIRM_UNBLOCK_USER']->value;
}?></p>
			  <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
			  <input type="hidden" name="action" value="block">
		    </div>
		    <div class="modal-footer">
			  <button type="button" class="btn btn-red" data-dismiss="modal"><?php echo $_smarty_tpl->tpl_vars['CANCEL']->value;?>
</button>
			  <input type="submit" class="btn btn-success" value="<?php echo $_smarty_tpl->tpl_vars['CONFIRM']->value;?>
">
		    </div>
		  </form>
		</div>
	  </div>
	</div>
	<?php }?>
  <?php }
}?>

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php if (isset($_smarty_tpl->tpl_vars['LOGGED_IN']->value)) {?>
  <?php echo '<script'; ?>
 type="text/javascript">
    function deletePost(post) {
	    if(confirm("<?php echo $_smarty_tpl->tpl_vars['CONFIRM_DELETE']->value;?>
")){
	        document.getElementById("delete" + post).submit();
        }
    }
  <?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 type="text/javascript">
    function deleteReply(post) {
    	if(confirm("<?php echo $_smarty_tpl->tpl_vars['CONFIRM_DELETE']->value;?>
")){
    		document.getElementById("deleteReply" + post).submit();
    	}
    }
  <?php echo '</script'; ?>
>
<?php }?> <?php }
}
