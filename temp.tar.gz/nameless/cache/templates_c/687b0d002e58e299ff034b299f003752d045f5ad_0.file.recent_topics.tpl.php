<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:31:01
  from '/var/www/nameless/custom/panel_templates/Default/collections/dashboard_stats/recent_topics.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600779c53b91c9_80071908',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '687b0d002e58e299ff034b299f003752d045f5ad' => 
    array (
      0 => '/var/www/nameless/custom/panel_templates/Default/collections/dashboard_stats/recent_topics.tpl',
      1 => 1611082601,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_600779c53b91c9_80071908 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="col-xl-3 col-md-6 mb-4">
    <div class="card stats-card border-left-primary shadow h-100 py-2">
        <div class="card-body">
            <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"><?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $_smarty_tpl->tpl_vars['VALUE']->value;?>
</div>
                </div>
                <div class="col-auto">
                    <?php echo $_smarty_tpl->tpl_vars['ICON']->value;?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php }
}
