<?php
/* Smarty version 3.1.33, created on 2021-01-27 08:38:23
  from '/var/www/nameless/custom/templates/DefaultRevamp/user/navigation.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_6011267f68aaa4_39086564',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6920d7cf87227bfd8764dbcf1e69597bbdf4f9d5' => 
    array (
      0 => '/var/www/nameless/custom/templates/DefaultRevamp/user/navigation.tpl',
      1 => 1611074674,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6011267f68aaa4_39086564 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="ui fluid vertical menu">
  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['CC_NAV_LINKS']->value, 'item', false, 'name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['name']->value => $_smarty_tpl->tpl_vars['item']->value) {
?>
    <a class="item<?php if (isset($_smarty_tpl->tpl_vars['item']->value['active'])) {?> active<?php }?>" href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</div><?php }
}
