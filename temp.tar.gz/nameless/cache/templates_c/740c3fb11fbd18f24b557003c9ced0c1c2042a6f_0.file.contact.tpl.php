<?php
/* Smarty version 3.1.33, created on 2021-01-20 01:29:37
  from '/var/www/nameless/custom/templates/MineBox/contact.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600787815f2724_74442384',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '740c3fb11fbd18f24b557003c9ced0c1c2042a6f' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/contact.tpl',
      1 => 1611094418,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_600787815f2724_74442384 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="container">
    <div class="card">
		<div class="card-body">
		<h1><i class="fa fa-envelope" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['CONTACT']->value;?>
</h1>
        <div class="row justify-content-center">
		<div class="col-md-8">
            <?php if (isset($_smarty_tpl->tpl_vars['SUCCESS']->value)) {?>
                <div class="alert alert-success">
                    <i class="fa fa-exclamation-triangle" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['SUCCESS']->value;?>

                </div>
            <?php }?>
            <form action="" method="post">
                <?php if (isset($_smarty_tpl->tpl_vars['ERROR']->value)) {?>
                    <div class="alert alert-danger">
                        <i class="fa fa-exclamation-triangle" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['ERROR']->value;?>

                    </div>
                <?php }?>
                <?php if (isset($_smarty_tpl->tpl_vars['ERROR_EMAIL']->value)) {?>
                    <div class="alert alert-danger">
                        <i class="fa fa-exclamation-triangle" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['ERROR_EMAIL']->value;?>

                    </div>
                <?php }?>			
                <div class="form-group">
					<label for="email"><i class="fa fa-at" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['EMAIL']->value;?>
</label>
                    <input type="email" name="email" id="email" class="form-control form-control-lg" placeholder="<?php echo $_smarty_tpl->tpl_vars['EMAIL']->value;?>
" tabindex="3">
                </div>
                <?php if (isset($_smarty_tpl->tpl_vars['ERROR_CONTENT']->value)) {?>
                    <div class="alert alert-danger">
                        <i class="fa fa-exclamation-triangle" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['ERROR_CONTENT']->value;?>

                    </div>
                <?php }?>
                <div class="form-group">
                    <label for="inputMessage"><i class="fa fa-file-text" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['MESSAGE']->value;?>
</label>
                    <textarea id="inputMessage" name="content" class="form-control" style="min-height:100px" placeholder="<?php echo $_smarty_tpl->tpl_vars['MESSAGE']->value;?>
" rows="5"></textarea>
                </div>
                <?php if (isset($_smarty_tpl->tpl_vars['RECAPTCHA']->value)) {?>
                    <div class="form-group">
                        <div class="g-recaptcha" data-sitekey="<?php echo $_smarty_tpl->tpl_vars['RECAPTCHA']->value;?>
"></div>
                    </div>
                <?php }?>
                <div class="form-group">
                    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
                    <input type="submit" class="btn btn-primary" value="<?php echo $_smarty_tpl->tpl_vars['SUBMIT']->value;?>
">
                </div>
            </form>
        </div>
    </div>
	</div>
	</div>
</div>

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
