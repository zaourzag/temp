<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:42:50
  from '/var/www/nameless/custom/templates/MineBox/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c8a76b812_07420283',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7b2bea3cee161109810810d006e2505a73b7f3aa' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/header.tpl',
      1 => 1611094419,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c8a76b812_07420283 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html<?php if (defined("HTML_CLASS")) {?> <?php echo @constant('HTML_CLASS');
}?> lang="<?php if (defined("HTML_LANG")) {
echo @constant('HTML_LANG');
} else { ?>en<?php }?>" <?php if (defined("HTML_RTL") && @constant('HTML_RTL') == true) {?> dir="rtl"<?php }?>>
<head>
    <!-- Standard Meta -->
    <meta charset="<?php if (defined("LANG_CHARSET")) {
echo @constant('LANG_CHARSET');
} else { ?>utf-8<?php }?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	<meta name="apple-mobile-web-app-capable" content="yes">
	
	<!-- fontawesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
	
    <!-- Site Properties -->
    <title><?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
</title>
    <meta name="author" content="<?php echo @constant('SITE_NAME');?>
">
	<?php if (isset($_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value, $tmp) > 0) {?>
	<meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value;?>
" />
	<?php }?>
	<?php if (isset($_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value, $tmp) > 0) {?>
	<meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value;?>
" />
	<?php }?>
	
	<meta name="theme-color" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
">
	<meta name="msapplication-TileColor" content="#2b5797">
	<meta name="msapplication-TileImage" content="/icons/mstile-144x144.png">
	<meta name="apple-mobile-web-app-title" content="<?php echo @constant('SITE_NAME');?>
">
	<meta name="application-name" content="<?php echo @constant('SITE_NAME');?>
">

	<!-- Twitter Tags -->
	<meta name="twitter:card" content="summary_large_image" />
	<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_TWITTER_SITE']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_TWITTER_SITE']->value, $tmp) > 0) {?>
	<meta name="twitter:site" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_TWITTER_SITE']->value;?>
" />
	<?php }?>
	<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_TWITTER_CREATOR']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_TWITTER_CREATOR']->value, $tmp) > 0) {?>
	<meta name="twitter:creator" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_TWITTER_CREATOR']->value;?>
">
	<?php }?>
	<meta name="twitter:title" content="<?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
" />
	<?php if (isset($_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value, $tmp) > 0) {?>
	<meta name="twitter:description" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value;?>
" />
	<?php }?>
	<meta name="twitter:image" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_LOGO']->value;?>
" />
	
	
	<!-- Facebook Tags -->
	<meta property="fb:app_id" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_FB_ID']->value;?>
" />
	<meta property="fb:page_id" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_FB_APP']->value;?>
" />
	
	<!-- Seo Meta -->
	<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_NORTON']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_NORTON']->value, $tmp) > 0) {?>
	<meta name="norton-safeweb-site-verification" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_NORTON']->value;?>
" />
	<?php }?>
	<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_WOT']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_WOT']->value, $tmp) > 0) {?>
	<meta name="wot-verification" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_WOT']->value;?>
" />
	<?php }?>
	<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_PINTEREST']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_PINTEREST']->value, $tmp) > 0) {?>
	<meta name="p:domain_verify" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_PINTEREST']->value;?>
" />
	<?php }?>
	<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_YANDEX']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_YANDEX']->value, $tmp) > 0) {?>
	<meta name="yandex-verification" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_YANDEX']->value;?>
" />
	<?php }?>
	<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_BING']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_BING']->value, $tmp) > 0) {?>
	<meta name="msvalidate.01" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_BING']->value;?>
" />
	<?php }?>
	<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_GOOGLE_VER']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_GOOGLE_VER']->value, $tmp) > 0) {?>
	<meta name="google-site-verification" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GOOGLE_VER']->value;?>
" />
	<?php }?>
    
	<!-- Meta property -->
    <meta property="og:title" content="<?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
" />
    <meta property="og:type" content="website" />
	<meta property="og:site_name" content="<?php echo @constant('SITE_NAME');?>
" />
    <meta property="og:url" content="<?php echo $_smarty_tpl->tpl_vars['OG_URL']->value;?>
" />
    <meta property="og:image" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_LOGO']->value;?>
" />
	<?php if (isset($_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value, $tmp) > 0) {?>
	<meta property="og:description" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value;?>
" />
	<?php }?>
	
	<!-- Favicon Tags -->
	<link rel="shortcut icon" icon" type="image/x-icon" href="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_FAVICON']->value;?>
" />
	<link rel="icon" type="image/x-icon" href="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_FAVICON']->value;?>
">
	 
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['TEMPLATE_CSS']->value, 'css');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['css']->value) {
?>
        <?php echo $_smarty_tpl->tpl_vars['css']->value;?>

    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	
	<meta name="google-analytics" content="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GA_ID']->value;?>
" />
	
	<?php echo '<script'; ?>
 async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GA_ID']->value;?>
"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());

		gtag('config', '<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GA_ID']->value;?>
');
	<?php echo '</script'; ?>
>
	
	<?php echo '<script'; ?>
 async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"><?php echo '</script'; ?>
>
	
	
	
		<!------------------------------------------------>
		<!------------------------------------------------>
		<!-------- Add Here Your Java Script Code -------->
		<!------------------------------------------------>
		<!------------------------------------------------>
	
	
</head>

<body><?php }
}
