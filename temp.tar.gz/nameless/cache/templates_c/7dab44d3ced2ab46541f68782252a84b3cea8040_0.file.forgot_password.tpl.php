<?php
/* Smarty version 3.1.33, created on 2021-01-20 01:34:16
  from '/var/www/nameless/custom/templates/MineBox/forgot_password.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600788984e4489_32198865',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7dab44d3ced2ab46541f68782252a84b3cea8040' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/forgot_password.tpl',
      1 => 1611094419,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_600788984e4489_32198865 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="container">
    <div class="card">
	<div class="card-body">
		<h1><i class="fa fa-unlock-alt" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['FORGOT_PASSWORD']->value;?>
</h1>
        <div class="row justify-content-center">
		<div class="col-md-12">
            <form role="form" action="" method="post">
                <div class="alert alert-info">
                        <i class="fa fa-exclamation-triangle" style="width: auto;margin: 0 .75em 0 0;"></i><?php echo $_smarty_tpl->tpl_vars['FORGOT_PASSWORD_INSTRUCTIONS']->value;?>

				</div>

                <?php if (isset($_smarty_tpl->tpl_vars['ERROR']->value)) {?>
                    <div class="alert alert-danger">
                        <i class="fa fa-exclamation-triangle" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['ERROR']->value;?>

                    </div>
                <?php } elseif (isset($_smarty_tpl->tpl_vars['SUCCESS']->value)) {?>
                    <div class="alert alert-success">
                        <i class="fa fa-exclamation-triangle" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['SUCCESS']->value;?>

                    </div>
                <?php }?>

                <div class="form-group">
                    <label for="inputEmail"><i class="fa fa-at" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['EMAIL_ADDRESS']->value;?>
</label>
                    <input type="email" id="inputEmail" name="email" placeholder="<?php echo $_smarty_tpl->tpl_vars['EMAIL_ADDRESS']->value;?>
" class="form-control">
                </div>
                <div class="form-group">
                    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
                    <input type="submit" class="btn btn-success" value="<?php echo $_smarty_tpl->tpl_vars['SUBMIT']->value;?>
">
                </div>
            </form>
        </div>
		</div>
    </div>
	</div>
</div>

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
