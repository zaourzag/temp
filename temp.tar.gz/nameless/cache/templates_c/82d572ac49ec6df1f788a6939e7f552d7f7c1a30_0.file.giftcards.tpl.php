<?php
/* Smarty version 3.1.33, created on 2021-01-20 12:29:36
  from '/var/www/nameless/custom/panel_templates/Default/tebex/giftcards.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_6008223029d963_49726474',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '82d572ac49ec6df1f788a6939e7f552d7f7c1a30' => 
    array (
      0 => '/var/www/nameless/custom/panel_templates/Default/tebex/giftcards.tpl',
      1 => 1611105722,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:sidebar.tpl' => 1,
    'file:footer.tpl' => 1,
    'file:scripts.tpl' => 1,
  ),
),false)) {
function content_6008223029d963_49726474 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <?php $_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <?php $_smarty_tpl->_subTemplateRender('file:sidebar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark"><?php echo $_smarty_tpl->tpl_vars['GIFT_CARDS']->value;?>
</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo $_smarty_tpl->tpl_vars['PANEL_INDEX']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['DASHBOARD']->value;?>
</a></li>
                            <li class="breadcrumb-item active"><?php echo $_smarty_tpl->tpl_vars['BUYCRAFT']->value;?>
</li>
                            <li class="breadcrumb-item active"><?php echo $_smarty_tpl->tpl_vars['GIFT_CARDS']->value;?>
</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php if (isset($_smarty_tpl->tpl_vars['NEW_UPDATE']->value)) {?>
                <?php if ($_smarty_tpl->tpl_vars['NEW_UPDATE_URGENT']->value == true) {?>
                <div class="alert alert-danger">
                    <?php } else { ?>
                    <div class="alert alert-primary alert-dismissible" id="updateAlert">
                        <button type="button" class="close" id="closeUpdate" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <?php }?>
                        <?php echo $_smarty_tpl->tpl_vars['NEW_UPDATE']->value;?>

                        <br />
                        <a href="<?php echo $_smarty_tpl->tpl_vars['UPDATE_LINK']->value;?>
" class="btn btn-primary" style="text-decoration:none"><?php echo $_smarty_tpl->tpl_vars['UPDATE']->value;?>
</a>
                        <hr />
                        <?php echo $_smarty_tpl->tpl_vars['CURRENT_VERSION']->value;?>
<br />
                        <?php echo $_smarty_tpl->tpl_vars['NEW_VERSION']->value;?>

                    </div>
                    <?php }?>

                    <div class="card">
                        <div class="card-body">
                            <a class="btn btn-primary" href="<?php echo $_smarty_tpl->tpl_vars['NEW_GIFT_CARD_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['NEW_GIFT_CARD']->value;?>
</a>
                            <hr />

                            <?php if (isset($_smarty_tpl->tpl_vars['SUCCESS']->value)) {?>
                                <div class="alert alert-success alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h5><i class="icon fa fa-check"></i> <?php echo $_smarty_tpl->tpl_vars['SUCCESS_TITLE']->value;?>
</h5>
                                    <?php echo $_smarty_tpl->tpl_vars['SUCCESS']->value;?>

                                </div>
                            <?php }?>

                            <?php if (isset($_smarty_tpl->tpl_vars['ERRORS']->value) && count($_smarty_tpl->tpl_vars['ERRORS']->value)) {?>
                                <div class="alert alert-danger alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h5><i class="icon fas fa-exclamation-triangle"></i> <?php echo $_smarty_tpl->tpl_vars['ERRORS_TITLE']->value;?>
</h5>
                                    <ul>
                                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ERRORS']->value, 'error');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['error']->value) {
?>
                                            <li><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</li>
                                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                    </ul>
                                </div>
                            <?php }?>

                            <?php if (isset($_smarty_tpl->tpl_vars['NO_GIFT_CARDS']->value)) {?>
                                <p><?php echo $_smarty_tpl->tpl_vars['NO_GIFT_CARDS']->value;?>
</p>
                            <?php } else { ?>
                                <div class="table-responsive">
                                    <table class="table table-striped dataTables-giftcards">
                                        <thead>
                                        <tr>
                                            <th><?php echo $_smarty_tpl->tpl_vars['GIFT_CARD_CODE']->value;?>
</th>
                                            <th><?php echo $_smarty_tpl->tpl_vars['GIFT_CARD_NOTE']->value;?>
</th>
                                            <th><?php echo $_smarty_tpl->tpl_vars['GIFT_CARD_BALANCE_REMAINING']->value;?>
</th>
                                            <th><?php echo $_smarty_tpl->tpl_vars['GIFT_CARD_ACTIVE']->value;?>
</th>
                                            <th><?php echo $_smarty_tpl->tpl_vars['VIEW']->value;?>
</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ALL_GIFT_CARDS']->value, 'giftcard');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['giftcard']->value) {
?>
                                            <tr>
                                                <td><?php echo $_smarty_tpl->tpl_vars['giftcard']->value['code'];?>
</td>
                                                <td><?php echo $_smarty_tpl->tpl_vars['giftcard']->value['note'];?>
</td>
                                                <td><?php echo $_smarty_tpl->tpl_vars['giftcard']->value['remaining'];?>
</td>
                                                <td><?php if ($_smarty_tpl->tpl_vars['giftcard']->value['void']) {?><i class="fas fa-times-circle fa-2x text-danger"></i><?php } else { ?><i class="fas fa-check-circle fa-2x text-success"></i><?php }?></td>
                                                <td><a href="<?php echo $_smarty_tpl->tpl_vars['giftcard']->value['view_link'];?>
" class="btn btn-primary btn-sm"><?php echo $_smarty_tpl->tpl_vars['VIEW']->value;?>
</a></td>
                                            </tr>
                                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php }?>

                        </div>
                    </div>

                    <!-- Spacing -->
                    <div style="height:1rem;"></div>

                </div>
        </section>
    </div>

    <?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</div>
<!-- ./wrapper -->

<?php $_smarty_tpl->_subTemplateRender('file:scripts.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php echo '<script'; ?>
 type="text/javascript">
    function showCancelModal(){
        $('#cancelModal').modal().show();
    }
<?php echo '</script'; ?>
>

</body>
</html><?php }
}
