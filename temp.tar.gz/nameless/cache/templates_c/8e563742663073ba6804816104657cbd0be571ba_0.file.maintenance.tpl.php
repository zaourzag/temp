<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:33:30
  from '/var/www/nameless/custom/templates/Monarch/maintenance.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077a5a5cc914_17445953',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8e563742663073ba6804816104657cbd0be571ba' => 
    array (
      0 => '/var/www/nameless/custom/templates/Monarch/maintenance.tpl',
      1 => 1611098705,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
  ),
),false)) {
function content_60077a5a5cc914_17445953 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <div class="ui container" id="error-maintenance">
      <div class="ui segment">
        <h2 class="ui header"><?php echo $_smarty_tpl->tpl_vars['MAINTENANCE_TITLE']->value;?>
</h2>
        <div class="ui divider"></div>
        <p><?php echo $_smarty_tpl->tpl_vars['MAINTENANCE_MESSAGE']->value;?>
</p>
        <div class="ui buttons">
          <button class="ui primary button" onclick="javascript:history.go(-1)"><?php echo $_smarty_tpl->tpl_vars['BACK']->value;?>
</button>
          <div class="or"></div>
          <button class="ui positive button" onclick="window.location.reload()"><?php echo $_smarty_tpl->tpl_vars['RETRY']->value;?>
</button>
        </div>
      </div>
    </div>
  
  </body>
</html><?php }
}
