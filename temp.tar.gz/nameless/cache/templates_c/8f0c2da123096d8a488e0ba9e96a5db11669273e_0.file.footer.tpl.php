<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:43
  from '/var/www/nameless/custom/templates/Cesium/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c4766ed15_72289795',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8f0c2da123096d8a488e0ba9e96a5db11669273e' => 
    array (
      0 => '/var/www/nameless/custom/templates/Cesium/footer.tpl',
      1 => 1611091445,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c4766ed15_72289795 (Smarty_Internal_Template $_smarty_tpl) {
?>					</div>
				</div>

				<?php if (isset($_smarty_tpl->tpl_vars['GLOBAL_WARNING_TITLE']->value)) {?>
					<div class="modal fade show-punishment" id="modal-acknowledge">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">
									<div class="modal-title"><?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_TITLE']->value;?>
</div>
								</div>
								<div class="modal-body">
									<?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_REASON']->value;?>

								</div>
								<div class="modal-footer">
									<a href="<?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_ACKNOWLEDGE_LINK']->value;?>
" class="btn btn-warning btn-sm"><?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_ACKNOWLEDGE']->value;?>
</a>
								</div>
							</div>
						</div>
					</div>
				<?php }?>

				<div class="chatbox" id="chatbox-bottom"></div>

			</div>

			<footer class="footer">
				<div class="footer-extra">
					<div class="container">
						<div class="footer-links">
							<?php if (($_smarty_tpl->tpl_vars['CSM']->value['particles'])) {?>
								<a href="#" id="toggleParticles"><?php echo $_smarty_tpl->tpl_vars['CSM']->value['toggleParticles'];?>
</a>
							<?php }?>
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['FOOTER_NAVIGATION']->value, 'link');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['link']->value) {
?>
								<?php if (empty($_smarty_tpl->tpl_vars['link']->value['items'])) {?>
									<a href="<?php echo $_smarty_tpl->tpl_vars['link']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['link']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['link']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['link']->value['title'];?>
</a>
								<?php } else { ?>
									<div class="dropdown">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_smarty_tpl->tpl_vars['link']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['link']->value['title'];?>
</a>
										<div class="dropdown-menu">
											<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['link']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?>
												<a href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
" class="dropdown-item"><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a>
											<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
										</div>
									</div>
								<?php }?>
							<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
							<a href="<?php echo $_smarty_tpl->tpl_vars['TERMS_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['TERMS_TEXT']->value;?>
</a>
							<a href="<?php echo $_smarty_tpl->tpl_vars['PRIVACY_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['PRIVACY_TEXT']->value;?>
</a>
						</div>
						<div class="footer-social">
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['SOCIAL_MEDIA_ICONS']->value, 'icon');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['icon']->value) {
?>
								<a href="<?php echo $_smarty_tpl->tpl_vars['icon']->value['link'];?>
" target="_blank">
									<i class="<?php echo $_smarty_tpl->tpl_vars['icon']->value['long'] == "envelope" ? 'fas' : 'fab';?>
 fa-<?php echo $_smarty_tpl->tpl_vars['icon']->value['long'];?>
-square"></i>
								</a>
							<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
						</div>
					</div>
				</div>
				<div class="footer-content">
					<div class="container">
						<?php echo $_smarty_tpl->tpl_vars['CSM']->value['footerContent'];?>

						<?php if (($_smarty_tpl->tpl_vars['PAGE_LOAD_TIME']->value)) {?>
							<div class="loading-time"></div>
						<?php }?>
					</div>
				</div>
			</footer>

		</div>

		<?php if (($_smarty_tpl->tpl_vars['CSM']->value['scrollToTop'])) {?>
			<div class="scrollToTop" id="scrollToTop">
				<a class="btn btn-scrollToTop" href="#">🡱</a>
			</div>
		<?php }?>
		
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['TEMPLATE_JS']->value, 'script');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['script']->value) {
?>
			<?php echo $_smarty_tpl->tpl_vars['script']->value;?>

		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		
		<?php if ((isset($_smarty_tpl->tpl_vars['NEW_UPDATE']->value) && $_smarty_tpl->tpl_vars['NEW_UPDATE_URGENT']->value !== true)) {?>
			<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['CSM']->value['template']['path'];?>
/assets/js/update.js"><?php echo '</script'; ?>
>
		<?php }?>

	</body>
</html><?php }
}
