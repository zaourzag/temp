<?php
/* Smarty version 3.1.33, created on 2021-01-23 02:21:08
  from '/var/www/nameless/custom/templates/DefaultRevamp/forum/profile_tab.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600b8814e06f71_26233187',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9240886bd9ba659fe1498790892d199ab8c5342a' => 
    array (
      0 => '/var/www/nameless/custom/templates/DefaultRevamp/forum/profile_tab.tpl',
      1 => 1611074674,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_600b8814e06f71_26233187 (Smarty_Internal_Template $_smarty_tpl) {
?><h3 class="ui header">
  <?php echo $_smarty_tpl->tpl_vars['PF_LATEST_POSTS_TITLE']->value;?>

</h3>

<?php if (isset($_smarty_tpl->tpl_vars['NO_POSTS']->value)) {?>
  <div class="ui info message">
    <div class="content">
      <?php echo $_smarty_tpl->tpl_vars['NO_POSTS']->value;?>

    </div>
  </div>
<?php } else { ?>
  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['PF_LATEST_POSTS']->value, 'post');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['post']->value) {
?>
    <h4 class="ui dividing header">
	  <div class="sub header right floated" data-toggle="tooltip" data-content="<?php echo $_smarty_tpl->tpl_vars['post']->value['date_full'];?>
"><?php echo $_smarty_tpl->tpl_vars['post']->value['date_friendly'];?>
</div>
      <a href="<?php echo $_smarty_tpl->tpl_vars['post']->value['link'];?>
" data-toggle="popup"><?php echo $_smarty_tpl->tpl_vars['post']->value['title'];?>
</a>
      <div class="ui wide popup">
        <h4 class="ui header"><?php echo $_smarty_tpl->tpl_vars['post']->value['title'];?>
</h4>
        <?php echo $_smarty_tpl->tpl_vars['post']->value['date_full'];?>

      </div>
    </h4>
    <div class="forum_post"><?php echo $_smarty_tpl->tpl_vars['post']->value['content'];?>
</div>
  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
}
}
}
