<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:30:50
  from '/var/www/nameless/custom/templates/Monarch/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600779ba576333_87738238',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9282deeb1e2fa1f5372ee71aaac0d2e9bffa1d4c' => 
    array (
      0 => '/var/www/nameless/custom/templates/Monarch/header.tpl',
      1 => 1611098705,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_600779ba576333_87738238 (Smarty_Internal_Template $_smarty_tpl) {
if (defined("HTML_CLASS")) {
$_smarty_tpl->_assignInScope('HTMLCLASS', " ".((string)@constant('HTML_CLASS')));
}
if (defined("HTML_LANG")) {
$_smarty_tpl->_assignInScope('HTMLLANG', " language='".((string)@constant('HTML_LANG'))."'");
} else {
$_smarty_tpl->_assignInScope('HTMLLANG', " language='en'");
}
if (defined("HTML_RTL") && @constant('HTML_RTL') == true) {
$_smarty_tpl->_assignInScope('HTMLRTL', " dir='rtl'");
}
if (defined("LANG_CHARSET")) {
$_smarty_tpl->_assignInScope('METACHARSET', ((string)@constant('LANG_CHARSET')));
} else {
$_smarty_tpl->_assignInScope('METACHARSET', "utf-8");
}
if (isset($_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value, $tmp) > 0) {
$_smarty_tpl->_assignInScope('PAGEDESCRIPTION', ((string)$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value));
} else {
$_smarty_tpl->_assignInScope('PAGEDESCRIPTION', " ");
}
if (isset($_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value, $tmp) > 0) {
$_smarty_tpl->_assignInScope('PAGEKEYWORDS', ((string)$_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value));
} else {
$_smarty_tpl->_assignInScope('PAGEKEYWORDS', " ");
}?>

<!DOCTYPE html>
<html<?php echo $_smarty_tpl->tpl_vars['HTMLCLASS']->value;
echo $_smarty_tpl->tpl_vars['HTMLLANG']->value;
echo $_smarty_tpl->tpl_vars['HTMLRTL']->value;?>
>
  <head>

    <meta charset="<?php echo $_smarty_tpl->tpl_vars['METACHARSET']->value;?>
">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <title><?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
</title>

    <meta name="author" content="<?php echo @constant('SITE_NAME');?>
">
    <meta name='description' content='<?php echo $_smarty_tpl->tpl_vars['PAGEDESCRIPTION']->value;?>
' />
    <meta name='keywords' content='<?php echo $_smarty_tpl->tpl_vars['PAGEKEYWORDS']->value;?>
' />

    <meta property="og:title" content="<?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="<?php echo $_smarty_tpl->tpl_vars['OG_URL']->value;?>
" />
    <meta property="og:image" content="<?php echo $_smarty_tpl->tpl_vars['OG_IMAGE']->value;?>
" />
    <meta property='og:description' content='<?php echo $_smarty_tpl->tpl_vars['PAGEDESCRIPTION']->value;?>
' />

    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['TEMPLATE_CSS']->value, 'css');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['css']->value) {
?>
      <?php echo $_smarty_tpl->tpl_vars['css']->value;?>

    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
  </head>

  <body id="page-<?php if (is_numeric(@constant('PAGE'))) {
echo $_smarty_tpl->tpl_vars['TITLE']->value;
} else {
echo @constant('PAGE');
}?>">
<?php }
}
