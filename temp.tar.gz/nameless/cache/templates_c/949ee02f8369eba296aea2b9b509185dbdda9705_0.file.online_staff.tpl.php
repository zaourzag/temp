<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:17
  from '/var/www/nameless/custom/templates/Aether/widgets/online_staff.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c2d65b217_21591307',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '949ee02f8369eba296aea2b9b509185dbdda9705' => 
    array (
      0 => '/var/www/nameless/custom/templates/Aether/widgets/online_staff.tpl',
      1 => 1599551086,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c2d65b217_21591307 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="card">
    <div class="card-header header-theme">
        <span><i class="fas fa-users-cog"></i> <?php echo $_smarty_tpl->tpl_vars['ONLINE_STAFF']->value;?>
</span>
    </div>
    <div class="card-block">
        <?php if (isset($_smarty_tpl->tpl_vars['ONLINE_STAFF_LIST']->value)) {?> <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ONLINE_STAFF_LIST']->value, 'user', false, NULL, 'online_staff_arr', array (
  'last' => true,
  'iteration' => true,
  'total' => true,
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
$_smarty_tpl->tpl_vars['__smarty_foreach_online_staff_arr']->value['iteration']++;
$_smarty_tpl->tpl_vars['__smarty_foreach_online_staff_arr']->value['last'] = $_smarty_tpl->tpl_vars['__smarty_foreach_online_staff_arr']->value['iteration'] === $_smarty_tpl->tpl_vars['__smarty_foreach_online_staff_arr']->value['total'];
?>
        <a style="<?php echo $_smarty_tpl->tpl_vars['user']->value['style'];?>
" href="<?php echo $_smarty_tpl->tpl_vars['user']->value['profile'];?>
" data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
" data-html="true" data-placement="top"><img src="<?php echo $_smarty_tpl->tpl_vars['user']->value['avatar'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['user']->value['nickname'];?>
" class="img-rounded" style="max-height:20px;max-width:20px;"> <?php echo $_smarty_tpl->tpl_vars['user']->value['username'];?>
</a>        <?php if (!(isset($_smarty_tpl->tpl_vars['__smarty_foreach_online_staff_arr']->value['last']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_online_staff_arr']->value['last'] : null)) {?><br /><?php }?> <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?> <?php } else { ?> <?php echo $_smarty_tpl->tpl_vars['NO_STAFF_ONLINE']->value;?>
 <?php }?>
    </div>
</div><?php }
}
