<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:30:41
  from '/var/www/nameless/custom/panel_templates/Default/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600779b1b92c29_05938094',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9ead9db8bd8c1086ba5b1ebca2d12ca3c53f6061' => 
    array (
      0 => '/var/www/nameless/custom/panel_templates/Default/footer.tpl',
      1 => 1611082599,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_600779b1b92c29_05938094 (Smarty_Internal_Template $_smarty_tpl) {
?><footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span><?php echo $_smarty_tpl->tpl_vars['PAGE_LOAD_TIME']->value;?>
</span>&nbsp;&nbsp;&nbsp;&nbsp;
            <span>&copy; NamelessMC <?php echo date('Y');?>
</span><br /><br />
                        <a href="https://github.com/NamelessMC/Nameless" target="_blank"><i class="fab fa-github fa-fw"></i> <?php echo $_smarty_tpl->tpl_vars['SOURCE']->value;?>
</a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="https://namelessmc.com" target="_blank"><i class="fas fa-life-ring fa-fw"></i> <?php echo $_smarty_tpl->tpl_vars['SUPPORT']->value;?>
</a>
        </div>
    </div>
</footer><?php }
}
