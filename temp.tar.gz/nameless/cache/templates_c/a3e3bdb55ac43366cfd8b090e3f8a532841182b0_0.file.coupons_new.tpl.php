<?php
/* Smarty version 3.1.33, created on 2021-01-20 12:28:56
  from '/var/www/nameless/custom/panel_templates/Default/tebex/coupons_new.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600822086da269_09374147',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a3e3bdb55ac43366cfd8b090e3f8a532841182b0' => 
    array (
      0 => '/var/www/nameless/custom/panel_templates/Default/tebex/coupons_new.tpl',
      1 => 1611105722,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:sidebar.tpl' => 1,
    'file:footer.tpl' => 1,
    'file:scripts.tpl' => 1,
  ),
),false)) {
function content_600822086da269_09374147 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <?php $_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <?php $_smarty_tpl->_subTemplateRender('file:sidebar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark"><?php echo $_smarty_tpl->tpl_vars['COUPONS']->value;?>
</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo $_smarty_tpl->tpl_vars['PANEL_INDEX']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['DASHBOARD']->value;?>
</a></li>
                            <li class="breadcrumb-item active"><?php echo $_smarty_tpl->tpl_vars['BUYCRAFT']->value;?>
</li>
                            <li class="breadcrumb-item active"><?php echo $_smarty_tpl->tpl_vars['COUPONS']->value;?>
</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php if (isset($_smarty_tpl->tpl_vars['NEW_UPDATE']->value)) {?>
                <?php if ($_smarty_tpl->tpl_vars['NEW_UPDATE_URGENT']->value == true) {?>
                <div class="alert alert-danger">
                    <?php } else { ?>
                    <div class="alert alert-primary alert-dismissible" id="updateAlert">
                        <button type="button" class="close" id="closeUpdate" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <?php }?>
                        <?php echo $_smarty_tpl->tpl_vars['NEW_UPDATE']->value;?>

                        <br />
                        <a href="<?php echo $_smarty_tpl->tpl_vars['UPDATE_LINK']->value;?>
" class="btn btn-primary" style="text-decoration:none"><?php echo $_smarty_tpl->tpl_vars['UPDATE']->value;?>
</a>
                        <hr />
                        <?php echo $_smarty_tpl->tpl_vars['CURRENT_VERSION']->value;?>
<br />
                        <?php echo $_smarty_tpl->tpl_vars['NEW_VERSION']->value;?>

                    </div>
                    <?php }?>

                    <div class="card">
                        <div class="card-body">
                            <h5 style="display:inline"><?php echo $_smarty_tpl->tpl_vars['CREATING_COUPON']->value;?>
</h5>
                            <div class="float-md-right">
                                <button role="button" class="btn btn-warning" onclick="showCancelModal()"><?php echo $_smarty_tpl->tpl_vars['CANCEL']->value;?>
</button>
                            </div>
                            <hr />

                            <?php if (isset($_smarty_tpl->tpl_vars['SUCCESS']->value)) {?>
                                <div class="alert alert-success alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h5><i class="icon fa fa-check"></i> <?php echo $_smarty_tpl->tpl_vars['SUCCESS_TITLE']->value;?>
</h5>
                                    <?php echo $_smarty_tpl->tpl_vars['SUCCESS']->value;?>

                                </div>
                            <?php }?>

                            <?php if (isset($_smarty_tpl->tpl_vars['ERRORS']->value) && count($_smarty_tpl->tpl_vars['ERRORS']->value)) {?>
                                <div class="alert alert-danger alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h5><i class="icon fas fa-exclamation-triangle"></i> <?php echo $_smarty_tpl->tpl_vars['ERRORS_TITLE']->value;?>
</h5>
                                    <ul>
                                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ERRORS']->value, 'error');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['error']->value) {
?>
                                            <li><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</li>
                                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                    </ul>
                                </div>
                            <?php }?>

                            <form action="" method="post">
                                <div class="form-group">
                                    <label for="inputCode"><?php echo $_smarty_tpl->tpl_vars['COUPON_CODE']->value;?>
</label>
                                    <input id="inputCode" type="text" class="form-control" name="code" placeholder="<?php echo $_smarty_tpl->tpl_vars['COUPON_CODE']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['COUPON_CODE_VALUE']->value;?>
">
                                </div>

                                <div class="form-group">
                                    <label for="inputNote"><?php echo $_smarty_tpl->tpl_vars['COUPON_NOTE']->value;?>
</label>
                                    <textarea class="form-control" id="inputNote" name="note"><?php echo $_smarty_tpl->tpl_vars['COUPON_NOTE_VALUE']->value;?>
</textarea>
                                </div>

                                <div class="form-group">
                                    <label for="inputEffectiveOn"><?php echo $_smarty_tpl->tpl_vars['EFFECTIVE_ON']->value;?>
</label>
                                    <select class="form-control" name="effective_on" id="inputEffectiveOn">
                                        <option value="1"<?php if ($_smarty_tpl->tpl_vars['EFFECTIVE_ON_VALUE']->value == '1') {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['CART']->value;?>
</option>
                                        <option value="2"<?php if ($_smarty_tpl->tpl_vars['EFFECTIVE_ON_VALUE']->value == '2') {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['PACKAGE']->value;?>
</option>
                                        <option value="3"<?php if ($_smarty_tpl->tpl_vars['EFFECTIVE_ON_VALUE']->value == '3') {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['CATEGORY']->value;?>
</option>
                                    </select>
                                </div>

                                <div class="form-group" id="effectiveOnPackages">
                                    <label for="inputEffectiveOnPackages"><?php echo $_smarty_tpl->tpl_vars['PACKAGES']->value;?>
</label> <small><?php echo $_smarty_tpl->tpl_vars['SELECT_MULTIPLE_WITH_CTRL']->value;?>
</small>
                                    <select class="form-control" id="inputEffectiveOnPackages" name="packages[]" multiple>
                                        <?php if (count($_smarty_tpl->tpl_vars['AVAILABLE_PACKAGES']->value)) {?>
                                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['AVAILABLE_PACKAGES']->value, 'available_package');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['available_package']->value) {
?>
                                                <option value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['available_package']->value->id, ENT_QUOTES, 'UTF-8', true);?>
"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['available_package']->value->name, ENT_QUOTES, 'UTF-8', true);?>
</option>
                                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                        <?php }?>
                                    </select>
                                </div>

                                <div class="form-group" id="effectiveOnCategories">
                                    <label for="inputEffectiveOnCategories"><?php echo $_smarty_tpl->tpl_vars['CATEGORIES']->value;?>
</label> <small><?php echo $_smarty_tpl->tpl_vars['SELECT_MULTIPLE_WITH_CTRL']->value;?>
</small>
                                    <select class="form-control" id="inputEffectiveOnCategories" name="categories[]" multiple>
                                        <?php if (count($_smarty_tpl->tpl_vars['AVAILABLE_CATEGORIES']->value)) {?>
                                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['AVAILABLE_CATEGORIES']->value, 'available_category');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['available_category']->value) {
?>
                                                <option value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['available_category']->value->id, ENT_QUOTES, 'UTF-8', true);?>
"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['available_category']->value->name, ENT_QUOTES, 'UTF-8', true);?>
</option>
                                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                        <?php }?>
                                    </select>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="inputDiscountType"><?php echo $_smarty_tpl->tpl_vars['DISCOUNT_TYPE']->value;?>
</label>
                                            <select class="form-control" id="inputDiscountType" name="discount_type">
                                                <option value="value"><?php echo $_smarty_tpl->tpl_vars['DISCOUNT_TYPE_VALUE']->value;?>
</option>
                                                <option value="percentage"><?php echo $_smarty_tpl->tpl_vars['DISCOUNT_TYPE_PERCENTAGE']->value;?>
</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group" id="discountTypeValue">
                                            <label for="inputDiscountTypeValue"><?php echo $_smarty_tpl->tpl_vars['DISCOUNT_TYPE_VALUE']->value;?>
</label>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"><?php echo $_smarty_tpl->tpl_vars['CURRENCY']->value;?>
</span>
                                                </div>
                                                <input type="number" class="form-control" name="discount_amount" id="inputDiscountTypeValue" placeholder="<?php echo $_smarty_tpl->tpl_vars['DISCOUNT_TYPE_VALUE']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['DISCOUNT_TYPE_VALUE_VALUE']->value;?>
" step="0.01">
                                            </div>
                                        </div>
                                        <div class="form-group" id="discountTypePercentage">
                                            <label for="inputDiscountTypePercentage"><?php echo $_smarty_tpl->tpl_vars['DISCOUNT_TYPE_PERCENTAGE']->value;?>
</label>
                                            <div class="input-group mb-3">
                                                <input type="number" class="form-control" name="discount_percentage" id="inputDiscountTypePercentage" placeholder="<?php echo $_smarty_tpl->tpl_vars['DISCOUNT_TYPE_PERCENTAGE']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['DISCOUNT_TYPE_PERCENTAGE_VALUE']->value;?>
">
                                                <div class="input-group-append">
                                                    <span class="input-group-text">%</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 align-self-center">
                                        <div class="form-group">
                                            <label for="inputRedeemUnlimited"><?php echo $_smarty_tpl->tpl_vars['UNLIMITED_USAGE']->value;?>
</label>
                                            <input type="checkbox" name="redeem_unlimited" id="inputRedeemUnlimited" class="js-switch" <?php if ($_smarty_tpl->tpl_vars['UNLIMITED_USAGE_VALUE']->value) {?>checked <?php }?>/>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group" id="redeemLimit">
                                            <label for="inputRedeemLimit"><?php echo $_smarty_tpl->tpl_vars['USES']->value;?>
</label>
                                            <input type="number" class="form-control" name="expire_limit" id="inputRedeemLimit" placeholder="<?php echo $_smarty_tpl->tpl_vars['USES']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['USES_VALUE']->value;?>
">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 align-self-center">
                                        <div class="form-group">
                                            <label for="inputExpireNever"><?php echo $_smarty_tpl->tpl_vars['NEVER_EXPIRE']->value;?>
</label>
                                            <input type="checkbox" name="expire_never" id="inputExpireNever" class="js-switch" <?php if ($_smarty_tpl->tpl_vars['NEVER_EXPIRE_VALUE']->value) {?>checked <?php }?>/>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group" id="expireDate">
                                            <label for="inputExpiryDate"><?php echo $_smarty_tpl->tpl_vars['EXPIRY_DATE']->value;?>
</label>
                                            <input type="text" class="form-control" name="expire_date" id="inputExpiryDate" placeholder="<?php echo $_smarty_tpl->tpl_vars['EXPIRY_DATE']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['EXPIRY_DATE_VALUE']->value;?>
">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputStartDate"><?php echo $_smarty_tpl->tpl_vars['START_DATE']->value;?>
</label>
                                    <input type="text" class="form-control" name="start_date" id="inputStartDate" placeholder="<?php echo $_smarty_tpl->tpl_vars['START_DATE']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['START_DATE_VALUE']->value;?>
">
                                </div>

                                <div class="form-group">
                                    <label for="inputBasketType"><?php echo $_smarty_tpl->tpl_vars['BASKET_TYPE']->value;?>
</label>
                                    <select class="form-control" name="basket_type" id="inputBasketType">
                                        <option value="both"<?php if ($_smarty_tpl->tpl_vars['BASKET_TYPE_VALUE']->value == 'both') {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['ALL_PURCHASES']->value;?>
</option>
                                        <option value="single"<?php if ($_smarty_tpl->tpl_vars['BASKET_TYPE_VALUE']->value == 'single') {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['ONE_OFF_PURCHASES']->value;?>
</option>
                                        <option value="subscription"<?php if ($_smarty_tpl->tpl_vars['BASKET_TYPE_VALUE']->value == 'subscription') {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['SUBSCRIPTIONS']->value;?>
</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="inputDiscountApplicationType"><?php echo $_smarty_tpl->tpl_vars['DISCOUNT_APPLICATION_TYPE']->value;?>
</label>
                                    <select class="form-control" name="discount_application_method" id="inputDiscountApplicationType">
                                        <option value="1"<?php if ($_smarty_tpl->tpl_vars['DISCOUNT_APPLICATION_TYPE_VALUE']->value == '1') {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['EACH_PACKAGE']->value;?>
</option>
                                        <option value="2"<?php if ($_smarty_tpl->tpl_vars['DISCOUNT_APPLICATION_TYPE_VALUE']->value == '2') {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['BASKET_BEFORE_SALES']->value;?>
</option>
                                        <option value="3"<?php if ($_smarty_tpl->tpl_vars['DISCOUNT_APPLICATION_TYPE_VALUE']->value == '3') {?> selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['BASKET_AFTER_SALES']->value;?>
</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="inputMinimum"><?php echo $_smarty_tpl->tpl_vars['MINIMUM_SPEND']->value;?>
</label>
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><?php echo $_smarty_tpl->tpl_vars['CURRENCY']->value;?>
</span>
                                        </div>
                                        <input type="number" class="form-control" name="minimum" id="inputMinimum" placeholder="<?php echo $_smarty_tpl->tpl_vars['MINIMUM_SPEND']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['MINIMUM_SPEND_VALUE']->value;?>
" step="0.01">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputUsername"><?php echo $_smarty_tpl->tpl_vars['USER_COUPON_FOR']->value;?>
</label> <small><?php echo $_smarty_tpl->tpl_vars['OPTIONAL']->value;?>
</small>
                                    <input type="text" class="form-control" id="inputUsername" name="username" placeholder="<?php echo $_smarty_tpl->tpl_vars['USER_COUPON_FOR']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['USER_COUPON_FOR_VALUE']->value;?>
">
                                </div>

                                <div class="form-group">
                                    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
                                    <input type="submit" class="btn btn-primary" value="<?php echo $_smarty_tpl->tpl_vars['SUBMIT']->value;?>
">
                                </div>
                            </form>

                        </div>
                    </div>

                    <!-- Spacing -->
                    <div style="height:1rem;"></div>

                </div>
        </section>
    </div>

    <div class="modal fade" id="cancelModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo $_smarty_tpl->tpl_vars['ARE_YOU_SURE']->value;?>
</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo $_smarty_tpl->tpl_vars['CONFIRM_CANCEL']->value;?>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo $_smarty_tpl->tpl_vars['NO']->value;?>
</button>
                    <a href="<?php echo $_smarty_tpl->tpl_vars['CANCEL_LINK']->value;?>
" class="btn btn-primary"><?php echo $_smarty_tpl->tpl_vars['YES']->value;?>
</a>
                </div>
            </div>
        </div>
    </div>

    <?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</div>
<!-- ./wrapper -->

<?php $_smarty_tpl->_subTemplateRender('file:scripts.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php echo '<script'; ?>
 type="text/javascript">
    function showCancelModal(){
        $('#cancelModal').modal().show();
    }
<?php echo '</script'; ?>
>

</body>
</html><?php }
}
