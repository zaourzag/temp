<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:43
  from '/var/www/nameless/custom/templates/Cesium/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c47617fc7_39395054',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a534b587486da3de9161b8e30e8478dfa87723f5' => 
    array (
      0 => '/var/www/nameless/custom/templates/Cesium/index.tpl',
      1 => 1611091445,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_60077c47617fc7_39395054 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/nameless/core/includes/smarty/plugins/modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php if (isset($_smarty_tpl->tpl_vars['HOME_SESSION_FLASH']->value)) {?>
	<div class="alert alert-info">
		<?php echo $_smarty_tpl->tpl_vars['HOME_SESSION_FLASH']->value;?>

	</div>
<?php }?>

<?php if (isset($_smarty_tpl->tpl_vars['HOME_SESSION_ERROR_FLASH']->value)) {?>
	<div class="alert alert-danger">
		<?php echo $_smarty_tpl->tpl_vars['HOME_SESSION_ERROR_FLASH']->value;?>

	</div>
<?php }?>

<?php if (count($_smarty_tpl->tpl_vars['NEWS']->value)) {?>
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['NEWS']->value, 'item');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['item']->value) {
?>
		<div class="card card-primary" id="newsPost-<?php echo $_smarty_tpl->tpl_vars['item']->value['id'];?>
">
			<div class="card-header">
				<a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
				<?php if (isset($_smarty_tpl->tpl_vars['item']->value['label'])) {?>
					<div class="news-label"><?php echo $_smarty_tpl->tpl_vars['item']->value['label'];?>
</div>
				<?php }?>
			</div>
			<div class="card-body">
				<div class="meta">
					<div class="news-meta">
						<a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_url'];?>
" class="news-avatar">
							<img src="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_avatar'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_name'];?>
">
						</a>
						<span>
							<a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_url'];?>
" style="<?php echo $_smarty_tpl->tpl_vars['item']->value['author_style'];?>
" data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['item']->value['author_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['author_name'];?>
</a>
							&bull;
							<span data-toggle="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['item']->value['date'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['time_ago'];?>
</span>
						</span>
					</div>
					<div class="news-stats">
						<i class="fas fa-eye fa-fw"></i> <?php echo $_smarty_tpl->tpl_vars['item']->value['views'];?>

						<i class="fas fa-comments fa-fw"></i> <?php echo $_smarty_tpl->tpl_vars['item']->value['replies'];?>

					</div>
				</div>
				<div class="date-block">
					<div class="date"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['item']->value['date'],"%d");?>
</div>
					<div class="month"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['item']->value['date'],"%b");?>
</div>
				</div>
				<div class="post">
					<?php echo $_smarty_tpl->tpl_vars['item']->value['content'];?>

				</div>
			</div>
			<div class="card-footer">
				<a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['url'];?>
" class="btn btn-primary btn-sm"><?php echo $_smarty_tpl->tpl_vars['READ_FULL_POST']->value;?>
</a>
			</div>
		</div>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
} else { ?>
	<div class="alert alert-danger">
		<?php echo $_smarty_tpl->tpl_vars['CSM']->value['noNewsPosts'];?>

	</div>
<?php }?>

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
