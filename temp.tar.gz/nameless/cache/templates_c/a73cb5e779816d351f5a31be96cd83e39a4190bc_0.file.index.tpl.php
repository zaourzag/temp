<?php
/* Smarty version 3.1.33, created on 2021-01-20 11:54:07
  from '/var/www/nameless/custom/templates/DefaultRevamp/tebex/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600819dfc5b711_84020903',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a73cb5e779816d351f5a31be96cd83e39a4190bc' => 
    array (
      0 => '/var/www/nameless/custom/templates/DefaultRevamp/tebex/index.tpl',
      1 => 1611105722,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_600819dfc5b711_84020903 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<h2 class="ui header">
    <?php echo $_smarty_tpl->tpl_vars['STORE']->value;?>

</h2>

<div class="ui stackable grid">
    <div class="ui centered row">
        <div class="ui <?php if (count($_smarty_tpl->tpl_vars['WIDGETS']->value)) {?>ten wide tablet twelve wide computer<?php } else { ?>sixteen wide<?php }?> column">
            <div class="ui padded segment">
                <div class="ui top attached menu">
                    <?php if ($_smarty_tpl->tpl_vars['SHOW_HOME_TAB']->value == '1') {?>
                        <a class="active item" href="<?php echo $_smarty_tpl->tpl_vars['HOME_URL']->value;?>
">
                            <?php echo $_smarty_tpl->tpl_vars['HOME']->value;?>

                        </a>
                    <?php }?>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['CATEGORIES']->value, 'category');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['category']->value) {
?>
                        <?php if (isset($_smarty_tpl->tpl_vars['category']->value['subcategories']) && count($_smarty_tpl->tpl_vars['category']->value['subcategories'])) {?>
                            <div class="ui pointing dropdown link item">
                                <span class="text"><?php echo $_smarty_tpl->tpl_vars['category']->value['title'];?>
</span>
                                <i class="dropdown icon"></i>
                                <div class="menu">
                                    <a class="item" href="<?php echo $_smarty_tpl->tpl_vars['category']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['category']->value['title'];?>
</a>
                                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['category']->value['subcategories'], 'subcategory');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['subcategory']->value) {
?>
                                        <a class="item" href="<?php echo $_smarty_tpl->tpl_vars['subcategory']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['subcategory']->value['title'];?>
</a>
                                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                </div>
                            </div>
                        <?php } else { ?>
                            <a class="item" href="<?php echo $_smarty_tpl->tpl_vars['category']->value['url'];?>
">
                                <?php echo $_smarty_tpl->tpl_vars['category']->value['title'];?>

                            </a>
                        <?php }?>
                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </div>
                <div class="ui bottom attached segment">
                    <?php echo $_smarty_tpl->tpl_vars['CONTENT']->value;?>

                </div>
            </div>
        </div>
        <?php if (count($_smarty_tpl->tpl_vars['WIDGETS']->value)) {?>
            <div class="ui six wide tablet four wide computer column">
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['WIDGETS']->value, 'widget');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['widget']->value) {
?>
                    <?php echo $_smarty_tpl->tpl_vars['widget']->value;?>

                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </div>
        <?php }?>
    </div>
</div>

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
