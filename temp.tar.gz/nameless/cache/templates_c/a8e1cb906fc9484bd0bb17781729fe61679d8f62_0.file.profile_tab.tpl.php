<?php
/* Smarty version 3.1.33, created on 2021-01-20 01:34:41
  from '/var/www/nameless/custom/templates/MineBox/forum/profile_tab.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600788b1d067e2_89556430',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a8e1cb906fc9484bd0bb17781729fe61679d8f62' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/forum/profile_tab.tpl',
      1 => 1611094420,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_600788b1d067e2_89556430 (Smarty_Internal_Template $_smarty_tpl) {
?><h3><?php echo $_smarty_tpl->tpl_vars['FORUM_TAB_TITLE']->value;?>
</h3>

<?php if (isset($_smarty_tpl->tpl_vars['NO_POSTS']->value)) {?>
	<p><?php echo $_smarty_tpl->tpl_vars['NO_POSTS']->value;?>
</p>
<?php } else { ?>
	<hr />
	<h4><?php echo $_smarty_tpl->tpl_vars['PF_LATEST_POSTS_TITLE']->value;?>
</h4>
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['PF_LATEST_POSTS']->value, 'post');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['post']->value) {
?>
		<div class="card panel-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
">
			<div class="card-header header-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
">
				<?php if ($_smarty_tpl->tpl_vars['post']->value['label']) {
echo $_smarty_tpl->tpl_vars['post']->value['label'];?>
 <?php }?><a href="<?php echo $_smarty_tpl->tpl_vars['post']->value['link'];?>
"><?php echo $_smarty_tpl->tpl_vars['post']->value['title'];?>
</a>
				<span class="pull-right">
	                <span rel="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['post']->value['date_full'];?>
"><i class="fa fa-clock-o" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['post']->value['date_friendly'];?>
</span>
	            </span>
			</div>
			<div class="card-body">
				<div class="forum_post">
					<?php echo $_smarty_tpl->tpl_vars['post']->value['content'];?>

				</div>
			</div>
		</div>
		<br />
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
}
}
}
