<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:51:35
  from '/var/www/nameless/custom/templates/MineBox/status.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077e97dfab48_19672025',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ae014c338af2087fc09383dce03d279bf8b42d20' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/status.tpl',
      1 => 1611094419,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_60077e97dfab48_19672025 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="container">
    <div class="card">
        <div class="card-body">
            <h2><?php echo $_smarty_tpl->tpl_vars['STATUS']->value;?>
</h2>

            <?php if (isset($_smarty_tpl->tpl_vars['CLICK_TO_COPY_TOOLTIP']->value)) {?>
            <div class="alert alert-info" style="text-align:center">
                <span onclick="copyToClipboard('#ip')" data-toggle="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['CLICK_TO_COPY_TOOLTIP']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['CONNECT_WITH']->value;?>
</span>
            </div>
            <?php }?>

            <?php if (count($_smarty_tpl->tpl_vars['SERVERS']->value)) {?>
                <?php $_smarty_tpl->_assignInScope('i', 0);?>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['SERVERS']->value, 'server', false, NULL, 'serverArray', array (
  'last' => true,
  'iteration' => true,
  'total' => true,
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['server']->value) {
$_smarty_tpl->tpl_vars['__smarty_foreach_serverArray']->value['iteration']++;
$_smarty_tpl->tpl_vars['__smarty_foreach_serverArray']->value['last'] = $_smarty_tpl->tpl_vars['__smarty_foreach_serverArray']->value['iteration'] === $_smarty_tpl->tpl_vars['__smarty_foreach_serverArray']->value['total'];
?>
                    <?php if ($_smarty_tpl->tpl_vars['i']->value == 0 || ($_smarty_tpl->tpl_vars['i']->value%3) == 0) {?>
                        <div class="card-deck" style="text-align:center">
                    <?php }?>

                    <div class="card server" id="server<?php echo $_smarty_tpl->tpl_vars['server']->value->id;?>
" data-id="<?php echo $_smarty_tpl->tpl_vars['server']->value->id;?>
" data-bungee="<?php echo $_smarty_tpl->tpl_vars['server']->value->bungee;?>
" data-players="<?php echo $_smarty_tpl->tpl_vars['server']->value->player_list;?>
">
                        <div class="card-header">
							<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['server']->value->name, ENT_QUOTES, 'UTF-8', true);?>

						</div>
                        <div class="card-body" id="content<?php echo $_smarty_tpl->tpl_vars['server']->value->id;?>
">
                            <i class="fa fa-spinner fa-pulse fa-2x" id="spinner<?php echo $_smarty_tpl->tpl_vars['server']->value->id;?>
"></i>
                        </div>
						<!--
						<div class="panel-footer">
							<div onclick="copyToClipboard('#<?php echo $_smarty_tpl->tpl_vars['server']->value->id;?>
')" data-toggle="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['CLICK_TO_COPY_TOOLTIP']->value;?>
"><span class="text-uppercase" style="color: #000;" id="<?php echo $_smarty_tpl->tpl_vars['server']->value->id;?>
"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['server']->value->ip, ENT_QUOTES, 'UTF-8', true);?>
</span></div>
						</div>
						-->
                    </div>

                    <?php if ((($_smarty_tpl->tpl_vars['i']->value+1)%3) == 0 || (isset($_smarty_tpl->tpl_vars['__smarty_foreach_serverArray']->value['last']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_serverArray']->value['last'] : null)) {?>
                        </div><br />
                    <?php }?>
                    <?php $_smarty_tpl->_assignInScope('i', $_smarty_tpl->tpl_vars['i']->value+1);?>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            <?php } else { ?>
                <div class="alert alert-warning" style="text-align:center"><?php echo $_smarty_tpl->tpl_vars['NO_SERVERS']->value;?>
</div>
            <?php }?>
        </div>
	</div>
</div>
<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
