<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:43
  from '/var/www/nameless/custom/templates/Cesium/widgets/online_staff.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c475f85f3_75085661',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ae6ffd7d261440e6bd885d948c046b21f45475e0' => 
    array (
      0 => '/var/www/nameless/custom/templates/Cesium/widgets/online_staff.tpl',
      1 => 1611091459,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c475f85f3_75085661 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="card card-default" id="widget-onlineStaff">
	<div class="card-header">
		<i class="fas fa-users-cog fa-fw"></i> <?php echo $_smarty_tpl->tpl_vars['ONLINE_STAFF']->value;?>

	</div>
	<div class="card-body">
		<div class="list">
			<?php if (isset($_smarty_tpl->tpl_vars['ONLINE_STAFF_LIST']->value)) {?>
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ONLINE_STAFF_LIST']->value, 'user');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
?>
					<div class="list-item">
						<div class="list-icon">
							<a href="<?php echo $_smarty_tpl->tpl_vars['user']->value['profile'];?>
">
								<img src="<?php echo $_smarty_tpl->tpl_vars['user']->value['avatar'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['user']->value['nickname'];?>
">
							</a>
						</div>
						<div class="list-content">
							<a href="<?php echo $_smarty_tpl->tpl_vars['user']->value['profile'];?>
" style="<?php echo $_smarty_tpl->tpl_vars['user']->value['style'];?>
" data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['user']->value['username'];?>
</a>
							<?php if (!empty($_smarty_tpl->tpl_vars['user']->value['title'])) {?>
								<span class="meta">
									<?php echo $_smarty_tpl->tpl_vars['user']->value['title'];?>

								</span>
							<?php }?>
						</div>
					</div>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			<?php } else { ?>
				<?php echo $_smarty_tpl->tpl_vars['NO_STAFF_ONLINE']->value;?>

			<?php }?>
		</div>
	</div>
	<div class="card-footer">
		<span><?php echo $_smarty_tpl->tpl_vars['TOTAL_ONLINE_STAFF']->value;?>
</span>
	</div>
</div><?php }
}
