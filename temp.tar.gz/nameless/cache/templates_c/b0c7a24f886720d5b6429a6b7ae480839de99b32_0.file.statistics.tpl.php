<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:17
  from '/var/www/nameless/custom/templates/Aether/widgets/statistics.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c2d67b6f2_36393582',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b0c7a24f886720d5b6429a6b7ae480839de99b32' => 
    array (
      0 => '/var/www/nameless/custom/templates/Aether/widgets/statistics.tpl',
      1 => 1599551086,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c2d67b6f2_36393582 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="card">
    <div class="card-header header-theme">
        <span><i class="fas fa-signal"></i> <?php echo $_smarty_tpl->tpl_vars['STATISTICS']->value;?>
</span>
    </div>
    <div class="card-block">
        <?php if (isset($_smarty_tpl->tpl_vars['FORUM_STATISTICS']->value)) {?>
        <span><b><?php echo $_smarty_tpl->tpl_vars['TOTAL_THREADS_VALUE']->value;?>
</b> <?php echo $_smarty_tpl->tpl_vars['TOTAL_THREADS']->value;?>
</span><br />
        <span><b><?php echo $_smarty_tpl->tpl_vars['TOTAL_POSTS_VALUE']->value;?>
</b> <?php echo $_smarty_tpl->tpl_vars['TOTAL_POSTS']->value;?>
</span><br /> <?php }?>
        <span><b><?php echo $_smarty_tpl->tpl_vars['USERS_REGISTERED_VALUE']->value;?>
</b> <?php echo $_smarty_tpl->tpl_vars['USERS_REGISTERED']->value;?>
</span><br />
        <span><b><?php echo $_smarty_tpl->tpl_vars['USERS_ONLINE_VALUE']->value;?>
</b> <?php echo $_smarty_tpl->tpl_vars['USERS_ONLINE']->value;?>
</span><br />
        <span><b><?php echo $_smarty_tpl->tpl_vars['GUESTS_ONLINE_VALUE']->value;?>
</b> <?php echo $_smarty_tpl->tpl_vars['GUESTS_ONLINE']->value;?>
</span><br />
        <span><b><?php echo $_smarty_tpl->tpl_vars['TOTAL_ONLINE_VALUE']->value;?>
</b> <?php echo $_smarty_tpl->tpl_vars['TOTAL_ONLINE']->value;?>
</span><br />
        <span><?php echo $_smarty_tpl->tpl_vars['LATEST_MEMBER']->value;?>
: <a style="<?php echo $_smarty_tpl->tpl_vars['LAST_MEMBER_VALUE']->value['style'];?>
" href="<?php echo $_smarty_tpl->tpl_vars['LATEST_MEMBER_VALUE']->value['profile'];?>
" data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['LATEST_MEMBER_VALUE']->value['id'];?>
" data-html="true" data-placement="top"><b><?php echo $_smarty_tpl->tpl_vars['LATEST_MEMBER_VALUE']->value['nickname'];?>
</b></a></span>
    </div>
</div><?php }
}
