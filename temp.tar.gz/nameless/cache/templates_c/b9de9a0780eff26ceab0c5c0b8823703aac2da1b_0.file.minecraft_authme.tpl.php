<?php
/* Smarty version 3.1.33, created on 2021-01-26 19:09:32
  from '/var/www/nameless/custom/panel_templates/Default/integrations/minecraft/minecraft_authme.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_601068ec078ac8_88778665',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b9de9a0780eff26ceab0c5c0b8823703aac2da1b' => 
    array (
      0 => '/var/www/nameless/custom/panel_templates/Default/integrations/minecraft/minecraft_authme.tpl',
      1 => 1611082601,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:sidebar.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:includes/update.tpl' => 1,
    'file:includes/alerts.tpl' => 1,
    'file:footer.tpl' => 1,
    'file:scripts.tpl' => 1,
  ),
),false)) {
function content_601068ec078ac8_88778665 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<body id="page-top">

<!-- Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php $_smarty_tpl->_subTemplateRender('file:sidebar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main content -->
        <div id="content">

            <!-- Topbar -->
            <?php $_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800"><?php echo $_smarty_tpl->tpl_vars['AUTHME']->value;?>
</h1>
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo $_smarty_tpl->tpl_vars['PANEL_INDEX']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['DASHBOARD']->value;?>
</a></li>
                        <li class="breadcrumb-item active"><?php echo $_smarty_tpl->tpl_vars['INTEGRATIONS']->value;?>
</li>
                        <li class="breadcrumb-item"><a href="<?php echo $_smarty_tpl->tpl_vars['MINECRAFT_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['MINECRAFT']->value;?>
</a></li>
                        <li class="breadcrumb-item active"><?php echo $_smarty_tpl->tpl_vars['AUTHME']->value;?>
</li>
                    </ol>
                </div>

                <!-- Update Notification -->
                <?php $_smarty_tpl->_subTemplateRender('file:includes/update.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

                <div class="card shadow mb-4">
                    <div class="card-body">

                        <!-- Success and Error Alerts -->
                        <?php $_smarty_tpl->_subTemplateRender('file:includes/alerts.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

                        <div class="card shadow border-left-primary">
                            <div class="card-body">
                                <h5><i class="icon fa fa-info-circle"></i> <?php echo $_smarty_tpl->tpl_vars['INFO']->value;?>
</h5>
                                <?php echo $_smarty_tpl->tpl_vars['AUTHME_INFO']->value;?>

                            </div>
                        </div>
                        <br />

                        <form id="enableAuthMe" action="" method="post">
                            <label for="inputEnableAuthme"><?php echo $_smarty_tpl->tpl_vars['ENABLE_AUTHME']->value;?>
</label>
                            <input type="hidden" name="enable_authme" value="0">
                            <input id="inputEnableAuthme" name="enable_authme" type="checkbox"
                                   class="js-switch js-check-change" <?php if ($_smarty_tpl->tpl_vars['ENABLE_AUTHME_VALUE']->value) {?> checked<?php }?> value="1" />
                            <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
                        </form>

                        <?php if (isset($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value)) {?>
                            <hr />
                            <form action="" method="post">
                                <div class="form-group">
                                    <label for="inputHashingAlgorithm"><?php echo $_smarty_tpl->tpl_vars['AUTHME_HASH_ALGORITHM']->value;?>
</label>
                                    <select id="inputHashingAlgorithm" class="form-control" name="hashing_algorithm">
                                        <option value="bcrypt" <?php if (isset($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->hash) && $_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->hash == 'bcrypt') {?> selected<?php }?>>
                                            bcrypt
                                        </option>
                                        <option value="sha1" <?php if (isset($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->hash) && $_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->hash == 'sha1') {?> selected<?php }?>>
                                            SHA1
                                        </option>
                                        <option value="sha256" <?php if (isset($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->hash) && $_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->hash == 'sha256') {?> selected<?php }?>>
                                            SHA256
                                        </option>
                                        <option value="pbkdf2" <?php if (isset($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->hash) && $_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->hash == 'pbkdf2') {?> selected<?php }?>>
                                            PBKDF2
                                        </option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="inputDBAddress"><?php echo $_smarty_tpl->tpl_vars['AUTHME_DB_ADDRESS']->value;?>
</label>
                                    <input type="text" class="form-control" name="db_address"
                                           value="<?php if (isset($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->address)) {
echo htmlspecialchars($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->address, ENT_QUOTES, 'UTF-8', true);
}?>">
                                </div>
                                <div class="form-group">
                                    <label for="inputDBPort"><?php echo $_smarty_tpl->tpl_vars['AUTHME_DB_PORT']->value;?>
</label>
                                    <input type="text" class="form-control" name="db_port"
                                           value="<?php if (isset($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->port)) {
echo htmlspecialchars($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->port, ENT_QUOTES, 'UTF-8', true);
} else { ?>3306<?php }?>">
                                </div>
                                <div class="form-group">
                                    <label for="inputDBName"><?php echo $_smarty_tpl->tpl_vars['AUTHME_DB_NAME']->value;?>
</label>
                                    <input type="text" class="form-control" name="db_name"
                                           value="<?php if (isset($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->db)) {
echo htmlspecialchars($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->db, ENT_QUOTES, 'UTF-8', true);
}?>">
                                </div>
                                <div class="form-group">
                                    <label for="inputDBUsername"><?php echo $_smarty_tpl->tpl_vars['AUTHME_DB_USER']->value;?>
</label>
                                    <input type="text" class="form-control" name="db_username"
                                           value="<?php if (isset($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->user)) {
echo htmlspecialchars($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->user, ENT_QUOTES, 'UTF-8', true);
}?>">
                                </div>
                                <div class="form-group">
                                    <label for="inputDBPassword"><?php echo $_smarty_tpl->tpl_vars['AUTHME_DB_PASSWORD']->value;?>
</label> <span
                                            class="badge badge-info"><i class="fa fa-question-circle"
                                                                        data-container="body" data-toggle="popover"
                                                                        data-placement="top" title="<?php echo $_smarty_tpl->tpl_vars['INFO']->value;?>
"
                                                                        data-content="<?php echo $_smarty_tpl->tpl_vars['AUTHME_DB_PASSWORD_HIDDEN']->value;?>
"></i></span>
                                    <input type="password" class="form-control" name="db_password">
                                </div>
                                <div class="form-group">
                                    <label for="inputDBTable"><?php echo $_smarty_tpl->tpl_vars['AUTHME_DB_TABLE']->value;?>
</label>
                                    <input type="text" class="form-control" name="db_table"
                                           value="<?php if (isset($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->table)) {
echo htmlspecialchars($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->table, ENT_QUOTES, 'UTF-8', true);
} else { ?>authme<?php }?>">
                                </div>
                                <div class="form-group">
                                    <label for="inputAuthmeSync"><?php echo $_smarty_tpl->tpl_vars['AUTHME_PASSWORD_SYNC']->value;?>
</label> <span
                                            class="badge badge-info"><i class="fa fa-question-circle"
                                                                        data-container="body" data-toggle="popover"
                                                                        data-placement="top" title="<?php echo $_smarty_tpl->tpl_vars['INFO']->value;?>
"
                                                                        data-content="<?php echo $_smarty_tpl->tpl_vars['AUTHME_PASSWORD_SYNC_HELP']->value;?>
"></i></span>
                                    <input type="hidden" name="authme_sync" value="0">
                                    <input id="inputAuthmeSync" name="authme_sync" type="checkbox"
                                           class="js-switch" <?php if (isset($_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->sync) && $_smarty_tpl->tpl_vars['AUTHME_DB_DETAILS']->value->sync) {?> checked<?php }?>
                                           value="1" />
                                </div>
                                <div class="form-group">
                                    <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
                                    <input type="submit" value="<?php echo $_smarty_tpl->tpl_vars['SUBMIT']->value;?>
" class="btn btn-primary">
                                </div>
                            </form>
                        <?php }?>

                    </div>
                </div>

                <!-- Spacing -->
                <div style="height:1rem;"></div>

                <!-- End Page Content -->
            </div>

            <!-- End Main Content -->
        </div>

        <?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <!-- End Content Wrapper -->
    </div>

    <!-- End Wrapper -->
</div>

<?php $_smarty_tpl->_subTemplateRender('file:scripts.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>

</html><?php }
}
