<?php
/* Smarty version 3.1.33, created on 2021-01-20 01:34:00
  from '/var/www/nameless/custom/templates/MineBox/forum/view_forum_no_discussions.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60078888dc0659_25053427',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bf5adc3cb7f2e524ca9b7bb9b2660cdad35edc71' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/forum/view_forum_no_discussions.tpl',
      1 => 1611094420,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_60078888dc0659_25053427 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="container">
<div class="card">
  <div class="card-body">
	  <div class="row">
		<div class="col-md-9">
		  <ol class="breadcrumb">
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['BREADCRUMBS']->value, 'breadcrumb');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['breadcrumb']->value) {
?>
			<li<?php if (isset($_smarty_tpl->tpl_vars['breadcrumb']->value['active'])) {?> class="active"<?php }?>><?php if (!isset($_smarty_tpl->tpl_vars['breadcrumb']->value['active'])) {?><a href="<?php echo $_smarty_tpl->tpl_vars['breadcrumb']->value['link'];?>
"><?php }
echo $_smarty_tpl->tpl_vars['breadcrumb']->value['forum_title'];
if (!isset($_smarty_tpl->tpl_vars['breadcrumb']->value['active'])) {?></a><?php }?></li>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		  </ol>
		  <h3 style="display: inline;"><?php echo $_smarty_tpl->tpl_vars['FORUM_TITLE']->value;?>
</h3><?php if ($_smarty_tpl->tpl_vars['NEW_TOPIC_BUTTON']->value) {?><span class="pull-right"><a href="<?php echo $_smarty_tpl->tpl_vars['NEW_TOPIC_BUTTON']->value;?>
" class="btn btn-success"><i class="fa fa-pencil" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['NEW_TOPIC']->value;?>
</a></span><?php }?><br /><br />
		  <?php if (!empty($_smarty_tpl->tpl_vars['SUBFORUMS']->value)) {?>
		  <div class="table-responsive">
		    <table class="table table-striped">
		      <colgroup>
			    <col span="1" style="width:50%">
			    <col span="1" style="width:20%">
			    <col span="1" style="width:30%">
			  </colgroup>
			  <tr>
			    <th colspan="3"><?php echo $_smarty_tpl->tpl_vars['SUBFORUM_LANGUAGE']->value;?>
</th>
			  </tr>
			  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['SUBFORUMS']->value, 'subforum');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['subforum']->value) {
?>
			  <tr>
			    <td><a href="<?php echo $_smarty_tpl->tpl_vars['subforum']->value['link'];?>
"><?php echo $_smarty_tpl->tpl_vars['subforum']->value['title'];?>
</a></td>
				<td><i class="fa fa-comments" style="width: auto;margin: 0 .75em 0 0;"></i><strong><?php echo $_smarty_tpl->tpl_vars['subforum']->value['topics'];?>
</strong> <?php echo $_smarty_tpl->tpl_vars['TOPICS']->value;?>
</td>
				<td>
				  <?php if (count($_smarty_tpl->tpl_vars['subforum']->value['latest_post'])) {?>
				  <div class="row">
				    <div class="col-md-3">
					  <div class="frame">
					    <a href="<?php echo $_smarty_tpl->tpl_vars['subforum']->value['latest_post']['last_user_link'];?>
"><img class="img-centre img-rounded" style="height:30px; width:30px;" src="<?php echo $_smarty_tpl->tpl_vars['subforum']->value['latest_post']['last_user_avatar'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['subforum']->value['latest_post']['last_user'];?>
" /></a>
					  </div>
				    </div>
				    <div class="col-md-9">
					  <a href="<?php echo $_smarty_tpl->tpl_vars['subforum']->value['latest_post']['link'];?>
"><?php echo $_smarty_tpl->tpl_vars['subforum']->value['latest_post']['title'];?>
</a>
					  <br />
					  <span data-toggle="tooltip" data-trigger="hover" data-original-title="<?php echo $_smarty_tpl->tpl_vars['subforum']->value['latest_post']['time'];?>
"><?php echo $_smarty_tpl->tpl_vars['subforum']->value['latest_post']['timeago'];?>
</span><br /><?php echo $_smarty_tpl->tpl_vars['BY']->value;?>
 <a style="<?php echo $_smarty_tpl->tpl_vars['subforum']->value['latest_post']['last_user_style'];?>
" href="<?php echo $_smarty_tpl->tpl_vars['subforum']->value['latest_post']['last_user_link'];?>
" data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['subforum']->value['latest_post']['last_user_id'];?>
" data-html="true" data-placement="top"><?php echo $_smarty_tpl->tpl_vars['subforum']->value['latest_post']['last_user'];?>
</a>
				    </div>
				  </div>
				  <?php } else { ?>
				  <?php echo $_smarty_tpl->tpl_vars['NO_TOPICS']->value;?>

				  <?php }?>
				</td>
			  </tr>
			  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		    </table>
		  </div>
		  <?php }?>
		  
		  <?php echo $_smarty_tpl->tpl_vars['NO_TOPICS_FULL']->value;?>

		</div>
		<div class="col-md-3">
		  <form class="form-horizontal" role="form" method="post" action="<?php echo $_smarty_tpl->tpl_vars['SEARCH_URL']->value;?>
">
		    <div class="input-group">
			  <input type="text" class="form-control input-sm" name="forum_search" placeholder="<?php echo $_smarty_tpl->tpl_vars['SEARCH']->value;?>
">
			  <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['TOKEN']->value;?>
">
			  <span class="input-group-btn">
			    <button type="submit" class="btn btn-success">
				  <i class="fa fa-search"></i>
			    </button>
			  </span>
		    </div>
		  </form>

<div class="googleads" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS']->value;?>
;">
<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value, $tmp) > 0) {?>
<br />
  <center>
	<ins class="adsbygoogle" data-ad-client="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_CLIENT']->value;?>
" data-ad-slot="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_GADS_SLOT']->value;?>
" data-ad-format="auto" data-full-width-responsive="true"></ins>
	<?php echo '<script'; ?>
>
		(adsbygoogle = window.adsbygoogle || []).push({});
	<?php echo '</script'; ?>
>
  </center>
<?php }?>
</div>

<div class="sidebar_banner" style="display: <?php echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER']->value;?>
;">
<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value, $tmp) > 0) {?>
<br />
  <center>
	<a href="<?php if (isset($_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value, $tmp) > 0) {
echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_LINK']->value;
} else { ?>#!<?php }?>" target="_blank" rel="nofollow">
		<img src="<?php echo $_smarty_tpl->tpl_vars['MINEBOX_SIDEBAR_BANNER_IMG']->value;?>
" style="max-width: 100%;">
	</a>
  </center>
<br />
<?php }?>
</div>

		  
		  <br />
		  <?php if (count($_smarty_tpl->tpl_vars['WIDGETS']->value)) {?>
		    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['WIDGETS']->value, 'widget');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['widget']->value) {
?>
		      <?php echo $_smarty_tpl->tpl_vars['widget']->value;?>
<br />
		    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		  <?php }?>
		  
		</div>
	  </div>
  </div>
</div>
</div>

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
