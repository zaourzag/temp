<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:17
  from '/var/www/nameless/custom/templates/Aether/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c2d6dbf29_10586354',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cbe44a37125fc76a1c19b73391f2fc8cc70ef221' => 
    array (
      0 => '/var/www/nameless/custom/templates/Aether/footer.tpl',
      1 => 1599551084,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c2d6dbf29_10586354 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="container">		
	<div class="chatbox" id="chatbox-bottom"></div>
</div>
<?php if (isset($_smarty_tpl->tpl_vars['GLOBAL_WARNING_TITLE']->value)) {?>
<div class="modal fade show-punishment" data-keyboard="false" data-backdrop="static" id="acknowledgeModal" tabindex="-1" role="dialog" aria-labelledby="acknowledgeModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="acknowledgeModalLabel"><?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_TITLE']->value;?>
</h4>
            </div>
            <div class="modal-body">
                <?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_REASON']->value;?>

            </div>
            <div class="modal-footer">
                <a href="<?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_ACKNOWLEDGE_LINK']->value;?>
" class="btn btn-warning"><?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_ACKNOWLEDGE']->value;?>
</a>
            </div>
        </div>
    </div>
</div>
<?php }?>
<br />
<footer class="footer-theme">
    <div class="footer-text">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <b><i class="fas fa-gavel"></i> <?php echo $_smarty_tpl->tpl_vars['FOOTER_LEGAL']->value;?>
</b><br />
                    <a href="<?php echo $_smarty_tpl->tpl_vars['TERMS_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['TERMS_TEXT']->value;?>
</a> &bull;
                    <a href="<?php echo $_smarty_tpl->tpl_vars['PRIVACY_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['PRIVACY_TEXT']->value;?>
</a><br /> &copy; <?php echo $_smarty_tpl->tpl_vars['SITE_NAME']->value;?>
 <?php echo date('Y');?>
<br />
                    <!--DO NOT REMOVE CREDITS CODE BELOW! REMOVING THIS CODE VIOLATES YOUR AETHER LICENSE!-->
                    <p><?php echo $_smarty_tpl->tpl_vars['FOOTER_CREDIT_1']->value;?>
 <a href="https://coldfiredzn.com" target="_blank">Coldfire</a> &bull;
                        <!--DO NOT REMOVE CREDITS CODE ABOVE! REMOVING THIS CODE VIOLATES YOUR AETHER LICENSE!-->
                        <a href="https://namelessmc.com">NamelessMC</a> <?php echo $_smarty_tpl->tpl_vars['FOOTER_CREDIT_2']->value;?>

                    </p>
                </div>
                <div class="col-md-4">
                    <b><i class="fas fa-link"></i> <?php echo $_smarty_tpl->tpl_vars['FOOTER_LINKS']->value;?>
</b><br /> <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['FOOTER_NAVIGATION']->value, 'item', false, 'name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['name']->value => $_smarty_tpl->tpl_vars['item']->value) {
?> <?php if (isset($_smarty_tpl->tpl_vars['item']->value['items'])) {?>
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
                    <div class="dropdown-menu">
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['item']->value['items'], 'dropdown');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown']->value) {
?>
                        <a href="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['dropdown']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['dropdown']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['dropdown']->value['title'];?>
</a> <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </div>
                    </a>
                    <?php } else { ?>
                    <a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
" target="<?php echo $_smarty_tpl->tpl_vars['item']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['icon'];?>
 <?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a> <?php }?>
                    <br /> <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    <br />
                </div>
                <div class="col-md-3">
                    <b><i class="far fa-user-circle"></i> <?php echo $_smarty_tpl->tpl_vars['FOOTER_SOCIAL']->value;?>
</b><br /> <?php if ($_smarty_tpl->tpl_vars['PAGE_LOAD_TIME']->value) {?>
                    <a href="#" onClick="return false;" data-toggle="tooltip" id="page_load_tooltip" title="Page loading.." style="text-decoration: none !important;"><i class="fas fa-tachometer-alt fa-2x"></i></a><?php }?>
		<?php if (!empty($_smarty_tpl->tpl_vars['SOCIAL_MEDIA_ICONS']->value)) {?>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['SOCIAL_MEDIA_ICONS']->value, 'icon');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['icon']->value) {
?>
                <a href="<?php echo $_smarty_tpl->tpl_vars['icon']->value['link'];?>
" target="_blank" style="text-decoration: none !important;"><i id="social-<?php echo $_smarty_tpl->tpl_vars['icon']->value['short'];?>
" class="<?php if ($_smarty_tpl->tpl_vars['icon']->value['long'] != 'envelope') {?>fab<?php } else { ?>fas<?php }?> fa-<?php echo $_smarty_tpl->tpl_vars['icon']->value['long'];?>
-square fa-2x"></i></a> <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    <?php }?>
                    <br />
                </div>
            </div>
        </div>
    </div>
</footer>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['TEMPLATE_JS']->value, 'script');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['script']->value) {
?> <?php echo $_smarty_tpl->tpl_vars['script']->value;?>
 <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
if (isset($_smarty_tpl->tpl_vars['NEW_UPDATE']->value)) {?>
	<?php if ($_smarty_tpl->tpl_vars['NEW_UPDATE_URGENT']->value != true) {?>
		<?php echo '<script'; ?>
 type="text/javascript">
            $(document).ready(function(){
                $('#closeUpdate').click(function(event){
                    event.preventDefault();

                    let expiry = new Date();
                    let length = 3600000;
                    expiry.setTime(expiry.getTime() + length);

                    $.cookie('update-alert-closed', 'true', { path: '/', expires: expiry });
                });

                if($.cookie('update-alert-closed') === 'true'){
                    $('#updateAlert').hide();
                }
            });
		<?php echo '</script'; ?>
>
	<?php }
}
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['PARTICLESJS']->value, 'PJS');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['PJS']->value) {
echo $_smarty_tpl->tpl_vars['PJS']->value;
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</body>
</html><?php }
}
