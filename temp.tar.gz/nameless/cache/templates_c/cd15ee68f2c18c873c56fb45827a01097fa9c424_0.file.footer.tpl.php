<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:34:31
  from '/var/www/nameless/custom/templates/Monarch/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077a97526094_51215401',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cd15ee68f2c18c873c56fb45827a01097fa9c424' => 
    array (
      0 => '/var/www/nameless/custom/templates/Monarch/footer.tpl',
      1 => 1611098705,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077a97526094_51215401 (Smarty_Internal_Template $_smarty_tpl) {
?>  </div></div>

  <div class="pre-footer text-center">
    <div class="container">
    <hr style="border:1px solid #000;">
      <div class="row">
        
        <div class="col-md-6" style="margin-top:20px">
          <h3>Social</h3>
          <ul class="list-inline social-media-list">
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['SOCIAL_MEDIA_ICONS']->value, 'icon');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['icon']->value) {
?>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['icon']->value['link'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['icon']->value['text'];?>
</a></li>
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
          </ul>
        </div>
        
        <div class="col-md-6" style="margin-top:20px">
          <h3>Useful Links</h3>
          <ul class="list-inline social-media-list">
            <span class="item"><a href="<?php echo $_smarty_tpl->tpl_vars['TERMS_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['TERMS_TEXT']->value;?>
</a></span><br>
            <span class="item"><a href="<?php echo $_smarty_tpl->tpl_vars['PRIVACY_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['PRIVACY_TEXT']->value;?>
</a></span>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <div id="contact" class="contact-section section text-center" style="background:<?php echo $_smarty_tpl->tpl_vars['MONARCH_COLOR']->value;?>
">
    <div class="container">
		<div class="row">
		<div class="col-md-6">
          <div class="ui inverted link list">
            <span class="item">&copy; <?php echo date('Y');?>
 <?php echo $_smarty_tpl->tpl_vars['SITE_NAME']->value;?>
. All Rights Reserved</span>
            <span class="item">Forum software by <a href="https://namelessmc.com">© <?php echo date('Y');?>
 NamelessMC</a></span>
          </div>
        </div>
		<div class="col-md-6">
          <div class="ui inverted link list">
            <span class="item">Designed By:<br><a href="https://github.com/agenthighcastle">HighCastle</a></span>
          </div>
        </div>
		</div>
    </div><!--//containter-->
  </div>

  <?php if (isset($_smarty_tpl->tpl_vars['GLOBAL_WARNING_TITLE']->value)) {?>
    <div class="ui medium modal" id="modal-acknowledge">
      <div class="header">
        <?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_TITLE']->value;?>

      </div>
      <div class="content">
        <?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_REASON']->value;?>

      </div>
      <div class="actions">
        <a class="ui positive button" href="<?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_ACKNOWLEDGE_LINK']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['GLOBAL_WARNING_ACKNOWLEDGE']->value;?>
</a>
      </div>
    </div>
  <?php }?>

  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['TEMPLATE_JS']->value, 'script');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['script']->value) {
?>
    <?php echo $_smarty_tpl->tpl_vars['script']->value;?>

  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

  <?php if (isset($_smarty_tpl->tpl_vars['NEW_UPDATE']->value) && ($_smarty_tpl->tpl_vars['NEW_UPDATE_URGENT']->value != true)) {?>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['TEMPLATE']->value['path'];?>
/js/core/update.js"><?php echo '</script'; ?>
>
  <?php }?>

</body>

</html>
<?php }
}
