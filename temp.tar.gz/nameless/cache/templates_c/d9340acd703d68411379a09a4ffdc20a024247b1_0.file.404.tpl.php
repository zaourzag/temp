<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:19
  from '/var/www/nameless/custom/templates/Aether/404.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c2f4cc6f2_26720206',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd9340acd703d68411379a09a4ffdc20a024247b1' => 
    array (
      0 => '/var/www/nameless/custom/templates/Aether/404.tpl',
      1 => 1599551084,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_60077c2f4cc6f2_26720206 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html<?php if (defined("HTML_CLASS")) {?> <?php echo @constant('HTML_CLASS');
}?> lang="<?php if (defined("HTML_LANG")) {
echo @constant('HTML_LANG');
} else { ?>en<?php }?>" <?php if (defined("HTML_RTL") && @constant('HTML_RTL') == true) {?> dir="rtl" <?php }?>>
    <head>
        <meta charset="<?php if (defined("LANG_CHARSET")) {
echo @constant('LANG_CHARSET');
} else { ?>utf-8<?php }?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        <title><?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
</title>
        <meta name="author" content="<?php echo @constant('SITE_NAME');?>
"> <?php if (isset($_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value, $tmp) > 0) {?>
        <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value;?>
" /> <?php }?> <?php if (isset($_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value, $tmp) > 0) {?>
        <meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value;?>
" /> <?php }?>
        <meta property="og:title" content="<?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="<?php echo $_smarty_tpl->tpl_vars['OG_URL']->value;?>
" />
        <meta property="og:image" content="<?php echo $_smarty_tpl->tpl_vars['THEME_FAVICON']->value;?>
" />
        <meta property="og:site_name" content="<?php echo @constant('SITE_NAME');?>
" /> <?php if (isset($_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value, $tmp) > 0) {?>
        <meta property="og:description" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value;?>
" /> <?php }?>
        <meta name="theme-color" content="<?php echo $_smarty_tpl->tpl_vars['THEME_S_COLOR']->value;?>
" />
        <link rel="icon" href="<?php echo $_smarty_tpl->tpl_vars['THEME_FAVICON']->value;?>
" /> <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['TEMPLATE_CSS']->value, 'css');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['css']->value) {
?> <?php echo $_smarty_tpl->tpl_vars['css']->value;?>
 <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_FONT']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_FONT']->value, $tmp) > 4) {?>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet"> 
        <style>
            body {font-family: 'Montserrat', sans-serif}
        </style>
         <?php } else { ?>
        <link href="https://fonts.googleapis.com/css2?family=Coda&display=swap" rel="stylesheet"> 
        <style>
            body {font-family: 'Coda', cursive}
        </style>
         <?php }?> <?php if (isset($_smarty_tpl->tpl_vars['THEME_GA']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_GA']->value, $tmp) > 0) {?> 
        <?php echo '<script'; ?>
 async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $_smarty_tpl->tpl_vars['THEME_GA']->value;?>
"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
>
            window.dataLayer = window.dataLayer || [];
      		        function gtag(){dataLayer.push(arguments);}
      		        gtag('js', new Date());
    
      		        gtag('config', '<?php echo $_smarty_tpl->tpl_vars['THEME_GA']->value;?>
');
        <?php echo '</script'; ?>
>
         <?php }?>
        <meta name="robots" content="noindex"> <?php echo $_smarty_tpl->tpl_vars['ParticlesCSS']->value;?>

    </head>
    <body>
        <?php echo $_smarty_tpl->tpl_vars['PARTICLESJsD']->value;?>
 <?php $_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
        <div class="container">
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <div class="jumbotron">
                        <center>
                            <h1>404</h1>
                            <br />
                            <h4><?php echo $_smarty_tpl->tpl_vars['404_TITLE']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['CONTENT']->value;?>
</h4>
                            <br />
                            <div class="btn-group" role="group" aria-label="...">
                                <button class="btn btn-primary btn-lg" onclick="javascript:history.go(-1)"><i class="fas fa-arrow-circle-left"></i> <?php echo $_smarty_tpl->tpl_vars['BACK']->value;?>
</button>
                                <a href="<?php echo $_smarty_tpl->tpl_vars['SITE_HOME']->value;?>
" class="btn btn-success btn-lg"><i class="fas fa-home"></i> <?php echo $_smarty_tpl->tpl_vars['HOME']->value;?>
</a>
                            </div>
                            <hr /> <?php echo $_smarty_tpl->tpl_vars['ERROR']->value;?>

                        </center>
                    </div>
                </div>
            </div>
        </div>
        <?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
