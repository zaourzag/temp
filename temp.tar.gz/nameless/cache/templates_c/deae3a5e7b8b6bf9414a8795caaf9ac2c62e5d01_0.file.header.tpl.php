<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:41:17
  from '/var/www/nameless/custom/templates/Aether/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c2d6a84c6_00429192',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'deae3a5e7b8b6bf9414a8795caaf9ac2c62e5d01' => 
    array (
      0 => '/var/www/nameless/custom/templates/Aether/header.tpl',
      1 => 1599551084,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c2d6a84c6_00429192 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html<?php if (defined("HTML_CLASS")) {?> <?php echo @constant('HTML_CLASS');
}?> lang="<?php if (defined("HTML_LANG")) {
echo @constant('HTML_LANG');
} else { ?>en<?php }?>" <?php if (defined("HTML_RTL") && @constant('HTML_RTL') == true) {?> dir="rtl"<?php }?>>
    <head>
        <meta charset="<?php if (defined("LANG_CHARSET")) {
echo @constant('LANG_CHARSET');
} else { ?>utf-8<?php }?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        <title><?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
</title>
        <meta name="author" content="<?php echo @constant('SITE_NAME');?>
"> 
	<?php if (isset($_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value, $tmp) > 0) {?>
        <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value;?>
" /> 
	<?php }?> 
	<?php if (isset($_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value, $tmp) > 0) {?>
        <meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_KEYWORDS']->value;?>
" /> 
	<?php }?>
        <meta property="og:title" content="<?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
 &bull; <?php echo @constant('SITE_NAME');?>
" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="<?php echo $_smarty_tpl->tpl_vars['OG_URL']->value;?>
" />
        <?php if (isset($_smarty_tpl->tpl_vars['THEME_FAVICON']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_FAVICON']->value, $tmp) > 0) {?><meta property="og:image" content="<?php echo $_smarty_tpl->tpl_vars['THEME_FAVICON']->value;?>
" /><?php }?>
	<meta property="og:site_name" content="<?php echo @constant('SITE_NAME');?>
" />
	<?php if (isset($_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value, $tmp) > 0) {?>
        <meta property="og:description" content="<?php echo $_smarty_tpl->tpl_vars['PAGE_DESCRIPTION']->value;?>
" /> 
	<?php }?>
        <meta name="theme-color" content="<?php echo $_smarty_tpl->tpl_vars['THEME_S_COLOR']->value;?>
" />
        <?php if (isset($_smarty_tpl->tpl_vars['THEME_FAVICON']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_FAVICON']->value, $tmp) > 0) {?><link rel="icon" href="<?php echo $_smarty_tpl->tpl_vars['THEME_FAVICON']->value;?>
" /><?php }?>
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['TEMPLATE_CSS']->value, 'css');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['css']->value) {
?>
	<?php echo $_smarty_tpl->tpl_vars['css']->value;?>

	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	<?php if (isset($_smarty_tpl->tpl_vars['THEME_FONT']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_FONT']->value, $tmp) > 4) {?>
		<link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
		
			<style>
 				body {font-family: 'Montserrat', sans-serif}
			</style>
		
	<?php } else { ?>
		<link href="https://fonts.googleapis.com/css2?family=Coda&display=swap" rel="stylesheet">
		
			<style>
 				body {font-family: 'Coda', cursive}
			</style>
		
	<?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['THEME_GA']->value) && preg_match_all('/[^\s]/u',$_smarty_tpl->tpl_vars['THEME_GA']->value, $tmp) > 0) {?>
	        
	        <?php echo '<script'; ?>
 async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $_smarty_tpl->tpl_vars['THEME_GA']->value;?>
"><?php echo '</script'; ?>
>
	        <?php echo '<script'; ?>
>
  		        window.dataLayer = window.dataLayer || [];
  		        function gtag(){dataLayer.push(arguments);}
  		        gtag('js', new Date());

  		        gtag('config', '<?php echo $_smarty_tpl->tpl_vars['THEME_GA']->value;?>
');
	        <?php echo '</script'; ?>
>
	        
	<?php }?>
    	<?php echo $_smarty_tpl->tpl_vars['ParticlesCSS']->value;?>

    </head>
    <body>
        <?php echo $_smarty_tpl->tpl_vars['PARTICLESJsD']->value;
}
}
