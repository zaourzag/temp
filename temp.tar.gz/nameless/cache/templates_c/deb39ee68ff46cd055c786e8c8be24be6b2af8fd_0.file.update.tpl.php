<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:31:01
  from '/var/www/nameless/custom/panel_templates/Default/update.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600779c53b0453_94556450',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'deb39ee68ff46cd055c786e8c8be24be6b2af8fd' => 
    array (
      0 => '/var/www/nameless/custom/panel_templates/Default/update.tpl',
      1 => 1611082599,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_600779c53b0453_94556450 (Smarty_Internal_Template $_smarty_tpl) {
if (isset($_smarty_tpl->tpl_vars['NEW_UPDATE']->value)) {?>
    <?php if ($_smarty_tpl->tpl_vars['NEW_UPDATE_URGENT']->value == true) {?>
        <div class="alert alert-danger">
        <?php } else { ?>
            <div class="alert alert-primary alert-dismissible" id="updateAlert">
                <button type="button" class="close" id="closeUpdate" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            <?php }?>
            <?php echo $_smarty_tpl->tpl_vars['NEW_UPDATE']->value;?>
<br />
            <a href="<?php echo $_smarty_tpl->tpl_vars['UPDATE_LINK']->value;?>
" class="btn btn-primary" style="text-decoration:none"><?php echo $_smarty_tpl->tpl_vars['UPDATE']->value;?>
</a>
            <hr /> <?php echo $_smarty_tpl->tpl_vars['CURRENT_VERSION']->value;?>

            <br /><?php echo $_smarty_tpl->tpl_vars['NEW_VERSION']->value;?>

        </div>
    <?php }
}
}
