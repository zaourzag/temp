<?php
/* Smarty version 3.1.33, created on 2021-01-20 00:42:50
  from '/var/www/nameless/custom/templates/MineBox/widgets/statistics.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60077c8a73fcb4_20340747',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f3872ddf50ae96717db5168b5d97d01324f72760' => 
    array (
      0 => '/var/www/nameless/custom/templates/MineBox/widgets/statistics.tpl',
      1 => 1611094424,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60077c8a73fcb4_20340747 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="card panel-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
">
	<div class="collaps card-header text-white text-uppercase header-<?php echo $_smarty_tpl->tpl_vars['MINEBOX_COLOR']->value;?>
"><i class="fa fa-users" style="width: auto;margin: 0 .75em 0 0;"></i> <?php echo $_smarty_tpl->tpl_vars['STATISTICS']->value;?>
</div>
	<div class="content">
	<div class="card-body">
    <?php if (isset($_smarty_tpl->tpl_vars['FORUM_STATISTICS']->value)) {?>
      <div>
        <span class="text-muted"><?php echo $_smarty_tpl->tpl_vars['TOTAL_THREADS']->value;?>
</span>
        <span class="float-right"><?php echo $_smarty_tpl->tpl_vars['TOTAL_THREADS_VALUE']->value;?>
</span>
      </div>
      <div>
        <span class="text-muted"><?php echo $_smarty_tpl->tpl_vars['TOTAL_POSTS']->value;?>
</span>
        <span class="float-right"><?php echo $_smarty_tpl->tpl_vars['TOTAL_POSTS_VALUE']->value;?>
</span>
      </div>
    <?php }?>
    <div>
      <span class="text-muted"><?php echo $_smarty_tpl->tpl_vars['USERS_REGISTERED']->value;?>
</span>
      <span class="float-right"><?php echo $_smarty_tpl->tpl_vars['USERS_REGISTERED_VALUE']->value;?>
</span>
    </div>
    <div>
      <span class="text-muted"><?php echo $_smarty_tpl->tpl_vars['LATEST_MEMBER']->value;?>
</span>
      <span class="float-right"><a style="<?php echo $_smarty_tpl->tpl_vars['LAST_MEMBER_VALUE']->value['style'];?>
" href="<?php echo $_smarty_tpl->tpl_vars['LATEST_MEMBER_VALUE']->value['profile'];?>
" data-poload="<?php echo $_smarty_tpl->tpl_vars['USER_INFO_URL']->value;
echo $_smarty_tpl->tpl_vars['LATEST_MEMBER_VALUE']->value['id'];?>
" data-html="true" data-placement="top"><?php echo $_smarty_tpl->tpl_vars['LATEST_MEMBER_VALUE']->value['nickname'];?>
</a></span>
    </div>
    </div>
	</div>
</div>
<?php }
}
