<?php
/* Smarty version 3.1.33, created on 2021-01-23 02:21:05
  from '/var/www/nameless/custom/templates/DefaultRevamp/privacy.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_600b8811815392_42224696',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ffcfa019d5f0bf83ae7c6ccf8c5b7081e2269d75' => 
    array (
      0 => '/var/www/nameless/custom/templates/DefaultRevamp/privacy.tpl',
      1 => 1611074674,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:navbar.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_600b8811815392_42224696 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender('file:navbar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<h2 class="ui header">
  <?php echo $_smarty_tpl->tpl_vars['PRIVACY_POLICY']->value;?>

</h2>

<div class="ui padded segment" id="privacy-policy">
  <p><?php echo $_smarty_tpl->tpl_vars['POLICY']->value;?>
</p>
</div>

<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
